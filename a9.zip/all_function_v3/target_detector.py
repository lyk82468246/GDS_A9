#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
Target Detector Library
目标检测库 - 集成几何边界检测和聚类分析
"""

import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
import time

# 全局边界检测配置
BOUNDARY_CONFIG = {
    'change_threshold': 150,      # 边界变化阈值(mm) - 增大以容忍更多不规则
    'smoothing_window': 7,        # 平滑窗口大小 - 增大以减少噪声影响
    'outlier_tolerance': 0.3,     # 异常值容忍度 (0-1) - 高值容忍更多异常点
    'boundary_percentile': 0.4,   # 边界检测百分位数 - 使用更保守的百分位
    'min_continuity_points': 3,   # 边界连续性最小点数
    'distance_variance_threshold': 200,  # 距离方差阈值
    'use_geometric_detection': True,  # 启用几何形状检测
    'wall_distance_threshold': 80,    # 墙面点距离阈值(mm)
    'min_wall_points': 15,            # 每面墙最少点数
    'angle_tolerance': 15,            # 墙面角度容忍度
}

# 全局聚类识别配置
CLUSTERING_CONFIG = {
    'eps': 100,                    # DBSCAN聚类半径(mm) - 控制聚类的紧密程度
    'min_samples': 3,             # DBSCAN最小样本数 - 形成聚类所需的最少点数
    'target_size_min': 80,        # 目标最小尺寸(mm)
    'target_size_max': 250,       # 目标最大尺寸(mm) 
    'min_cluster_points': 3,      # 有效聚类最少点数
    'density_threshold': 0.7,     # 小目标密度阈值 - 允许小但密集的目标
    'confidence_weight_points': 0.4,    # 点数在置信度计算中的权重
    'confidence_weight_density': 0.6,   # 密度在置信度计算中的权重
    'max_clusters': 5,           # 最大聚类数量限制
    'outlier_filter': True,       # 启用异常值过滤
    'outlier_threshold': 2.0,     # 异常值标准差阈值
}

class BoundaryDetector:
    """增强的边界检测器，专门处理平行四边形场地"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.expected_field_shape = 'rectangle'  # 期望的场地形状
        self.wall_detection_distance = 3500  # 墙面检测距离阈值
        self.min_wall_points = BOUNDARY_CONFIG['min_wall_points']
        self.angle_tolerance = BOUNDARY_CONFIG['angle_tolerance']
        self.wall_distance_threshold = BOUNDARY_CONFIG['wall_distance_threshold']
        
    def detect_walls_by_geometry(self, scan_data):
        """基于几何形状检测墙面边界"""
        print("开始几何形状检测...")
        
        # 1. 收集所有有效点
        points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 5000:  # 有效距离范围
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                points.append((x, y, angle, distance))
        
        print(f"收集到有效点数: {len(points)}")
        
        if len(points) < 50:
            print("有效点数不足,无法进行几何检测")
            return []
        
        # 2. 使用RANSAC算法检测直线（墙面）
        walls = self._detect_walls_ransac(points)
        print(f"检测到墙面数量: {len(walls)}")
        
        # 3. 过滤和验证墙面
        valid_walls = self._validate_walls(walls, points)
        print(f"有效墙面数量: {len(valid_walls)}")
        
        # 4. 根据墙面确定场地内的点
        field_points = self._filter_points_by_walls(points, valid_walls)
        print(f"场地内点数: {len(field_points)}")
        
        return field_points
    
    def _detect_walls_ransac(self, points, max_walls=4):
        """使用RANSAC算法检测墙面直线"""
        walls = []
        remaining_points = points.copy()
        
        for wall_idx in range(max_walls):
            if len(remaining_points) < 20:
                break
            
            best_wall = None
            best_inliers = []
            max_inliers = 0
            
            # RANSAC迭代
            for iteration in range(200):  # 增加迭代次数
                # 随机选择两个点
                if len(remaining_points) < 2:
                    break
                    
                sample = random.sample(remaining_points, 2)
                p1, p2 = sample[0][:2], sample[1][:2]
                
                # 计算直线参数 ax + by + c = 0
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                
                if abs(dx) < 1 and abs(dy) < 1:
                    continue
                
                # 直线方程: (y2-y1)x - (x2-x1)y + (x2-x1)y1 - (y2-y1)x1 = 0
                a = dy
                b = -dx
                c = dx * p1[1] - dy * p1[0]
                
                # 归一化
                norm = math.sqrt(a*a + b*b)
                if norm > 0:
                    a, b, c = a/norm, b/norm, c/norm
                else:
                    continue
                
                # 找到内点
                inliers = []
                for point in remaining_points:
                    x, y = point[0], point[1]
                    dist = abs(a*x + b*y + c)
                    if dist < self.wall_distance_threshold:  # 距离阈值
                        inliers.append(point)
                
                # 更新最佳结果
                if len(inliers) > max_inliers and len(inliers) >= self.min_wall_points:
                    max_inliers = len(inliers)
                    best_wall = (a, b, c)
                    best_inliers = inliers.copy()
            
            # 如果找到有效墙面
            if best_wall and len(best_inliers) >= self.min_wall_points:
                wall_info = {
                    'line': best_wall,
                    'points': best_inliers,
                    'point_count': len(best_inliers),
                    'id': wall_idx
                }
                walls.append(wall_info)
                
                print(f"检测到墙面 {wall_idx}: {len(best_inliers)} 个点")
                
                # 从剩余点中移除已识别的墙面点
                remaining_points = [p for p in remaining_points if p not in best_inliers]
        
        return walls
    
    def _validate_walls(self, walls, all_points):
        """验证检测到的墙面"""
        valid_walls = []
        
        for wall in walls:
            a, b, c = wall['line']
            points = wall['points']
            
            if len(points) < self.min_wall_points:
                continue
            
            # 计算墙面的方向角
            wall_angle = math.degrees(math.atan2(-a, -b)) % 180
            
            # 检查是否接近水平或垂直（期望的墙面方向）
            # 但对于平行四边形，可能需要更宽松的角度判断
            angle_diff_horizontal = min(abs(wall_angle), abs(wall_angle - 180))
            angle_diff_vertical = abs(wall_angle - 90)
            angle_diff_diagonal1 = min(abs(wall_angle - 45), abs(wall_angle - 135))
            angle_diff_diagonal2 = min(abs(wall_angle - 225), abs(wall_angle - 315))
            
            # 接受水平、垂直或斜向的墙面（适应平行四边形）
            if (angle_diff_horizontal <= self.angle_tolerance or 
                angle_diff_vertical <= self.angle_tolerance or
                angle_diff_diagonal1 <= self.angle_tolerance or
                angle_diff_diagonal2 <= self.angle_tolerance):
                
                wall['angle'] = wall_angle
                valid_walls.append(wall)
                print(f"验证墙面 {wall['id']}: 角度={wall_angle:.1f}°")
        
        return valid_walls
    
    def _filter_points_by_walls(self, points, walls):
        """根据检测到的墙面过滤场地内的点"""
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
            
            if not is_wall_point and min_wall_distance > self.wall_distance_threshold * 2:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 场地点={len(field_points)}")
        return field_points
    
    def update_wall_detection_params(self, **kwargs):
        """动态更新墙面检测参数"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
                if key in BOUNDARY_CONFIG:
                    BOUNDARY_CONFIG[key] = value
        print(f"墙面检测参数已更新: {kwargs}")


class StatisticalBoundaryDetector:
    """统计边界检测器 - 作为几何检测的备选方案"""
    
    def __init__(self):
        self.min_distance_threshold = 200   # 最小有效距离(mm)
        self.max_distance_threshold = 5000  # 最大有效距离(mm)
        self.boundary_change_threshold = BOUNDARY_CONFIG['change_threshold']
        self.smoothing_window = BOUNDARY_CONFIG['smoothing_window']
        self.outlier_tolerance = BOUNDARY_CONFIG['outlier_tolerance']
        self.boundary_percentile = BOUNDARY_CONFIG['boundary_percentile']
        self.min_continuity_points = BOUNDARY_CONFIG['min_continuity_points']
        self.distance_variance_threshold = BOUNDARY_CONFIG['distance_variance_threshold']
    
    def detect_statistical_boundary(self, scan_data):
        """统计边界检测算法"""
        print("使用统计边界检测算法...")
        
        valid_points = []
        distances = []
        
        # 收集有效点
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if self.min_distance_threshold < distance < self.max_distance_threshold:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                valid_points.append((x, y, angle, distance))
                distances.append(distance)
        
        print(f"统计检测收集到有效点数: {len(valid_points)}")
        
        if len(valid_points) < 10:
            return valid_points
        
        # 使用更宽松的边界检测
        field_points = []
        
        # 计算全局距离统计
        distances_array = np.array(distances)
        median_distance = np.median(distances_array)
        std_distance = np.std(distances_array)
        q25 = np.percentile(distances_array, 25)
        q75 = np.percentile(distances_array, 75)
        
        print(f"距离统计: 中位数={median_distance:.0f}, 标准差={std_distance:.0f}, Q25={q25:.0f}, Q75={q75:.0f}")
        
        # 动态阈值：更接近中位数的点更可能是场地内的点
        # 使用四分位数范围来确定边界
        threshold_distance = q75 + (q75 - q25) * 0.3  # 更宽松的阈值
        
        for i, (x, y, angle, distance) in enumerate(valid_points):
            # 使用更宽松的条件
            if distance <= threshold_distance:
                field_points.append((x, y, angle, distance))
        
        print(f"统计检测识别到 {len(field_points)} 个场地内点 (阈值: {threshold_distance:.0f}mm)")
        return field_points


class TargetClusterAnalyzer:
    """目标聚类分析器"""
    
    def __init__(self):
        # 聚类配置 - 使用全局配置
        self.clustering_eps = CLUSTERING_CONFIG['eps']
        self.clustering_min_samples = CLUSTERING_CONFIG['min_samples']
        self.target_size_range = (CLUSTERING_CONFIG['target_size_min'], CLUSTERING_CONFIG['target_size_max'])
        self.min_cluster_points = CLUSTERING_CONFIG['min_cluster_points']
        self.density_threshold = CLUSTERING_CONFIG['density_threshold']
        self.confidence_weight_points = CLUSTERING_CONFIG['confidence_weight_points']
        self.confidence_weight_density = CLUSTERING_CONFIG['confidence_weight_density']
        self.max_clusters = CLUSTERING_CONFIG['max_clusters']
        self.outlier_filter = CLUSTERING_CONFIG['outlier_filter']
        self.outlier_threshold = CLUSTERING_CONFIG['outlier_threshold']
    
    def cluster_targets(self, field_points):
        """优化的目标聚类分析"""
        if len(field_points) < self.min_cluster_points:
            return []
            
        # 提取坐标进行聚类
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        # 异常值过滤
        if self.outlier_filter and len(coordinates) > 5:
            coordinates = self._filter_outliers(coordinates)
            if len(coordinates) < self.min_cluster_points:
                return []
        
        # 使用全局配置的DBSCAN参数
        clustering = DBSCAN(
            eps=self.clustering_eps,
            min_samples=self.clustering_min_samples
        ).fit(coordinates)
        
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:  # 跳过噪声点
                continue
                
            cluster_indices = [i for i in range(len(coordinates)) if labels[i] == label]
            cluster_points = [field_points[i] for i in cluster_indices if i < len(field_points)]
            
            if len(cluster_points) < self.min_cluster_points:
                continue
            
            # 计算聚类的尺寸和特征
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range)
            
            # 计算聚类密度
            cluster_area = x_range * y_range if x_range > 0 and y_range > 0 else 1
            density = len(cluster_points) / cluster_area * 1000  # 密度归一化
            
            # 使用全局配置的尺寸筛选条件
            if (self.target_size_range[0] <= cluster_size <= self.target_size_range[1] or 
                (cluster_size < self.target_size_range[0] and density > self.density_threshold)):
                
                # 计算聚类中心
                center_x = np.mean(cluster_coords[:, 0])
                center_y = np.mean(cluster_coords[:, 1])
                
                # 计算角度和距离
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                # 使用全局配置的权重计算置信度
                points_score = min(1.0, len(cluster_points) / 10.0)
                density_score = min(1.0, density / 2.0)
                confidence = (self.confidence_weight_points * points_score + 
                             self.confidence_weight_density * density_score)
                
                clusters.append({
                    'angle': target_angle,
                    'distance': target_distance,
                    'size': cluster_size,
                    'points': cluster_points,
                    'center': (center_x, center_y),
                    'confidence': confidence,
                    'density': density,
                    'point_count': len(cluster_points)
                })
        
        # 限制聚类数量并按置信度排序
        clusters.sort(key=lambda x: x['confidence'], reverse=True)
        clusters = clusters[:self.max_clusters]
        
        return clusters
    
    def _filter_outliers(self, coordinates):
        """过滤异常值点"""
        if len(coordinates) < 5:
            return coordinates
            
        # 计算距离原点的距离
        distances = np.sqrt(coordinates[:, 0]**2 + coordinates[:, 1]**2)
        
        # 使用标准差方法过滤异常值
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)
        
        # 保留在合理范围内的点
        valid_mask = np.abs(distances - mean_dist) <= self.outlier_threshold * std_dist
        
        return coordinates[valid_mask]
    
    def update_clustering_params(self, **kwargs):
        """动态更新聚类参数"""
        for key, value in kwargs.items():
            if hasattr(self, f'clustering_{key}'):
                setattr(self, f'clustering_{key}', value)
                CLUSTERING_CONFIG[key] = value
            elif key in ['target_size_min', 'target_size_max']:
                if key == 'target_size_min':
                    self.target_size_range = (value, self.target_size_range[1])
                    CLUSTERING_CONFIG['target_size_min'] = value
                else:
                    self.target_size_range = (self.target_size_range[0], value)
                    CLUSTERING_CONFIG['target_size_max'] = value
            elif hasattr(self, key):
                setattr(self, key, value)
                CLUSTERING_CONFIG[key] = value
        
        print(f"聚类参数已更新: {kwargs}")


class TargetSelector:
    """目标选择器 - 从多个候选目标中选择最佳目标"""
    
    def __init__(self):
        self.last_target_angle = None
        self.target_tracking_threshold = 30  # 目标跟踪角度阈值
        self.confidence_threshold = 0.3      # 最低置信度阈值
        self.distance_weight = 0.3           # 距离权重
        self.confidence_weight = 0.7         # 置信度权重
    
    def select_best_target(self, clusters):
        """选择最佳目标"""
        if not clusters:
            return None
        
        # 过滤掉置信度过低的目标
        valid_clusters = [c for c in clusters if c['confidence'] >= self.confidence_threshold]
        
        if not valid_clusters:
            return None
        
        # 如果有历史目标，优先考虑连续性
        if self.last_target_angle is not None:
            for cluster in valid_clusters:
                angle_diff = abs(cluster['angle'] - self.last_target_angle)
                if angle_diff > 180:
                    angle_diff = 360 - angle_diff
                
                if angle_diff <= self.target_tracking_threshold:
                    self.last_target_angle = cluster['angle']
                    return cluster
        
        # 没有连续目标，选择综合评分最高的
        best_target = None
        best_score = -1
        
        for cluster in valid_clusters:
            # 综合评分：置信度 + 距离因子
            distance_factor = max(0, 1 - cluster['distance'] / 3000)  # 距离越近分数越高
            score = (self.confidence_weight * cluster['confidence'] + 
                    self.distance_weight * distance_factor)
            
            if score > best_score:
                best_score = score
                best_target = cluster
        
        if best_target:
            self.last_target_angle = best_target['angle']
        
        return best_target
    
    def reset_tracking(self):
        """重置目标跟踪"""
        self.last_target_angle = None


class TargetDetector:
    """改进的目标检测器，集成几何和统计检测方法"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.min_distance_threshold = 200   # 最小有效距离(mm)
        self.max_distance_threshold = 5000  # 最大有效距离(mm)
        
        # 检测方法选择
        self.use_geometric_detection = BOUNDARY_CONFIG['use_geometric_detection']
        
        # 创建子组件
        self.boundary_detector = BoundaryDetector()
        self.statistical_detector = StatisticalBoundaryDetector()
        self.cluster_analyzer = TargetClusterAnalyzer()
        self.target_selector = TargetSelector()
        
        # 性能统计
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'geometric_detections': 0,
            'statistical_detections': 0,
            'average_field_points': 0,
            'average_clusters': 0
        }
        
    def detect_field_boundary(self, scan_data):
        """场地边界检测主函数"""
        self.detection_stats['total_detections'] += 1
        
        if self.use_geometric_detection:
            print("使用几何形状检测算法...")
            # 使用几何形状检测
            field_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
            
            if len(field_points) > 20:  # 如果几何检测成功
                print(f"几何检测成功，识别到 {len(field_points)} 个场地内点")
                self.detection_stats['geometric_detections'] += 1
                self.detection_stats['average_field_points'] = (
                    (self.detection_stats['average_field_points'] * (self.detection_stats['total_detections'] - 1) + len(field_points)) / 
                    self.detection_stats['total_detections']
                )
                return field_points
            else:
                print("几何检测失败，回退到统计方法")
        
        # 回退到统计方法
        field_points = self.statistical_detector.detect_statistical_boundary(scan_data)
        self.detection_stats['statistical_detections'] += 1
        self.detection_stats['average_field_points'] = (
            (self.detection_stats['average_field_points'] * (self.detection_stats['total_detections'] - 1) + len(field_points)) / 
            self.detection_stats['total_detections']
        )
        return field_points
        
    def cluster_targets(self, field_points):
        """目标聚类分析"""
        clusters = self.cluster_analyzer.cluster_targets(field_points)
        self.detection_stats['average_clusters'] = (
            (self.detection_stats['average_clusters'] * (self.detection_stats['total_detections'] - 1) + len(clusters)) / 
            self.detection_stats['total_detections']
        )
        return clusters
    
    def find_target(self, scan_data):
        """主要的目标检测函数"""
        # 检测场地边界
        field_points = self.detect_field_boundary(scan_data)
        
        # 聚类分析
        clusters = self.cluster_targets(field_points)
        
        # 选择最佳目标
        best_target = self.target_selector.select_best_target(clusters)
        
        if best_target:
            self.detection_stats['successful_detections'] += 1
            return best_target['angle'], best_target['distance'], best_target
        
        return None, None, None
    
    def find_all_targets(self, scan_data):
        """检测所有目标"""
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        return clusters
    
    def update_detection_method(self, use_geometric=True):
        """更新检测方法"""
        self.use_geometric_detection = use_geometric
        BOUNDARY_CONFIG['use_geometric_detection'] = use_geometric
        method_text = "几何检测" if use_geometric else "统计检测"
        print(f"边界检测方法切换为: {method_text}")
    
    def update_boundary_params(self, **kwargs):
        """更新边界检测参数"""
        self.boundary_detector.update_wall_detection_params(**kwargs)
        
        # 同时更新统计检测器的参数
        for key, value in kwargs.items():
            if hasattr(self.statistical_detector, key):
                setattr(self.statistical_detector, key, value)
    
    def update_clustering_params(self, **kwargs):
        """更新聚类参数"""
        self.cluster_analyzer.update_clustering_params(**kwargs)
    
    def update_selection_params(self, **kwargs):
        """更新目标选择参数"""
        for key, value in kwargs.items():
            if hasattr(self.target_selector, key):
                setattr(self.target_selector, key, value)
        print(f"目标选择参数已更新: {kwargs}")
    
    def reset_target_tracking(self):
        """重置目标跟踪"""
        self.target_selector.reset_tracking()
    
    def get_detection_stats(self):
        """获取检测统计信息"""
        stats = self.detection_stats.copy()
        if stats['total_detections'] > 0:
            stats['success_rate'] = stats['successful_detections'] / stats['total_detections']
            stats['geometric_rate'] = stats['geometric_detections'] / stats['total_detections']
            stats['statistical_rate'] = stats['statistical_detections'] / stats['total_detections']
        else:
            stats['success_rate'] = 0
            stats['geometric_rate'] = 0 
            stats['statistical_rate'] = 0
        return stats
    
    def print_detection_stats(self):
        """打印检测统计信息"""
        stats = self.get_detection_stats()
        print("\n=== 目标检测统计信息 ===")
        print(f"总检测次数: {stats['total_detections']}")
        print(f"成功检测次数: {stats['successful_detections']}")
        print(f"成功率: {stats['success_rate']:.2%}")
        print(f"几何检测使用率: {stats['geometric_rate']:.2%}")
        print(f"统计检测使用率: {stats['statistical_rate']:.2%}")
        print(f"平均场地点数: {stats['average_field_points']:.1f}")
        print(f"平均聚类数: {stats['average_clusters']:.1f}")
        print("========================\n")
    
    def validate_scan_data(self, scan_data):
        """验证扫描数据的有效性"""
        if not scan_data:
            return False, "扫描数据为空"
        
        valid_points = 0
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if self.min_distance_threshold < distance < self.max_distance_threshold:
                valid_points += 1
        
        if valid_points < 50:
            return False, f"有效点数不足: {valid_points}/50"
        
        return True, f"扫描数据有效，包含 {valid_points} 个有效点"


# 工厂函数和便利函数
def create_target_detector(config=None):
    """创建目标检测器实例"""
    detector = TargetDetector()
    
    if config:
        if 'boundary' in config:
            detector.update_boundary_params(**config['boundary'])
        if 'clustering' in config:
            detector.update_clustering_params(**config['clustering'])
        if 'selection' in config:
            detector.update_selection_params(**config['selection'])
    
    return detector


def get_default_config():
    """获取默认配置"""
    return {
        'boundary': BOUNDARY_CONFIG.copy(),
        'clustering': CLUSTERING_CONFIG.copy(),
        'selection': {
            'confidence_threshold': 0.3,
            'distance_weight': 0.3,
            'confidence_weight': 0.7,
            'target_tracking_threshold': 30
        }
    }


def update_global_config(boundary_config=None, clustering_config=None):
    """更新全局配置"""
    if boundary_config:
        BOUNDARY_CONFIG.update(boundary_config)
    if clustering_config:
        CLUSTERING_CONFIG.update(clustering_config)
    print("全局配置已更新")


# 测试和调试函数
def test_target_detector_with_mock_data():
    """使用模拟数据测试目标检测器"""
    detector = create_target_detector()
    
    # 生成模拟雷达数据
    mock_data = {}
    
    # 添加一些墙面点
    for angle in range(0, 90):
        mock_data[angle] = (3000, 100)  # 前方墙面
    for angle in range(90, 180):
        mock_data[angle] = (2000, 100)  # 右侧墙面
    for angle in range(180, 270):
        mock_data[angle] = (3000, 100)  # 后方墙面
    for angle in range(270, 360):
        mock_data[angle] = (2000, 100)  # 左侧墙面
    
    # 添加一些目标点
    for angle in range(45, 55):
        mock_data[angle] = (1500, 80)  # 目标1
    for angle in range(135, 145):
        mock_data[angle] = (1200, 90)  # 目标2
    
    # 测试检测
    angle, distance, target_info = detector.find_target(mock_data)
    
    if angle is not None:
        print(f"检测到目标: 角度={angle:.1f}°, 距离={distance:.0f}mm")
        print(f"目标置信度: {target_info['confidence']:.2f}")
    else:
        print("未检测到目标")
    
    # 打印统计信息
    detector.print_detection_stats()
    
    return detector


if __name__ == '__main__':
    # 库文件测试
    print("Target Detector Library Test")
    print("============================")
    
    # 测试目标检测器
    test_detector = test_target_detector_with_mock_data()
    
    # 显示配置信息
    print("\n当前配置:")
    print("边界检测配置:", BOUNDARY_CONFIG)
    print("聚类配置:", CLUSTERING_CONFIG)
    
    print("\n目标检测库加载完成!")