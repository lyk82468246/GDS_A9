# robot_config.py
"""
机器人配置管理模块
"""

# 边界检测配置 - 与BoundaryDetector类匹配
BOUNDARY_CONFIG = {
    # 统计检测参数
    'statistical_distance_threshold': 200,
    'cluster_distance_threshold': 150,
    'min_distance_change': 100,
    
    # 墙面检测参数
'expected_wall_distance': 2000,
'wall_distance_tolerance': 300,
'wall_distance_threshold': 100,
'wall_exclusion_distance': 400,
'min_wall_points': 15,

# 角度相关参数
'angle_tolerance': 15,
'angle_step': 1,
'angle_window': 3,

# 目标检测参数
'min_target_points': 5,
'max_target_distance': 3000,
'min_target_distance': 100,
'target_size_threshold': 50,

# 噪声过滤参数
'noise_filter_threshold': 100,

# 边界检测阈值
'boundary_distance_jump_threshold': 300,
'consecutive_boundary_points': 3,
}