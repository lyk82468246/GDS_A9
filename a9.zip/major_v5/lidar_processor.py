import serial
import threading
import bisect
import time
import math
import numpy as np

class EnhancedLidarProcessor:
    """增强的激光雷达数据处理器，提供更准确和密集的扫描数据"""
    
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.port = port
        self.baudrate = baudrate
        self.serial = None
        self.running = False
        self.data_thread = None
        self.lock = threading.Lock()
        
        # 存储最近的扫描数据，格式为 {角度: 距离}
        self.current_scan = {}
        
        # 初始化串口连接
        self._init_serial()
    
    def _init_serial(self):
        """初始化串口连接"""
        try:
            self.serial = serial.Serial(self.port, self.baudrate, timeout=1)
            time.sleep(2)  # 等待串口稳定
            print(f"成功连接到激光雷达: {self.port}")
        except Exception as e:
            print(f"无法连接到激光雷达: {e}")
    
    def start(self):
        """启动数据处理线程"""
        if self.running:
            return
        
        self.running = True
        self.data_thread = threading.Thread(target=self._process_data, daemon=True)
        self.data_thread.start()
        print("激光雷达数据处理已启动")
    
    def stop(self):
        """停止数据处理线程"""
        self.running = False
        if self.data_thread:
            self.data_thread.join(timeout=1.0)
        if self.serial and self.serial.is_open:
            self.serial.close()
        print("激光雷达数据处理已停止")
    
    def _parse_frame(self, data):
        """解析激光雷达数据帧
        
        Args:
            data: 原始字节数据
        
        Returns:
            解析后的角度和距离数据列表
        """
        if len(data) < 9:  # 最小帧长度
            return []
        
        points = []
        index = 0
        
        while index < len(data) - 9:
            # 检查帧头
            if data[index] == 0x59 and data[index+1] == 0x59:
                # 帧头找到，解析数据
                distance = (data[index+3] << 8) | data[index+2]
                angle = ((data[index+5] << 8) | data[index+4]) / 100.0
                confidence = data[index+6]
                
                # 过滤低置信度点
                if confidence > 10:
                    points.append((angle, distance))
                
                # 移动到下一帧
                index += 9
            else:
                # 不是帧头，继续寻找
                index += 1
        
        return points
    
    def _process_data(self):
        """处理串口数据的主循环"""
        buffer = bytearray()
        
        while self.running:
            try:
                if not self.serial or not self.serial.is_open:
                    self._init_serial()
                    time.sleep(1)
                    continue
                
                # 读取可用数据
                available = self.serial.in_waiting
                if available > 0:
                    data = self.serial.read(available)
                    buffer.extend(data)
                    
                    # 查找帧尾
                    frame_end = buffer.find(b'\x59\x59', 1)
                    while frame_end != -1:
                        # 提取完整帧
                        frame = buffer[:frame_end+2]
                        buffer = buffer[frame_end+2:]
                        
                        # 解析帧数据
                        points = self._parse_frame(frame)
                        
                        # 更新扫描数据
                        with self.lock:
                            for angle, distance in points:
                                self.current_scan[angle] = distance
                        
                        # 查找下一帧尾
                        frame_end = buffer.find(b'\x59\x59', 1)
            except Exception as e:
                print(f"数据处理错误: {e}")
                time.sleep(0.1)
    
    @property
    def scan_data(self):
        """获取当前的扫描数据"""
        with self.lock:
            # 返回扫描数据的副本
            return self.current_scan.copy()    