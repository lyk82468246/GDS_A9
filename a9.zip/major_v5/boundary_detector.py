# boundary_detector.py
import numpy as np
from sklearn.cluster import DBSCAN
import math

class EnhancedBoundaryDetector:
    """基于几何形状的场地边界检测器"""
    
    def __init__(self, config=None):
        # 使用默认配置或用户提供的配置
        self.config = config or {
            'change_threshold': 150,
            'smoothing_window': 7,
            'outlier_tolerance': 0.3,
            'boundary_percentile': 0.4,
            'min_continuity_points': 3,
            'distance_variance_threshold': 200,
            'use_geometric_detection': True,
            'wall_distance_threshold': 80,
            'min_wall_points': 15,
            'angle_tolerance': 15,
        }
        self.detected_walls = []
        self.field_boundary = []
        self.boundary_points = []
    
    def detect_walls_by_geometry(self, scan_data):
        """基于几何形状检测墙面边界
        
        Args:
            scan_data: 激光雷达扫描数据，格式为 {角度: 距离}
        
        Returns:
            tuple: (墙面列表, 边界点列表)
        """
        # 将扫描数据转换为点坐标
        points = [(math.radians(angle), distance) 
                  for angle, distance in scan_data.items() 
                  if distance > 0]
        
        # 转换为笛卡尔坐标
        cartesian_points = np.array([
            [distance * math.cos(angle), distance * math.sin(angle)]
            for angle, distance in points
        ])
        
        # 使用RANSAC算法检测墙面
        walls = self._detect_walls_ransac(cartesian_points)
        
        # 验证和过滤墙面
        valid_walls = self._validate_walls(walls, cartesian_points)
        
        # 提取边界点
        boundary_points = self._filter_points_by_walls(cartesian_points, valid_walls)
        
        self.detected_walls = valid_walls
        self.boundary_points = boundary_points
        
        return valid_walls, boundary_points
    
    def _detect_walls_ransac(self, points, max_walls=4):
        """使用RANSAC算法检测墙面直线
        
        Args:
            points: 点云数据
            max_walls: 最多检测的墙面数量
        
        Returns:
            list: 检测到的墙面列表，每个墙面表示为 (起点, 终点, 方向角)
        """
        walls = []
        remaining_points = points.copy()
        
        for _ in range(max_walls):
            if len(remaining_points) < self.config['min_wall_points']:
                break
                
            # RANSAC参数
            max_iterations = 100
            distance_threshold = self.config['wall_distance_threshold']
            best_inliers = []
            best_line = None
            
            for _ in range(max_iterations):
                # 随机选择两个点定义一条直线
                idx1, idx2 = np.random.choice(len(remaining_points), 2, replace=False)
                p1, p2 = remaining_points[idx1], remaining_points[idx2]
                
                # 计算直线参数: ax + by + c = 0
                a = p2[1] - p1[1]
                b = p1[0] - p2[0]
                c = p2[0] * p1[1] - p1[0] * p2[1]
                norm = np.sqrt(a**2 + b**2)
                
                if norm == 0:
                    continue
                    
                # 计算所有点到直线的距离
                distances = np.abs(a * remaining_points[:, 0] + b * remaining_points[:, 1] + c) / norm
                
                # 收集内点
                inliers = remaining_points[distances < distance_threshold]
                
                # 更新最佳模型
                if len(inliers) > len(best_inliers):
                    best_inliers = inliers
                    best_line = (p1, p2)
            
            # 如果找到了足够的内点，将其视为墙面
            if len(best_inliers) >= self.config['min_wall_points']:
                # 计算墙面方向角
                dx = best_line[1][0] - best_line[0][0]
                dy = best_line[1][1] - best_line[0][1]
                angle = math.degrees(math.atan2(dy, dx))
                
                # 计算墙面的起点和终点
                x_min, y_min = np.min(best_inliers, axis=0)
                x_max, y_max = np.max(best_inliers, axis=0)
                
                walls.append(((x_min, y_min), (x_max, y_max), angle))
                
                # 从剩余点中移除已被分配到墙面的点
                remaining_points_mask = np.ones(len(remaining_points), dtype=bool)
                for inlier in best_inliers:
                    distances = np.sqrt(np.sum((remaining_points - inlier)**2, axis=1))
                    closest_idx = np.argmin(distances)
                    if distances[closest_idx] < 1e-3:
                        remaining_points_mask[closest_idx] = False
                
                remaining_points = remaining_points[remaining_points_mask]
        
        return walls
    
    def _validate_walls(self, walls, all_points):
        """验证检测到的墙面
        
        Args:
            walls: 待验证的墙面列表
            all_points: 所有点云数据
        
        Returns:
            list: 验证后的墙面列表
        """
        valid_walls = []
        
        # 检查墙面之间的角度关系（寻找平行和垂直墙面）
        for wall in walls:
            p1, p2, angle = wall
            
            # 规范化角度到 [0, 180)
            norm_angle = angle % 180
            
            # 检查墙面是否大致水平或垂直
            is_horizontal = abs(norm_angle % 90) < self.config['angle_tolerance']
            is_vertical = abs((norm_angle - 45) % 90) < self.config['angle_tolerance']
            
            if is_horizontal or is_vertical:
                valid_walls.append(wall)
        
        return valid_walls
    
    def _filter_points_by_walls(self, points, walls):
        """根据检测到的墙面过滤场地内的点
        
        Args:
            points: 所有点云数据
            walls: 墙面列表
        
        Returns:
            list: 位于场地边界内的点
        """
        if not walls:
            return points
            
        boundary_points = []
        
        # 为简化示例，这里只考虑点是否在所有墙面的"内部"
        # 实际应用中可能需要更复杂的多边形内外判断算法
        for point in points:
            x, y = point
            is_inside = True
            
            for wall in walls:
                p1, p2, angle = wall
                a = p2[1] - p1[1]
                b = p1[0] - p2[0]
                c = p2[0] * p1[1] - p1[0] * p2[1]
                
                # 计算点到直线的有符号距离
                distance = (a * x + b * y + c) / np.sqrt(a**2 + b**2)
                
                # 假设墙面外侧的点距离为负
                if distance < -self.config['wall_distance_threshold']:
                    is_inside = False
                    break
            
            if is_inside:
                boundary_points.append(point)
        
        return np.array(boundary_points)
    
    def get_field_boundary(self):
        """获取检测到的场地边界"""
        return self.field_boundary
    
    def update_config(self, config):
        """更新检测器配置"""
        self.config.update(config)