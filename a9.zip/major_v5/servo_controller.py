from adafruit_servokit import ServoKit

class ServoController:
    """舵机云台控制器"""
    
    def __init__(self):
        # 初始化PCA9685舵机驱动板
        self.kit = ServoKit(channels=16)
        
        # 设置舵机通道
        self.pan_channel = 0   # 水平旋转舵机通道
        self.tilt_channel = 1  # 垂直旋转舵机通道
        
        # 设置舵机角度范围
        self.pan_min_angle = 0
        self.pan_max_angle = 180
        self.pan_center_angle = 90
        
        self.tilt_min_angle = 30
        self.tilt_max_angle = 150
        self.tilt_center_angle = 90
        
        # 初始化舵机位置
        self.set_pan_angle(self.pan_center_angle)
        self.set_tilt_angle(self.tilt_center_angle)
    
    def set_pan_angle(self, angle):
        """设置水平旋转角度
        
        Args:
            angle: 目标角度（0-180度）
        """
        # 限制角度范围
        angle = max(self.pan_min_angle, min(angle, self.pan_max_angle))
        self.kit.servo[self.pan_channel].angle = angle
    
    def set_tilt_angle(self, angle):
        """设置垂直旋转角度
        
        Args:
            angle: 目标角度（0-180度）
        """
        # 限制角度范围
        angle = max(self.tilt_min_angle, min(angle, self.tilt_max_angle))
        self.kit.servo[self.tilt_channel].angle = angle
    
    def set_horizontal_angle(self, relative_angle):
        """设置相对水平角度（从中心点开始）
        
        Args:
            relative_angle: 相对角度（-90到90度）
        """
        # 计算绝对角度
        absolute_angle = self.pan_center_angle + relative_angle
        self.set_pan_angle(absolute_angle)
    
    def set_vertical_angle(self, relative_angle):
        """设置相对垂直角度（从中心点开始）
        
        Args:
            relative_angle: 相对角度（-60到60度）
        """
        # 计算绝对角度
        absolute_angle = self.tilt_center_angle + relative_angle
        self.set_tilt_angle(absolute_angle)
    
    def cleanup(self):
        """清理资源，将舵机复位到中心位置"""
        self.set_pan_angle(self.pan_center_angle)
        self.set_tilt_angle(self.tilt_center_angle)    