import numpy as np
from sklearn.cluster import DBSCAN

# 全局配置参数
BOUNDARY_CONFIG = {
    'change_threshold': 150,
    'smoothing_window': 7,
    'outlier_tolerance': 0.3,
    'boundary_percentile': 0.4,
    'min_continuity_points': 3,
    'distance_variance_threshold': 200,
    'use_geometric_detection': True,
    'wall_distance_threshold': 80,
    'min_wall_points': 15,
    'angle_tolerance': 15,
}

CLUSTERING_CONFIG = {
    'eps': 100,
    'min_samples': 3,
    'target_size_min': 80,
    'target_size_max': 250,
    'min_cluster_points': 3,
    'density_threshold': 0.7,
    'confidence_weight_points': 0.4,
    'confidence_weight_density': 0.6,
    'max_clusters': 5,
    'outlier_filter': True,
    'outlier_threshold': 2.0,
}

class ImprovedTargetDetector:
    """改进的目标检测器，集成几何和统计检测方法"""
    
    def __init__(self):
        self.boundary_detector = EnhancedBoundaryDetector()
    
    def detect_field_boundary(self, scan_data):
        """检测场地边界
        
        Args:
            scan_data: 激光雷达扫描数据
            
        Returns:
            边界点列表
        """
        if BOUNDARY_CONFIG['use_geometric_detection']:
            # 尝试几何边界检测
            walls = self.boundary_detector.detect_walls_by_geometry(scan_data)
            if walls:
                return walls
        
        # 回退到统计边界检测
        return self._statistical_boundary_detection(scan_data)
    
    def _statistical_boundary_detection(self, scan_data):
        """统计边界检测方法
        
        Args:
            scan_data: 激光雷达扫描数据
            
        Returns:
            边界点列表
        """
        # 将扫描数据转换为点列表
        points = []
        for angle, distance in scan_data.items():
            x = distance * np.cos(np.radians(angle))
            y = distance * np.sin(np.radians(angle))
            points.append((x, y))
        
        if not points:
            return []
        
        # 计算每个点的局部密度
        point_densities = []
        for i, (x, y) in enumerate(points):
            # 计算到其他点的距离
            distances = [np.sqrt((x2 - x)**2 + (y2 - y)**2) for x2, y2 in points]
            # 计算近邻点数量
            density = sum(1 for d in distances if 0 < d < 150)
            point_densities.append(density)
        
        # 计算密度阈值（中位数）
        density_threshold = np.median(point_densities)
        
        # 筛选高密度点作为边界候选
        boundary_candidates = []
        for i, (x, y) in enumerate(points):
            if point_densities[i] >= density_threshold:
                boundary_candidates.append((x, y))
        
        return boundary_candidates
    
    def cluster_targets(self, field_points):
        """对场地内的点进行聚类分析，识别潜在目标
        
        Args:
            field_points: 场地内的点列表
            
        Returns:
            聚类结果列表，每个聚类包含其中心位置和相关统计信息
        """
        if len(field_points) < CLUSTERING_CONFIG['min_samples']:
            return []
        
        # 转换为numpy数组
        X = np.array(field_points)
        
        # 应用DBSCAN聚类
        db = DBSCAN(eps=CLUSTERING_CONFIG['eps'], min_samples=CLUSTERING_CONFIG['min_samples']).fit(X)
        core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
        core_samples_mask[db.core_sample_indices_] = True
        labels = db.labels_
        
        # 过滤噪声点
        clusters = {}
        for i, label in enumerate(labels):
            if label == -1:  # 噪声点
                continue
            
            if label not in clusters:
                clusters[label] = []
            
            clusters[label].append(field_points[i])
        
        # 评估每个聚类，计算中心和置信度
        result_clusters = []
        for label, points in clusters.items():
            if len(points) < CLUSTERING_CONFIG['min_cluster_points']:
                continue
            
            # 计算聚类中心
            center_x = np.mean([p[0] for p in points])
            center_y = np.mean([p[1] for p in points])
            
            # 计算聚类大小（半径）
            distances = [np.sqrt((p[0] - center_x)**2 + (p[1] - center_y)**2) for p in points]
            cluster_size = np.mean(distances)
            
            # 计算密度
            density = len(points) / (np.pi * cluster_size**2) if cluster_size > 0 else 0
            
            # 计算置信度
            points_confidence = min(1.0, len(points) / 15.0)  # 最多15个点贡献满置信度
            density_confidence = min(1.0, density / CLUSTERING_CONFIG['density_threshold'])
            confidence = (CLUSTERING_CONFIG['confidence_weight_points'] * points_confidence + 
                         CLUSTERING_CONFIG['confidence_weight_density'] * density_confidence)
            
            # 过滤不符合大小要求的聚类
            if (cluster_size < CLUSTERING_CONFIG['target_size_min'] or 
                cluster_size > CLUSTERING_CONFIG['target_size_max']):
                continue
            
            result_clusters.append({
                'center': (center_x, center_y),
                'size': cluster_size,
                'density': density,
                'confidence': confidence,
                'points': points
            })
        
        # 按置信度排序
        result_clusters.sort(key=lambda c: c['confidence'], reverse=True)
        
        # 限制最大聚类数量
        return result_clusters[:CLUSTERING_CONFIG['max_clusters']]
    
    def _filter_outliers(self, coordinates):
        """过滤坐标点中的异常值
        
        Args:
            coordinates: 坐标点列表
            
        Returns:
            过滤后的坐标点列表
        """
        if not coordinates:
            return []
        
        # 计算平均值和标准差
        coords_array = np.array(coordinates)
        mean = np.mean(coords_array, axis=0)
        std = np.std(coords_array, axis=0)
        
        # 过滤异常值
        filtered = []
        for coord in coordinates:
            # 计算每个维度的Z分数
            z_scores = np.abs((coord - mean) / (std + 1e-8))  # 加小量防止除零
            # 如果所有维度的Z分数都小于阈值，则保留该点
            if np.all(z_scores < CLUSTERING_CONFIG['outlier_threshold']):
                filtered.append(coord)
        
        return filtered
    
    def find_target(self, scan_data):
        """寻找最佳目标
        
        Args:
            scan_data: 激光雷达扫描数据
            
        Returns:
            最佳目标的角度和距离，或None
        """
        # 检测场地边界
        boundary_points = self.detect_field_boundary(scan_data)
        
        # 提取边界内的点作为潜在目标
        field_points = []
        for angle, distance in scan_data.items():
            x = distance * np.cos(np.radians(angle))
            y = distance * np.sin(np.radians(angle))
            
            # 简单判断：如果点不在边界点中，则认为是场内点
            # 实际应用中可能需要更复杂的判断
            if (x, y) not in boundary_points:
                field_points.append((x, y))
        
        # 过滤异常值
        if CLUSTERING_CONFIG['outlier_filter']:
            field_points = self._filter_outliers(field_points)
        
        # 对场内点进行聚类
        clusters = self.cluster_targets(field_points)
        
        if not clusters:
            return None
        
        # 选择置信度最高的聚类作为目标
        best_cluster = clusters[0]
        center_x, center_y = best_cluster['center']
        
        # 计算目标的角度和距离
        target_distance = np.sqrt(center_x**2 + center_y**2)
        target_angle = np.degrees(np.arctan2(center_y, center_x))
        
        return (target_angle, target_distance)
    
    def update_clustering_params(self, **kwargs):
        """更新聚类参数
        
        Args:
            **kwargs: 要更新的参数
        """
        for key, value in kwargs.items():
            if key in CLUSTERING_CONFIG:
                CLUSTERING_CONFIG[key] = value
                print(f"更新聚类参数: {key} = {value}")    