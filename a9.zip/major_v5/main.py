import math
import threading
import time
import tkinter as tk
from tkinter import ttk

from matplotlib import pyplot as plt
import serial
from lidar_processor import EnhancedLidarProcessor
from target_detector import BOUNDARY_CONFIG, ImprovedTargetDetector
from servo_controller import ServoController
from boundary_detector import EnhancedBoundaryDetector
from robot_chassis import MecanumCar
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', base_speed=60):
        # 初始化各模块
        self.lidar = EnhancedLidarProcessor(lidar_port)
        self.boundary_detector = EnhancedBoundaryDetector()
        self.target_detector = ImprovedTargetDetector()
        self.servo = ServoController()
        self.chassis = MecanumCar()
        
        # 系统状态
        self.running = False
        self.detection_method = "geometric"
        self.last_target = None
        
        # 创建GUI
        self.root = tk.Tk()
        self.root.title("Lidar Battle Bot Control Panel")
        self._create_control_widgets(self.root)
        
        # 启动GUI更新循环
        self.root.after(100, self._update_gui_loop)
        
        # 启动触发监听线程
        self.trigger_thread = threading.Thread(target=self._listen_for_trigger, daemon=True)
        self.trigger_thread.start()

    def _create_control_widgets(self, parent):
        # 创建系统状态显示框架
        status_frame = ttk.LabelFrame(parent, text="System Status")
        status_frame.pack(fill="x", padx=10, pady=5)
        
        self.status_label = ttk.Label(status_frame, text="System Stopped", foreground="red")
        self.status_label.pack(side="left", padx=5, pady=5)
        
        self.start_stop_btn = ttk.Button(status_frame, text="Start", command=self._toggle_system)
        self.start_stop_btn.pack(side="right", padx=5, pady=5)
        
        # 创建检测方法选择框架
        method_frame = ttk.LabelFrame(parent, text="Detection Method")
        method_frame.pack(fill="x", padx=10, pady=5)
        
        self.detection_var = tk.StringVar(value="geometric")
        geometric_radio = ttk.Radiobutton(method_frame, text="Geometric", 
                                         variable=self.detection_var, value="geometric",
                                         command=self._on_method_change)
        geometric_radio.pack(side="left", padx=10)
        
        statistical_radio = ttk.Radiobutton(method_frame, text="Statistical", 
                                           variable=self.detection_var, value="statistical",
                                           command=self._on_method_change)
        statistical_radio.pack(side="left", padx=10)
        
        # 创建参数调节框架
        params_frame = ttk.LabelFrame(parent, text="Detection Parameters")
        params_frame.pack(fill="x", padx=10, pady=5)
        
        # 墙面距离阈值
        ttk.Label(params_frame, text="Wall Distance Threshold:").pack(anchor="w", padx=5)
        self.wall_threshold_var = tk.DoubleVar(value=80)
        wall_threshold_scale = ttk.Scale(params_frame, from_=50, to=200, 
                                        variable=self.wall_threshold_var,
                                        command=self._on_wall_threshold_change)
        wall_threshold_scale.pack(fill="x", padx=10)
        self.wall_threshold_label = ttk.Label(params_frame, text=f"{self.wall_threshold_var.get():.0f} mm")
        self.wall_threshold_label.pack(anchor="e", padx=10)
        
        # 最小墙面点数
        ttk.Label(params_frame, text="Minimum Wall Points:").pack(anchor="w", padx=5)
        self.min_points_var = tk.IntVar(value=15)
        min_points_scale = ttk.Scale(params_frame, from_=5, to=30, 
                                    variable=self.min_points_var,
                                    command=self._on_min_points_change)
        min_points_scale.pack(fill="x", padx=10)
        self.min_points_label = ttk.Label(params_frame, text=f"{self.min_points_var.get()} points")
        self.min_points_label.pack(anchor="e", padx=10)
        
        # 创建数据可视化框架
        viz_frame = ttk.LabelFrame(parent, text="Lidar Visualization")
        viz_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # 创建Matplotlib图形
        self.fig, self.ax = plt.subplots(figsize=(6, 5))
        self.canvas = FigureCanvasTkAgg(self.fig, master=viz_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        
        # 初始化图形
        self.ax.set_aspect('equal')
        self.ax.set_xlim(-500, 500)
        self.ax.set_ylim(-500, 500)
        self.ax.set_xlabel('X (mm)')
        self.ax.set_ylabel('Y (mm)')
        self.ax.set_title('Lidar Scan and Target Detection')
        
        # 初始化点集合
        self.scan_points, = self.ax.plot([], [], 'bo', markersize=2, label='Lidar Points')
        self.boundary_points, = self.ax.plot([], [], 'ro', markersize=3, label='Boundary')
        self.target_point, = self.ax.plot([], [], 'go', markersize=8, label='Target')
        self.ax.legend(loc='upper right')

    def _listen_for_trigger(self):
        """监听触发信号，启动或停止系统"""
        try:
            ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
            while True:
                if not self.running:
                    time.sleep(0.1)
                    continue
                
                line = ser.readline().decode('utf-8').strip()
                if line == "FIRE":
                    print("触发信号收到，启动攻击序列")
                    self._initiate_attack()
        except Exception as e:
            print(f"触发监听错误: {e}")

    def _update_gui_loop(self):
        """更新GUI界面的循环"""
        if self.running:
            try:
                # 获取最新的激光雷达数据
                scan_data = self.lidar.scan_data
                
                # 检测边界
                if self.detection_method == "geometric":
                    boundary_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
                else:
                    boundary_points = self.target_detector._statistical_boundary_detection(scan_data)
                
                # 检测目标
                target = self.target_detector.find_target(scan_data)
                self.last_target = target
                
                # 更新图形
                x_values = [math.cos(math.radians(angle)) * dist for angle, dist in scan_data.items()]
                y_values = [math.sin(math.radians(angle)) * dist for angle, dist in scan_data.items()]
                
                self.scan_points.set_data(x_values, y_values)
                
                if boundary_points:
                    bx_values = [point[0] for point in boundary_points]
                    by_values = [point[1] for point in boundary_points]
                    self.boundary_points.set_data(bx_values, by_values)
                else:
                    self.boundary_points.set_data([], [])
                
                if target:
                    tx = math.cos(math.radians(target[0])) * target[1]
                    ty = math.sin(math.radians(target[0])) * target[1]
                    self.target_point.set_data(tx, ty)
                    
                    # 控制舵机指向目标
                    self.servo.set_horizontal_angle(target[0])
                else:
                    self.target_point.set_data([], [])
                
                self.fig.canvas.draw_idle()
                
                # 控制机器人移动
                if target and self.running:
                    self._control_movement(target)
                
            except Exception as e:
                print(f"更新循环错误: {e}")
        
        # 继续更新
        self.root.after(100, self._update_gui_loop)

    def _toggle_system(self):
        """切换系统运行状态"""
        self.running = not self.running
        if self.running:
            self.status_label.config(text="System Running", foreground="green")
            self.start_stop_btn.config(text="Stop")
            print("系统已启动")
        else:
            self.status_label.config(text="System Stopped", foreground="red")
            self.start_stop_btn.config(text="Start")
            self.chassis.stop()
            self.servo.cleanup()
            print("系统已停止")

    def _on_method_change(self):
        """处理检测方法变更"""
        self.detection_method = self.detection_var.get()
        print(f"检测方法已变更为: {self.detection_method}")

    def _on_wall_threshold_change(self, value):
        """处理墙面距离阈值变更"""
        value = float(value)
        self.wall_threshold_var.set(value)
        self.wall_threshold_label.config(text=f"{value:.0f} mm")
        BOUNDARY_CONFIG['wall_distance_threshold'] = value
        print(f"墙面距离阈值已变更为: {value}")

    def _on_min_points_change(self, value):
        """处理最小墙面点数变更"""
        value = int(float(value))  # 转换为整数
        self.min_points_var.set(value)
        self.min_points_label.config(text=f"{value} points")
        BOUNDARY_CONFIG['min_wall_points'] = value
        print(f"最小墙面点数已变更为: {value}")

    def _control_movement(self, target):
        """根据目标位置控制机器人移动"""
        angle, distance = target
        
        # 基本移动逻辑
        if distance > 300:
            # 目标较远，前进
            self.chassis.move_forward(40)
        elif distance < 200:
            # 目标太近，后退
            self.chassis.move_backward(40)
        else:
            # 距离合适，停止
            self.chassis.stop()
        
        # 角度调整
        if angle > 10:
            # 目标在右侧，右转
            self.chassis.turn_right(30)
        elif angle < -10:
            # 目标在左侧，左转
            self.chassis.turn_left(30)

    def _initiate_attack(self):
        """启动攻击序列"""
        if self.last_target:
            angle, distance = self.last_target
            print(f"攻击目标: 角度 {angle}, 距离 {distance}")
            
            # 微调舵机对准目标
            self.servo.set_horizontal_angle(angle)
            time.sleep(0.5)
            
            # 模拟发射过程
            print("准备发射...")
            time.sleep(0.5)
            print("发射!")
            time.sleep(1.0)
            print("攻击完成")
        else:
            print("没有检测到目标，无法攻击")

    def run(self):
        """运行主控制循环"""
        self.root.mainloop()

if __name__ == "__main__":
    # 确保中文显示正常
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
    
    # 创建并运行机器人
    bot = LidarBattleBot()
    bot.run()    