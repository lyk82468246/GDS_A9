import math
import time

# 全局配置常量
BOUNDARY_CONFIG = {
    'statistical_distance_threshold': 200,
    'expected_wall_distance': 2000,
    'wall_distance_tolerance': 300,
    'min_target_distance': 100,
    'max_target_distance': 3000,
    'min_wall_points': 15,
}

class TargetDetector:
    """仅使用几何检测的目标检测器"""
    
    def __init__(self):
        # 边界检测参数
        self.boundary_distance_threshold = BOUNDARY_CONFIG['statistical_distance_threshold']
        self.expected_wall_distance = BOUNDARY_CONFIG['expected_wall_distance']
        self.wall_distance_tolerance = BOUNDARY_CONFIG['wall_distance_tolerance']
        
        self.use_geometric_detection = True  # 默认使用几何检测
        self.use_statistical_detection = True  # 统计检测开关
        
        self.detection_mode = 'hybrid'  # 'geometric', 'statistical', 'hybrid'
        
        # 安全地获取配置参数，提供默认值
        self.boundary_distance_threshold = BOUNDARY_CONFIG.get('statistical_distance_threshold', 200)
        self.cluster_distance_threshold = BOUNDARY_CONFIG.get('cluster_distance_threshold', 150)
        self.min_distance_change = BOUNDARY_CONFIG.get('min_distance_change', 100)
        
        # 统计信息
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }

    def detect_field_boundary(self, scan_data):
        """几何方法检测场地边界"""
        start_time = time.time()
        
        # 使用几何方法检测边界
        boundary_points = self._geometric_boundary_detection(scan_data)
        
        # 记录处理时间
        processing_time = time.time() - start_time
        self.detection_stats['total_detections'] += 1
        if boundary_points:
            self.detection_stats['successful_detections'] += 1
            self.detection_stats['last_detection_time'] = time.time()
        
        return boundary_points

    def _geometric_boundary_detection(self, scan_data):
        """几何边界检测"""
        field_points = []
        
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            
            # 基本有效性检查
            if distance < BOUNDARY_CONFIG['min_target_distance'] or distance > BOUNDARY_CONFIG['max_target_distance']:
                continue
            
            # 检查是否为边界点
            if self._is_boundary_point(angle, distance, scan_data):
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                field_points.append((x, y, angle, distance, intensity))
        
        return field_points

    def _is_boundary_point(self, angle, distance, scan_data):
        """几何方法判断边界点"""
        left_angle = (angle - 1) % 360
        right_angle = (angle + 1) % 360
        
        left_distance, _ = scan_data.get(left_angle, (0, 0))
        right_distance, _ = scan_data.get(right_angle, (0, 0))
        
        # 如果相邻点距离变化过大,可能是边界
        if left_distance > 0 and abs(distance - left_distance) > self.boundary_distance_threshold:
            return True
        if right_distance > 0 and abs(distance - right_distance) > self.boundary_distance_threshold:
            return True
        
        # 检查是否接近预期的墙面距离
        expected_distances = [self.expected_wall_distance, self.expected_wall_distance * 1.414]  # 对角线距离
        for expected in expected_distances:
            if abs(distance - expected) < self.wall_distance_tolerance:
                return True
        
        return False

    def get_detection_statistics(self):
        """获取检测统计信息"""
        success_rate = 0
        if self.detection_stats['total_detections'] > 0:
            success_rate = self.detection_stats['successful_detections'] / self.detection_stats['total_detections'] * 100
        
        return {
            'total_detections': self.detection_stats['total_detections'],
            'successful_detections': self.detection_stats['successful_detections'],
            'success_rate': success_rate,
        }

    def reset_statistics(self):
        """重置统计信息"""
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }