import serial
import threading
import time
import numpy as np

class LidarProcessor:
    """增强的雷达数据处理器,提高数据密度和准确性"""
    
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        # 增加数据缓存用于插值
        self._point_buffer = {}  # 按角度存储多个点
        self._complete_scans = []  # 存储最近的完整扫描
        self.interpolation_density = 2  # 插值密度倍数

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    @property
    def scan_data(self):
        """提供scan_data属性，返回当前扫描数据"""
        return self.get_scan_data()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[:47]
                        checksum = sum(frame_data[:46]) & 0xFF
                        
                        if checksum == frame_data[46]:
                            parsed = self._parse_frame(frame_data)
                            if parsed and parsed['points']:
                                self._update_scan_dict(parsed)
                        
                        buffer = buffer[47:]
                    else:
                        start_index = buffer.find(b'\x54\x2C', 1)
                        if start_index == -1:
                            buffer = buffer[-46:]
                        else:
                            buffer = buffer[start_index:]
                            
            except Exception as e:
                print(f"数据处理错误: {str(e)}")
                time.sleep(0.01)

    def _update_scan_dict(self, parsed_data):
        """更新扫描字典"""
        with self._lock:
            for angle, distance, intensity in parsed_data['points']:
                angle_int = int(angle) % 360
                
                # 存储到点缓存中用于插值
                if angle_int not in self._point_buffer:
                    self._point_buffer[angle_int] = []
                self._point_buffer[angle_int].append((distance, intensity, time.time()))
                
                # 保持缓存大小
                if len(self._point_buffer[angle_int]) > 5:
                    self._point_buffer[angle_int] = self._point_buffer[angle_int][-5:]
                
                # 更新主字典（使用最新值）
                self._scan_dict[angle_int] = (distance, intensity)
                
                # 检测扫描周期
                if not self._scan_started and angle_int == 0:
                    self._scan_started = True
                elif self._scan_started and angle_int == 0:
                    # 完成一轮扫描
                    self._complete_scans.append(dict(self._scan_dict))
                    if len(self._complete_scans) > 3:
                        self._complete_scans = self._complete_scans[-3:]

    def _generate_enhanced_scan_dict(self):
        """增强的扫描字典生成,提高数据密度和准确性"""
        with self._lock:
            enhanced_dict = {}
            
            # 按角度分组处理
            angle_groups = {}
            for angle in range(360):
                if angle in self._point_buffer and self._point_buffer[angle]:
                    # 使用最近的有效数据
                    recent_points = [p for p in self._point_buffer[angle] 
                                   if time.time() - p[2] < 1.0]  # 1秒内的数据
                    if recent_points:
                        # 使用平均值提高准确性
                        avg_distance = sum(p[0] for p in recent_points) / len(recent_points)
                        avg_intensity = sum(p[1] for p in recent_points) / len(recent_points)
                        angle_groups[angle] = (avg_distance, avg_intensity)
                    else:
                        angle_groups[angle] = self._scan_dict.get(angle, (0, 0))
                else:
                    angle_groups[angle] = self._scan_dict.get(angle, (0, 0))
            
            # 生成增强的字典
            for target_angle in range(360):
                if angle_groups[target_angle][0] > 0:
                    enhanced_dict[target_angle] = angle_groups[target_angle]
                else:
                    # 使用高级插值
                    interpolated = self._advanced_interpolate(target_angle, angle_groups)
                    if interpolated:
                        enhanced_dict[target_angle] = interpolated
                    else:
                        enhanced_dict[target_angle] = (0, 0)
            
            return enhanced_dict

    def _advanced_interpolate(self, target_angle, angle_groups):
        """高级插值算法"""
        # 寻找最近的有效点
        valid_points = []
        for offset in range(1, 31):  # 搜索范围±30度
            for direction in [-1, 1]:
                check_angle = (target_angle + direction * offset) % 360
                if angle_groups[check_angle][0] > 0:
                    valid_points.append((check_angle, angle_groups[check_angle]))
                    if len(valid_points) >= 4:
                        break
            if len(valid_points) >= 4:
                break
        
        if len(valid_points) < 2:
            return None
        
        # 计算权重插值
        total_weight = 0
        weighted_distance = 0
        weighted_intensity = 0
        
        for angle, (distance, intensity) in valid_points:
            angle_diff = min(abs(target_angle - angle), 360 - abs(target_angle - angle))
            weight = 1.0 / (angle_diff + 1)  # 距离越近权重越大
            
            total_weight += weight
            weighted_distance += distance * weight
            weighted_intensity += intensity * weight
        
        if total_weight > 0:
            avg_distance = weighted_distance / total_weight
            avg_intensity = weighted_intensity / total_weight
            return (int(avg_distance), int(avg_intensity))
        
        return None

    def get_enhanced_scan_data(self):
        """获取增强的扫描数据"""
        return self._generate_enhanced_scan_dict()

    def get_scan_data(self):
        """获取当前扫描数据"""
        with self._lock:
            return dict(self._scan_dict)

    def get_statistics(self):
        """获取统计信息"""
        return {
            'valid_points': self._valid_point_count,
            'total_points': self._total_point_count,
            'buffer_angles': len([a for a in self._point_buffer if self._point_buffer[a]]),
            'complete_scans': len(self._complete_scans)
        }

    def shutdown(self):
        """关闭雷达连接"""
        self._running = False
        if hasattr(self, '_thread'):
            self._thread.join(timeout=1)
        if hasattr(self, 'ser') and self.ser.is_open:
            self.ser.close()

    def close(self):
        """关闭雷达连接 - 提供close方法的别名"""
        self.shutdown()