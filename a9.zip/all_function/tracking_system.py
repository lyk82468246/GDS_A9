import time
import math
import threading
from collections import defaultdict, deque

class TrackingSystem:
    """目标跟踪系统,集成雷达检测和舵机控制"""
    
    def __init__(self, lidar_processor, servo_controller, target_detector):
        self.lidar = lidar_processor
        self.servo = servo_controller
        self.detector = target_detector
        
        # 跟踪状态
        self.tracking_enabled = False
        self.current_target = None
        self.tracking_thread = None
        self.running = False
        
        # 跟踪参数
        self.track_update_interval = 0.1  # 跟踪更新间隔(秒)
        self.target_lost_timeout = 2.0    # 目标丢失超时(秒)
        self.min_tracking_confidence = 60  # 最小跟踪置信度
        
        # 跟踪历史和预测
        self.target_history = deque(maxlen=10)
        self.prediction_enabled = True
        
        # 统计信息
        self.tracking_stats = {
            'total_tracks': 0,
            'successful_tracks': 0,
            'lost_tracks': 0,
            'tracking_time': 0,
            'last_target_time': 0
        }
        
        # 扫描模式参数
        self.scan_mode = False
        self.scan_range = 180  # 扫描范围
        self.scan_speed = 30   # 扫描速度(度/秒)
        self.scan_direction = 1  # 扫描方向

    def start_tracking(self):
        """开始目标跟踪"""
        if not self.tracking_enabled:
            self.tracking_enabled = True
            self.running = True
            self.tracking_thread = threading.Thread(target=self._tracking_loop)
            self.tracking_thread.daemon = True
            self.tracking_thread.start()
            print("目标跟踪系统已启动")
            return True
        return False

    def stop_tracking(self):
        """停止目标跟踪"""
        if self.tracking_enabled:
            self.tracking_enabled = False
            self.running = False
            if self.tracking_thread:
                self.tracking_thread.join(timeout=1)
            self.servo.center_servos()
            print("目标跟踪系统已停止")
            return True
        return False

    def _tracking_loop(self):
        """主跟踪循环"""
        last_target_time = 0
        
        while self.running and self.tracking_enabled:
            try:
                start_time = time.time()
                
                # 获取雷达数据
                scan_data = self.lidar.get_enhanced_scan_data()
                
                # 检测目标
                target = self.detector.find_target(scan_data)
                
                if target and target['confidence'] >= self.min_tracking_confidence:
                    # 找到有效目标
                    self._handle_target_found(target)
                    last_target_time = time.time()
                    self.tracking_stats['last_target_time'] = last_target_time
                    
                else:
                    # 目标丢失处理
                    self._handle_target_lost(last_target_time)
                
                # 控制更新频率
                elapsed = time.time() - start_time
                sleep_time = max(0, self.track_update_interval - elapsed)
                time.sleep(sleep_time)
                
            except Exception as e:
                print(f"跟踪循环错误: {e}")
                time.sleep(0.1)

    def _handle_target_found(self, target):
        """处理找到目标的情况"""
        self.current_target = target
        self.target_history.append({
            'angle': target['angle'],
            'distance': target['distance'],
            'confidence': target['confidence'],
            'timestamp': time.time()
        })
        
        # 停止扫描模式
        if self.scan_mode:
            self.scan_mode = False
            print("目标找到,退出扫描模式")
        
        # 计算跟踪角度(可以加入预测)
        track_angle = target['angle']
        if self.prediction_enabled and len(self.target_history) >= 3:
            predicted_angle = self._predict_target_angle()
            if predicted_angle is not None:
                # 混合当前检测和预测结果
                track_angle = 0.7 * target['angle'] + 0.3 * predicted_angle
        
                # 控制舵机跟踪
        self.servo.track_angle(track_angle)
        
        # 更新统计信息
        self.tracking_stats['successful_tracks'] += 1
        print(f"跟踪目标: 角度={target['angle']:.1f}°, 距离={target['distance']:.0f}mm, 置信度={target['confidence']:.1f}")

    def _handle_target_lost(self, last_target_time):
        """处理目标丢失的情况"""
        current_time = time.time()
        time_since_last_target = current_time - last_target_time
        
        if time_since_last_target > self.target_lost_timeout:
            if not self.scan_mode:
                print("目标丢失,启动扫描模式")
                self.scan_mode = True
                self.tracking_stats['lost_tracks'] += 1
            
            # 执行扫描
            self._perform_scan()

    def _predict_target_angle(self):
        """预测目标角度"""
        if len(self.target_history) < 3:
            return None
        
        # 使用简单的线性预测
        recent_history = list(self.target_history)[-3:]
        angles = [h['angle'] for h in recent_history]
        times = [h['timestamp'] for h in recent_history]
        
        # 计算角度变化率
        dt1 = times[1] - times[0]
        dt2 = times[2] - times[1]
        
        if dt1 > 0 and dt2 > 0:
            rate1 = (angles[1] - angles[0]) / dt1
            rate2 = (angles[2] - angles[1]) / dt2
            avg_rate = (rate1 + rate2) / 2
            
            # 预测下一个时刻的角度
            prediction_time = 0.1  # 预测0.1秒后的位置
            predicted_angle = angles[-1] + avg_rate * prediction_time
            
            return predicted_angle % 360
        
        return None

    def _perform_scan(self):
        """执行扫描模式"""
        current_angles = self.servo.get_current_angles()
        current_pan = current_angles['pan']
        
        # 计算扫描目标角度
        scan_step = self.scan_speed * self.track_update_interval
        new_angle = current_pan + self.scan_direction * scan_step
        
        # 检查扫描边界
        if new_angle >= 180:
            new_angle = 180
            self.scan_direction = -1
        elif new_angle <= 0:
            new_angle = 0
            self.scan_direction = 1
        
        self.servo.set_pan_angle(new_angle)

    def get_tracking_status(self):
        """获取跟踪状态信息"""
        return {
            'tracking_enabled': self.tracking_enabled,
            'current_target': self.current_target,
            'scan_mode': self.scan_mode,
            'target_history_length': len(self.target_history),
            'stats': self.tracking_stats
        }

    def set_tracking_parameters(self, **kwargs):
        """设置跟踪参数"""
        if 'update_interval' in kwargs:
            self.track_update_interval = kwargs['update_interval']
        if 'lost_timeout' in kwargs:
            self.target_lost_timeout = kwargs['lost_timeout']
        if 'min_confidence' in kwargs:
            self.min_tracking_confidence = kwargs['min_confidence']
        if 'scan_speed' in kwargs:
            self.scan_speed = kwargs['scan_speed']
        if 'prediction_enabled' in kwargs:
            self.prediction_enabled = kwargs['prediction_enabled']

    def reset_tracking_stats(self):
        """重置跟踪统计信息"""
        self.tracking_stats = {
            'total_tracks': 0,
            'successful_tracks': 0,
            'lost_tracks': 0,
            'tracking_time': 0,
            'last_target_time': 0
        }
        self.target_history.clear()

    def cleanup(self):
        """清理跟踪系统"""
        self.stop_tracking()
        print("跟踪系统已清理")