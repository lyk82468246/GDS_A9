import RPi.GPIO as GPIO
import time
import math
import threading
import random
import serial
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

from lidar_processor import LidarProcessor
from servo_controller import ServoController
from target_detector import TargetDetector

# 配置参数（需要在类外定义）
BOUNDARY_CONFIG = {
    'use_geometric_detection': True,
    'wall_distance_threshold': 80,
    'wall_exclusion_distance': 150,
    'min_wall_points': 15,
    'angle_tolerance': 20
}

CLUSTERING_CONFIG = {
    'eps': 80,
    'min_samples': 3,
    'target_size_min': 50,
    'target_size_max': 300,
    'density_threshold': 1.0,
    'outlier_filter': True
}

# 麦轮车类定义
class MecanumCar:
    def __init__(self, pins):
        GPIO.setmode(GPIO.BCM)
        self.pins = pins
        self.pwm_frequency = 1000
        self.pwms = {}
        self.encoder_counts = {motor: 0 for motor in pins.keys()}
        
        for motor_name, motor_pins in pins.items():
            GPIO.setup(motor_pins['in1'], GPIO.OUT)
            GPIO.setup(motor_pins['in2'], GPIO.OUT)
            GPIO.setup(motor_pins['encoder_a'], GPIO.IN, pull_up_down=GPIO.PUD_UP)
            
            pwm1 = GPIO.PWM(motor_pins['in1'], self.pwm_frequency)
            pwm2 = GPIO.PWM(motor_pins['in2'], self.pwm_frequency)
            pwm1.start(0)
            pwm2.start(0)
            
            self.pwms[motor_name] = {'pwm1': pwm1, 'pwm2': pwm2}
            
            GPIO.add_event_detect(motor_pins['encoder_a'], GPIO.RISING, 
                                callback=lambda channel, name=motor_name: self._encoder_callback(channel, name))
    
    def _encoder_callback(self, channel, motor_name):
        self.encoder_counts[motor_name] += 1
    
    def set_motor_speed(self, motor_name, duty_cycle):
        if motor_name not in self.pwms:
            return
        
        pwm1 = self.pwms[motor_name]['pwm1']
        pwm2 = self.pwms[motor_name]['pwm2']
        
        if duty_cycle > 0:
            pwm1.ChangeDutyCycle(min(abs(duty_cycle), 100))
            pwm2.ChangeDutyCycle(0)
        elif duty_cycle < 0:
            pwm1.ChangeDutyCycle(0)
            pwm2.ChangeDutyCycle(min(abs(duty_cycle), 100))
        else:
            pwm1.ChangeDutyCycle(0)
            pwm2.ChangeDutyCycle(0)
    
    def move(self, direction_angle, speed, rotation_speed=0):
        angle_rad = math.radians(direction_angle)
        
        vx = speed * math.cos(angle_rad)
        vy = speed * math.sin(angle_rad)
        
        front_left_speed = vx - vy - rotation_speed
        front_right_speed = vx + vy + rotation_speed
        rear_left_speed = vx + vy - rotation_speed
        rear_right_speed = vx - vy + rotation_speed
        
        self.set_motor_speed('front_left', front_left_speed)
        self.set_motor_speed('front_right', front_right_speed)
        self.set_motor_speed('rear_left', rear_left_speed)
        self.set_motor_speed('rear_right', rear_right_speed)
    
    def move_forward_with_custom_duty_cycles(self, start_up_time, start_duty_cycles, normal_duty_cycles, duration):
        for motor_name, duty_cycle in start_duty_cycles.items():
            self.set_motor_speed(motor_name, duty_cycle)
        
        time.sleep(start_up_time)
        
        for motor_name, duty_cycle in normal_duty_cycles.items():
            self.set_motor_speed(motor_name, duty_cycle)
        
        time.sleep(duration)
        self.stop()
    
    def move_backward_with_custom_duty_cycles(self, start_up_time, start_duty_cycles, normal_duty_cycles, duration):
        for motor_name, duty_cycle in start_duty_cycles.items():
            self.set_motor_speed(motor_name, -duty_cycle)
        
        time.sleep(start_up_time)
        
        for motor_name, duty_cycle in normal_duty_cycles.items():
            self.set_motor_speed(motor_name, -duty_cycle)
        
        time.sleep(duration)
        self.stop()
    
    def rotate_left(self, angle, duration):
        rotation_speed = 30
        self.move(0, 0, rotation_speed)
        time.sleep(duration)
        self.stop()
    
    def rotate_right(self, angle, duration):
        rotation_speed = -30
        self.move(0, 0, rotation_speed)
        time.sleep(duration)
        self.stop()
    
    def stop(self):
        for motor_name in self.pwms.keys():
            self.set_motor_speed(motor_name, 0)
    
    def read_speeds(self):
        initial_counts = self.encoder_counts.copy()
        time.sleep(0.1)
        final_counts = self.encoder_counts.copy()
        
        speeds = {}
        for motor_name in self.encoder_counts.keys():
            count_diff = final_counts[motor_name] - initial_counts[motor_name]
            speed = count_diff / 0.1
            speeds[motor_name] = speed
        
        return speeds
    
    def __del__(self):
        try:
            for motor_name in self.pwms.keys():
                self.pwms[motor_name]['pwm1'].stop()
                self.pwms[motor_name]['pwm2'].stop()
            GPIO.cleanup()
        except:
            pass

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        # 运动参数配置
        self.forward_start_up_time = 0.05
        self.forward_start_duty_cycles = {
            'front_left': 99, 'front_right': 99,
            'rear_left': 99, 'rear_right': 99
        }
        self.forward_normal_duty_cycles = {
            'front_left': 100, 'front_right': 100,
            'rear_left': 100, 'rear_right': 100
        }
        self.forward_duration = 1.2
        
        self.backward_start_up_time = 0.3
        self.backward_start_duty_cycles = {
            'front_left': 99, 'front_right': 99,
            'rear_left': 70, 'rear_right': 99
        }
        self.backward_normal_duty_cycles = {
            'front_left': 100, 'front_right': 100,
            'rear_left': 75, 'rear_right': 100
        }
        self.backward_duration = 1.9
        
        # 初始化各个组件
        self.lidar = LidarProcessor(port=lidar_port, baudrate=230400)
        self.car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.detector = TargetDetector()
    
        # 串口通信
        self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
        
        # 控制参数
        self.base_speed = base_speed
        self.is_running = False
        self.system_active = False
        self.crossed_midline = False
        self.target_angle = None
        self.target_distance = None
        self.last_camera_data_time = 0
        self.camera_target_count = 0
        
        # 新增：记录右边墙的距离
        self.right_wall_distance = None
        
        # 胜利信号相关
        self.next_victory_time = time.time() + random.uniform(5, 10)
        
        # 线程锁
        self.data_lock = threading.Lock()
        
        # GUI相关
        self.gui_running = True
        self._init_gui()
        
        # 启动监听线程
        self._start_threads()

    def _init_gui(self):
        """初始化GUI界面"""
        self.root = tk.Tk()
        self.root.title("Lidar Battle Bot - Enhanced Geometric Boundary Detection with Wall Exclusion")
        self.root.geometry("1500x1000")
        
        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建左侧控制面板
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # 创建图形显示区域
        plot_frame = ttk.Frame(main_frame)
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 设置matplotlib图形
        plt.style.use('dark_background')
        self.fig, self.ax = plt.subplots(figsize=(10, 10), facecolor='black')
        self.ax.set_facecolor('black')
        self.ax.set_xlim(-4000, 4000)
        self.ax.set_ylim(-4000, 4000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Wall Exclusion)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        
        # 创建canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 设置控制面板的滚动条
        canvas_frame = tk.Canvas(control_frame, width=300)
        scrollbar = ttk.Scrollbar(control_frame, orient="vertical", command=canvas_frame.yview)
        scrollable_frame = ttk.Frame(canvas_frame)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas_frame.configure(scrollregion=canvas_frame.bbox("all"))
        )
        
        canvas_frame.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas_frame.configure(yscrollcommand=scrollbar.set)
        
        canvas_frame.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # 创建控制组件
        self._create_control_widgets(scrollable_frame)
        
        # 启动GUI更新线程
        threading.Thread(target=self._update_gui_loop, daemon=True).start()

    def _start_threads(self):
        """启动所有监听线程"""
        threading.Thread(target=self._listen_for_trigger, daemon=True).start()

    def start_move_to_center(self):
        """开始向中线移动"""
        # 启动时记录右边墙的距离
        scan_data = self.lidar.get_enhanced_scan_data()
        if scan_data:
            right_angle = 270  # 右边方向
            self.right_wall_distance = scan_data.get(right_angle, (0, 0))[0]
            print(f"记录右边墙的距离: {self.right_wall_distance} mm")
        
        # 开始前进
        self.is_running = True
        threading.Thread(target=self.move_to_center, daemon=True).start()

    def move_to_center(self):
        """前进到中线位置,使用自定义占空比控制"""
        try:
            print("开始执行运动序列...")
            
            # 前进阶段
            print("阶段1: 向前运动")
            self.car.move_forward_with_custom_duty_cycles(
                self.forward_start_up_time, 
                self.forward_start_duty_cycles, 
                self.forward_normal_duty_cycles, 
                self.forward_duration
            )
            
            if not self.is_running:
                return
            
            # 中间停顿
            print("阶段2: 中间停顿")
            time.sleep(1.5)
            
            if not self.is_running:
                return
            
            # 后退阶段
            print("阶段3: 向后运动")
            self.car.move_backward_with_custom_duty_cycles(
                self.backward_start_up_time, 
                self.backward_start_duty_cycles, 
                self.backward_normal_duty_cycles, 
                self.backward_duration
            )
            
            print("运动序列执行完成")
            
        except Exception as e:
            print(f"运动序列执行异常: {e}")
        finally:
            # 无论如何都要停止
            self.car.stop()
            print("运动序列结束，小车停止")
        
        self.crossed_midline = True
        print("到达中线,开始战斗模式")
        self.start_battle_mode()

    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False

    def _parse_camera_data(self, data_str):
        """解析摄像头数据，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    # 有效目标数据范围是0-359
                    if 0 <= angle1 <= 359 and 0 <= angle2 <= 359:
                        return angle1, angle2
            return None, None
        except:
            return None, None
    
    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待视觉模块触发命令...")
        
        while True:
            try:
                if self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    # 检查是否为触发命令
                    if self._parse_trigger_command(data):
                        if not self.system_active:
                            print(f"接收到启动命令: {data}")
                            self.system_active = True
                            self._start_system()
                    
                    # 如果系统已激活且越过中线，处理摄像头数据
                    elif self.system_active and self.crossed_midline:
                        angle1, angle2 = self._parse_camera_data(data)
                        if angle1 is not None and angle2 is not None:
                            self._handle_camera_data(angle1, angle2)
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)

    def _handle_camera_data(self, horizontal_angle, vertical_angle):
        """处理摄像头数据"""
        current_time = time.time()
        self.last_camera_data_time = current_time
        self.camera_target_count += 1
        
        print(f"摄像头检测到目标: 水平{horizontal_angle}°, 垂直{vertical_angle}°")
        
        # 控制舵机转向目标
        # 水平角度：左为正，右为负
        servo_horizontal = max(-75, min(75, horizontal_angle))
        servo_vertical = max(-45, min(45, vertical_angle))
        
        self.servo.set_horizontal_angle(servo_horizontal)
        self.servo.set_vertical_angle(servo_vertical)
        
        # 检查是否连续5秒收到有效数据（游戏结束条件）
        if self.camera_target_count >= 50:  # 假设10Hz数据，5秒约50个数据
            print("连续5秒检测到目标，游戏结束")
            self._stop_system()
    
    def _toggle_system(self):
        """手动切换系统状态"""
        if not self.system_active:
            self.system_active = True
            self._start_system()
        else:
            self.system_active = False
            self._stop_system()
    
    def _start_system(self):
        """启动系统"""
        print("系统启动，开始前进到中线...")
        self.status_var.set("System Active - Moving to Center")
        self.status_label.configure(background='green')
        self.start_stop_button.configure(text="Stop System")
        
        # 开始前进到中心位置
        self.start_move_to_center()
        
    def _stop_system(self):
        """停止系统"""
        print("系统停止")
        self.is_running = False
        self.system_active = False
        self.crossed_midline = False
        self.car.stop()
        
        # 舵机回到中位
        self.servo.set_horizontal_angle(0)
        self.servo.set_vertical_angle(0)
        
        self.status_var.set("System Stopped")
        self.status_label.configure(background='red')
        self.start_stop_button.configure(text="Manual Start")

    def lidar_data_thread(self):
        """处理雷达数据的线程"""
        print("雷达数据线程已启动")
        while self.is_running and self.system_active and self.crossed_midline:
            try:
                scan_data = self.lidar.get_enhanced_scan_data()
                if scan_data:
                    # 检测场地内的目标
                    field_points = self.detector.detect_field_boundary(scan_data)
                    clusters = self.detector.cluster_targets(field_points)
                    
                    if clusters:
                        # 选择最近的目标
                        target = min(clusters, key=lambda x: x['distance'])
                        target_angle = target['angle']
                        target_distance = target['distance']
                        
                        with self.data_lock:
                            self.target_angle = target_angle
                            self.target_distance = target_distance
                        
                        self._track_target_with_servo(target_angle)
                        print(f"雷达检测到目标: 角度={target_angle:.1f}°, 距离={target_distance:.0f}mm")
                    else:
                        # 没有目标，进行随机移动
                        self._random_movement()
                
                time.sleep(0.1)
            except Exception as e:
                print(f"雷达数据处理异常: {e}")
                time.sleep(0.5)

    def _track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        # 计算舵机角度（-75到75度范围）
        servo_angle = target_angle
        if servo_angle > 180:
            servo_angle = servo_angle - 360
        
        # 限制在舵机范围内
        servo_angle = max(-75, min(75, servo_angle))
        
        # 如果角度偏差较小，直接用舵机跟踪
        if abs(servo_angle) <= 45:
            self.servo.set_horizontal_angle(servo_angle)
        else:
            # 角度偏差过大，小车转向补偿
            turn_angle = servo_angle / 2  # 小幅转向
            if turn_angle > 0:
                self.car.rotate_left(abs(turn_angle), 0.3)
            else:
                self.car.rotate_right(abs(turn_angle), 0.3)
            time.sleep(0.2)

    def _random_movement(self):
        """随机移动避免被攻击"""
        movement_type = random.choice(['translate', 'rotate'])
        
        if movement_type == 'translate':
            # 随机平移
            angle = random.randint(0, 360)
            speed = random.randint(30, 60)
            duration = random.uniform(0.5, 1.0)
            self.car.move(angle, speed, duration)
        else:
            # 随机旋转
            direction = random.choice(['left', 'right'])
            angle = random.randint(15, 45)
            duration = random.uniform(0.3, 0.8)
            if direction == 'left':
                self.car.rotate_left(angle, duration)
            else:
                self.car.rotate_right(angle, duration)

    def victory_signal_thread(self):
        """胜利信号线程"""
        print("胜利信号线程已启动")
        while self.is_running and self.system_active and self.crossed_midline:
            try:
                current_time = time.time()
                
                # 检查是否到了发送胜利信号的时间
                if current_time >= self.next_victory_time:
                    self._send_victory_signal()
                    # 设置下次发送时间（5-10秒随机间隔）
                    interval = random.uniform(5, 10)
                    self.next_victory_time = current_time + interval
                    print(f"胜利信号已发送，下次发送间隔: {interval:.1f}秒")
                
                # 检查摄像头无数据超时
                if current_time - self.last_camera_data_time > 5:
                    self.camera_target_count = 0  # 重置计数
                
                time.sleep(1.0)
            except Exception as e:
                print(f"胜利信号处理异常: {e}")
                time.sleep(1.0)

    def _send_victory_signal(self):
        """发送胜利信号"""
        # 这里可以添加具体的胜利信号发送逻辑
        # 例如串口发送、GPIO输出等
        print("发送胜利信号")

    def start_battle_mode(self):
        """启动战斗模式"""
        if not self.crossed_midline:
            return
            
        self.is_running = True
        
        # 启动各个处理线程
        lidar_thread = threading.Thread(target=self.lidar_data_thread, daemon=True)
        victory_thread = threading.Thread(target=self.victory_signal_thread, daemon=True)
        
        lidar_thread.start()
        victory_thread.start()
        
        print("战斗模式已启动！")
        
        self.status_var.set("System Active - Battle Mode")

    def _create_control_widgets(self, parent):
        """创建控制组件"""
        # 系统状态显示
        ttk.Label(parent, text="System Status", font=('Arial', 12, 'bold')).pack(pady=5)
        self.status_var = tk.StringVar(value="Waiting for Trigger")
        self.status_label = ttk.Label(parent, textvariable=self.status_var, 
                                     background='red', foreground='white', font=('Arial', 10))
        self.status_label.pack(pady=5, fill=tk.X)
        
        # 启动/停止按钮
        self.start_stop_button = ttk.Button(parent, text="Manual Start", 
                                           command=self._toggle_system)
        self.start_stop_button.pack(pady=10, fill=tk.X)
        
        # 目标信息显示
        ttk.Label(parent, text="Target Information", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        self.target_info_frame = ttk.Frame(parent)
        self.target_info_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.target_info_frame, text="Angle:").grid(row=0, column=0, sticky='w')
        self.angle_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.angle_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(self.target_info_frame, text="Distance:").grid(row=1, column=0, sticky='w')
        self.distance_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.distance_var).grid(row=1, column=1, sticky='w')
        
        # 舵机控制显示
        ttk.Label(parent, text="Servo Control", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        servo_frame = ttk.Frame(parent)
        servo_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(servo_frame, text="Pan:").grid(row=0, column=0, sticky='w')
        self.pan_var = tk.StringVar(value="0°")
        ttk.Label(servo_frame, textvariable=self.pan_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(servo_frame, text="Tilt:").grid(row=1, column=0, sticky='w')
        self.tilt_var = tk.StringVar(value="0°")
        ttk.Label(servo_frame, textvariable=self.tilt_var).grid(row=1, column=1, sticky='w')
        
        # 统计信息
        ttk.Label(parent, text="Statistics", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        stats_frame = ttk.Frame(parent)
        stats_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(stats_frame, text="Camera Targets:").grid(row=0, column=0, sticky='w')
        self.camera_targets_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.camera_targets_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Midline Crossed:").grid(row=1, column=0, sticky='w')
        self.midline_var = tk.StringVar(value="No")
        ttk.Label(stats_frame, textvariable=self.midline_var).grid(row=1, column=1, sticky='w')

    def _update_gui_loop(self):
        """GUI更新循环"""
        while self.gui_running:
            try:
                self._update_gui()
                time.sleep(0.1)  # 10Hz更新频率
            except Exception as e:
                print(f"GUI更新异常: {e}")
                time.sleep(0.1)

    def _update_gui(self):
        """更新GUI显示"""
        # 更新目标信息
        with self.data_lock:
            if self.target_angle is not None:
                self.angle_var.set(f"{self.target_angle:.1f}°")
                self.distance_var.set(f"{self.target_distance:.0f}mm")
            else:
                self.angle_var.set("N/A")
                self.distance_var.set("N/A")
        
        # 更新舵机位置
        self.pan_var.set(f"{self.servo.pan_angle:.0f}°")
        self.tilt_var.set(f"{self.servo.tilt_angle:.0f}°")
        
        # 更新统计信息
        self.camera_targets_var.set(str(self.camera_target_count))
        self.midline_var.set("Yes" if self.crossed_midline else "No")

    def shutdown(self):
        """关闭系统"""
        self.is_running = False
        self.system_active = False
        self.gui_running = False
        self.car.stop()
        self.servo.cleanup()
        self.lidar.close()
        self.camera_serial.close()
        print("系统已关闭")

def main():
    # 创建机器人实例
    bot = LidarBattleBot()
    
    try:
        print("机器人系统已初始化")
        print("等待视觉模块发送触发命令（格式：$+角度1+角度2$，角度范围360-999）")
        print("系统将执行运动序列：前进->停顿->后退，然后进入战斗模式")
        
        # 启动Tkinter主循环
        bot.root.mainloop()
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
    finally:
        bot.shutdown()

if __name__ == '__main__':
    main()