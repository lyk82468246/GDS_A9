import math
import numpy as np
import time

# 完整的边界检测配置
BOUNDARY_CONFIG = {
    # 统计检测参数
    'statistical_distance_threshold': 200,
    'cluster_distance_threshold': 150,
    'min_distance_change': 100,
    
    # 墙面检测参数
    'expected_wall_distance': 2000,
    'wall_distance_tolerance': 300,
    'wall_distance_threshold': 100,
    'wall_exclusion_distance': 400,
    'min_wall_points': 15,
    
    # 角度相关参数
    'angle_tolerance': 15,  # 添加缺失的配置项
    'angle_step': 1,
    'angle_window': 3,
    
    # 目标检测参数
    'min_target_points': 5,
    'max_target_distance': 3000,
    'min_target_distance': 100,
    'target_size_threshold': 50,
    
    # 噪声过滤参数
    'noise_filter_threshold': 100,
    
    # 边界检测阈值
    'boundary_distance_jump_threshold': 300,
    'consecutive_boundary_points': 3,
}

class BoundaryDetector:
    """边界检测器类"""
    
    def __init__(self):
        # 安全地获取配置参数，提供默认值
        self.statistical_distance_threshold = BOUNDARY_CONFIG.get('statistical_distance_threshold', 200)
        self.cluster_distance_threshold = BOUNDARY_CONFIG.get('cluster_distance_threshold', 150)
        self.min_distance_change = BOUNDARY_CONFIG.get('min_distance_change', 100)
        
        # 墙面检测参数
        self.expected_wall_distance = BOUNDARY_CONFIG.get('expected_wall_distance', 2000)
        self.wall_distance_tolerance = BOUNDARY_CONFIG.get('wall_distance_tolerance', 300)
        self.wall_distance_threshold = BOUNDARY_CONFIG.get('wall_distance_threshold', 100)
        self.wall_exclusion_distance = BOUNDARY_CONFIG.get('wall_exclusion_distance', 400)
        self.min_wall_points = BOUNDARY_CONFIG.get('min_wall_points', 15)
        
        # 角度相关参数 - 修复KeyError问题
        self.angle_tolerance = BOUNDARY_CONFIG.get('angle_tolerance', 15)
        self.angle_step = BOUNDARY_CONFIG.get('angle_step', 1)
        self.angle_window = BOUNDARY_CONFIG.get('angle_window', 3)
        
        # 目标检测参数
        self.min_target_points = BOUNDARY_CONFIG.get('min_target_points', 5)
        self.max_target_distance = BOUNDARY_CONFIG.get('max_target_distance', 3000)
        self.min_target_distance = BOUNDARY_CONFIG.get('min_target_distance', 100)
        self.target_size_threshold = BOUNDARY_CONFIG.get('target_size_threshold', 50)
        
        # 噪声过滤参数
        self.noise_filter_threshold = BOUNDARY_CONFIG.get('noise_filter_threshold', 100)
        
        # 边界检测阈值
        self.boundary_distance_jump_threshold = BOUNDARY_CONFIG.get('boundary_distance_jump_threshold', 300)
        self.consecutive_boundary_points = BOUNDARY_CONFIG.get('consecutive_boundary_points', 3)
        
        # 统计信息
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }

    def detect_boundary(self, scan_data):
        """检测边界点"""
        boundary_points = []
        
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            
            if self._is_boundary_point(angle, distance, scan_data):
                # 转换坐标
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                boundary_points.append((x, y, angle, distance, intensity))
        
        self.detection_stats['total_detections'] += 1
        if boundary_points:
            self.detection_stats['successful_detections'] += 1
            self.detection_stats['last_detection_time'] = time.time()
        
        return boundary_points

    def _is_boundary_point(self, angle, distance, scan_data):
        """判断是否为边界点"""
        if distance < self.min_target_distance or distance > self.max_target_distance:
            return True
        
        # 检查相邻角度的距离变化
        for offset in [-1, 1]:
            adjacent_angle = (angle + offset) % 360
            adjacent_distance, _ = scan_data.get(adjacent_angle, (0, 0))
            
            if adjacent_distance > 0:
                if abs(distance - adjacent_distance) > self.statistical_distance_threshold:
                    return True
        
        # 检查是否接近墙面
        if abs(distance - self.expected_wall_distance) < self.wall_distance_tolerance:
            return True
        
        return False

    def get_detection_statistics(self):
        """获取检测统计信息"""
        success_rate = 0
        if self.detection_stats['total_detections'] > 0:
            success_rate = self.detection_stats['successful_detections'] / self.detection_stats['total_detections'] * 100
        
        return {
            'total_detections': self.detection_stats['total_detections'],
            'successful_detections': self.detection_stats['successful_detections'],
            'success_rate': success_rate,
        }

    def reset_statistics(self):
        """重置统计信息"""
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }