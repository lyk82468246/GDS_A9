from adafruit_servokit import ServoKit
import time

class ServoController:
    """舵机云台控制器,使用I2C PWM控制器"""
    
    def __init__(self):
        self.servo_kit = ServoKit(channels=16)
        
        self.pan_channel = 1
        self.tilt_channel = 0
        self.pan_angle = 90
        self.tilt_angle = 80
        self.angle_min = 0
        self.angle_max = 180
        
        self.set_pan_angle(self.pan_angle)
        self.set_tilt_angle(self.tilt_angle)
        print("I2C舵机控制器已初始化")

    def set_pan_angle(self, angle):
        """设置水平舵机角度"""
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.pan_angle = angle
        self.servo_kit.servo[self.pan_channel].angle = angle
        return self.pan_angle

    def set_tilt_angle(self, angle):
        """设置垂直舵机角度"""
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.tilt_angle = angle
        self.servo_kit.servo[self.tilt_channel].angle = angle
        return self.tilt_angle

    def set_horizontal_angle(self, relative_angle):
        """设置水平相对角度 (-90 到 90)"""
        absolute_angle = 90 + relative_angle
        return self.set_pan_angle(absolute_angle)

    def set_vertical_angle(self, relative_angle):
        """设置垂直相对角度 (-30 到 30)"""
        absolute_angle = 90 + relative_angle
        return self.set_tilt_angle(absolute_angle)

    def get_current_angles(self):
        """获取当前舵机角度"""
        return {
            'pan': self.pan_angle,
            'tilt': self.tilt_angle,
            'pan_relative': self.pan_angle - 90,
            'tilt_relative': self.tilt_angle - 90
        }

    def center_servos(self):
        """舵机复位到中心位置"""
        print("舵机复位到中心位置")
        self.set_pan_angle(90)
        self.set_tilt_angle(90)

    def cleanup(self):
        """舵机复位到中位位置"""
        self.set_pan_angle(90)
        self.set_tilt_angle(90)
        time.sleep(0.5)
        print("舵机已复位到中位位置")