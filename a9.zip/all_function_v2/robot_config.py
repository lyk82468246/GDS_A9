# robot_config.py
"""
机器人配置管理模块
"""

# 边界检测配置 - 与BoundaryDetector类匹配
BOUNDARY_CONFIG = {
    # 统计检测参数
    'statistical_distance_threshold': 200,
    'cluster_distance_threshold': 150,
    'min_distance_change': 100,
    
    # 墙面检测参数
    'expected_wall_distance': 2000,
    'wall_distance_tolerance': 300,
    'wall_distance_threshold': 100,
    'wall_exclusion_distance': 400,
    'min_wall_points': 15,
    
    # 角度相关参数
    'angle_tolerance': 15,
    'angle_step': 1,
    'angle_window': 3,
    
    # 目标检测参数
    'min_target_points': 5,
    'max_target_distance': 3000,
    'min_target_distance': 100,
    'target_size_threshold': 50,
    
    # 噪声过滤参数
    'noise_filter_threshold': 100,
    
    # 边界检测阈值
    'boundary_distance_jump_threshold': 300,
    'consecutive_boundary_points': 3,
}

# 聚类检测配置
CLUSTERING_CONFIG = {
    'cluster_distance_threshold': 150,
    'min_cluster_size': 3,
    'target_size_min': 50,
    'target_size_max': 300,
    'density_threshold': 1.0,
    'outlier_filter': True,
    'max_cluster_distance': 200
}

# GUI配置
GUI_CONFIG = {
    'window_title': "Lidar Battle Bot - Enhanced Geometric Boundary Detection",
    'window_size': "1500x1000",
    'plot_xlim': (-4000, 4000),
    'plot_ylim': (-4000, 4000),
    'colors': ['red', 'blue', 'yellow', 'orange', 'purple', 'cyan'],
    'wall_colors': ['red', 'blue', 'yellow', 'orange'],
    'update_frequency': 0.1  # 10Hz
}

# 通信配置
COMMUNICATION_CONFIG = {
    'lidar_port': '/dev/ttyAMA2',
    'camera_port': '/dev/ttyCH343USB0',
    'lidar_baudrate': 230400,
    'camera_baudrate': 115200,
    'camera_timeout': 0.1
}

# 运动控制配置
MOTION_CONFIG = {
    'base_speed': 60,
    'forward_start_up_time': 0.5,
    'forward_start_duty_cycles': [70, 70, 70, 70],
    'forward_normal_duty_cycles': [60, 60, 60, 60],
    'forward_duration': 2.0,
    'backward_start_up_time': 0.3,
    'backward_start_duty_cycles': [50, 50, 50, 50],
    'backward_normal_duty_cycles': [40, 40, 40, 40],
    'backward_duration': 1.0
}

# 电机引脚配置
MOTOR_PINS = {
    'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
    'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
    'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
    'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
}