# main.py
"""
机器人主程序入口
"""

from robot_system import RobotSystem

def main():
    """主函数"""
    # 创建并启动机器人系统
    robot = RobotSystem()
    robot.start()

if __name__ == '__main__':
    main()