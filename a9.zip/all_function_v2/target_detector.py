import math
import time
from collections import defaultdict

from Boundary_detector import BoundaryDetector

# 全局配置常量
BOUNDARY_CONFIG = {
    'statistical_distance_threshold': 200,
    'expected_wall_distance': 2000,
    'wall_distance_tolerance': 300,
    'min_target_distance': 100,
    'max_target_distance': 3000,
    'min_wall_points': 15,
    'cluster_distance_threshold': 150,
    'min_distance_change': 100,
    'min_cluster_size': 3,
    'max_cluster_distance': 200,
}

class TargetDetector:
    """仅使用几何检测的目标检测器"""
    
    def __init__(self, min_cluster_size, max_cluster_distance, boundary_detector):
        self.min_cluster_size = min_cluster_size
        self.max_cluster_distance = max_cluster_distance
        self.boundary_detector = boundary_detector
        
        self.boundary_distance_threshold = BOUNDARY_CONFIG['statistical_distance_threshold']
        self.expected_wall_distance = BOUNDARY_CONFIG['expected_wall_distance']
        self.wall_distance_tolerance = BOUNDARY_CONFIG['wall_distance_tolerance']
        
        self.use_geometric_detection = True
        self.use_statistical_detection = True
        
        self.detection_mode = 'hybrid'
        
        self.boundary_distance_threshold = BOUNDARY_CONFIG.get('statistical_distance_threshold', 200)
        self.min_distance_change = BOUNDARY_CONFIG.get('min_distance_change', 100)
        
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }

    def detect_field_boundary(self, scan_data):
        """几何方法检测场地边界"""
        start_time = time.time()
        
        # 使用几何方法检测边界
        boundary_points = self._geometric_boundary_detection(scan_data)
        
        # 记录处理时间
        processing_time = time.time() - start_time
        self.detection_stats['total_detections'] += 1
        if boundary_points:
            self.detection_stats['successful_detections'] += 1
            self.detection_stats['last_detection_time'] = time.time()
        
        return boundary_points

    def _geometric_boundary_detection(self, scan_data):
        """几何边界检测"""
        field_points = []
        
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            
            # 基本有效性检查
            if distance < BOUNDARY_CONFIG['min_target_distance'] or distance > BOUNDARY_CONFIG['max_target_distance']:
                continue
            
            # 检查是否为边界点
            if self._is_boundary_point(angle, distance, scan_data):
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                field_points.append((x, y, angle, distance, intensity))
        
        return field_points

    def _is_boundary_point(self, angle, distance, scan_data):
        """几何方法判断边界点"""
        left_angle = (angle - 1) % 360
        right_angle = (angle + 1) % 360
        
        left_distance, _ = scan_data.get(left_angle, (0, 0))
        right_distance, _ = scan_data.get(right_angle, (0, 0))
        
        # 如果相邻点距离变化过大,可能是边界
        if left_distance > 0 and abs(distance - left_distance) > self.boundary_distance_threshold:
            return True
        if right_distance > 0 and abs(distance - right_distance) > self.boundary_distance_threshold:
            return True
        
        # 检查是否接近预期的墙面距离
        expected_distances = [self.expected_wall_distance, self.expected_wall_distance * 1.414]  # 对角线距离
        for expected in expected_distances:
            if abs(distance - expected) < self.wall_distance_tolerance:
                return True
        
        return False

    def cluster_targets(self, field_points):
        """将检测到的边界点聚类成目标"""
        if not field_points:
            return []
        
        # 基于距离的简单聚类算法
        clusters = []
        used_points = set()
        
        for i, point in enumerate(field_points):
            if i in used_points:
                continue
                
            cluster = [point]
            used_points.add(i)
            x1, y1 = point[0], point[1]
            
            # 寻找附近的点
            for j, other_point in enumerate(field_points):
                if j in used_points:
                    continue
                    
                x2, y2 = other_point[0], other_point[1]
                distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
                
                if distance <= self.max_cluster_distance:
                    cluster.append(other_point)
                    used_points.add(j)
        
        # 过滤小聚类
        filtered_clusters = []
        for cluster in clusters:
            if len(cluster) >= self.min_cluster_size:
                filtered_clusters.append(cluster)
        
        return filtered_clusters

    def analyze_cluster(self, cluster):
        """分析聚类的特征"""
        if not cluster:
            return None
        
        # 计算聚类中心
        center_x = sum(point[0] for point in cluster) / len(cluster)
        center_y = sum(point[1] for point in cluster) / len(cluster)
        
        # 计算平均距离
        avg_distance = sum(point[3] for point in cluster) / len(cluster)
        
        # 计算角度范围
        angles = [point[2] for point in cluster]
        min_angle = min(angles)
        max_angle = max(angles)
        
        # 处理角度跨越0度的情况
        if max_angle - min_angle > 180:
            angles = [(angle + 360) if angle < 180 else angle for angle in angles]
            min_angle = min(angles) % 360
            max_angle = max(angles) % 360
        
        angle_span = max_angle - min_angle
        
        return {
            'center': (center_x, center_y),
            'size': len(cluster),
            'avg_distance': avg_distance,
            'angle_span': angle_span,
            'min_angle': min_angle,
            'max_angle': max_angle,
            'points': cluster
        }

    def detect_and_cluster_targets(self, scan_data):
        """检测边界并聚类目标的完整流程"""
        # 检测边界点
        field_points = self.detect_field_boundary(scan_data)
        
        # 聚类目标
        clusters = self.cluster_targets(field_points)
        
        # 分析每个聚类
        analyzed_clusters = []
        for cluster in clusters:
            analysis = self.analyze_cluster(cluster)
            if analysis:
                analyzed_clusters.append(analysis)
        
        return field_points, analyzed_clusters

    def get_detection_statistics(self):
        """获取检测统计信息"""
        success_rate = 0
        if self.detection_stats['total_detections'] > 0:
            success_rate = self.detection_stats['successful_detections'] / self.detection_stats['total_detections'] * 100
        
        return {
            'total_detections': self.detection_stats['total_detections'],
            'successful_detections': self.detection_stats['successful_detections'],
            'success_rate': success_rate,
        }

    def reset_statistics(self):
        """重置统计信息"""
        self.detection_stats = {
            'total_detections': 0,
            'successful_detections': 0,
            'last_detection_time': 0,
        }

    def set_detection_mode(self, mode):
        """设置检测模式"""
        if mode in ['geometric', 'statistical', 'hybrid']:
            self.detection_mode = mode
            return True
        return False

    def update_config(self, config_updates):
        """动态更新配置参数"""
        for key, value in config_updates.items():
            if hasattr(self, key):
                setattr(self, key, value)
                print(f"更新参数 {key}: {value}")
            else:
                print(f"警告: 未知参数 {key}")

    def get_current_config(self):
        """获取当前配置"""
        return {
            'boundary_distance_threshold': self.boundary_distance_threshold,
            'cluster_distance_threshold': self.cluster_distance_threshold,
            'min_distance_change': self.min_distance_change,
            'min_cluster_size': self.min_cluster_size,
            'max_cluster_distance': self.max_cluster_distance,
            'expected_wall_distance': self.expected_wall_distance,
            'wall_distance_tolerance': self.wall_distance_tolerance,
            'detection_mode': self.detection_mode
        }