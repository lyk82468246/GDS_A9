# communication_manager.py
"""
通信管理模块，处理串口通信和命令解析
"""

import serial
import threading
import time
from robot_config import COMMUNICATION_CONFIG

class CommunicationManager:
    def __init__(self, camera_port=None, callback=None):
        self.camera_port = camera_port or COMMUNICATION_CONFIG['camera_port']
        self.callback = callback
        self.is_running = False
        self.listen_thread = None
        
        try:
            self.camera_serial = serial.Serial(
                self.camera_port, 
                COMMUNICATION_CONFIG['camera_baudrate'], 
                timeout=COMMUNICATION_CONFIG['camera_timeout']
            )
            print("串口初始化成功")
        except Exception as e:
            print(f"串口初始化失败: {e}")
            self.camera_serial = MockSerial()
    
    def start_listening(self):
        """开始监听串口命令"""
        if not self.is_running:
            self.is_running = True
            self.listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
            self.listen_thread.start()
            print("串口监听已启动")
    
    def stop_listening(self):
        """停止监听串口命令"""
        self.is_running = False
        if self.listen_thread:
            self.listen_thread.join(timeout=1.0)
        print("串口监听已停止")
    
    def _listen_loop(self):
        """监听循环"""
        print("等待视觉模块触发命令...")
        
        while self.is_running:
            try:
                if hasattr(self.camera_serial, 'in_waiting') and self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    if self._parse_trigger_command(data):
                        if self.callback:
                            self.callback(data)
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)
    
    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False
    
    def send_victory_signal(self):
        """发送胜利信号"""
        try:
            # 这里可以添加具体的胜利信号发送逻辑
            print("发送胜利信号")
        except Exception as e:
            print(f"发送胜利信号失败: {e}")
    
    def shutdown(self):
        """关闭通信管理器"""
        self.stop_listening()
        try:
            self.camera_serial.close()
        except:
            pass

class MockSerial:
    def __init__(self):
        self.in_waiting = 0
        
    def readline(self):
        return b"mock data\n"
        
    def close(self):
        pass