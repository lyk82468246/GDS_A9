# gui_manager.py
"""
GUI管理模块，处理界面显示和更新
"""

import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import math
import numpy as np
import threading
import time
from robot_config import GUI_CONFIG

class GUIManager:
    def __init__(self, robot_system=None):
        self.robot_system = robot_system
        self.gui_running = False
        self.gui_thread = None
        
        # 数据显示变量
        self.status_var = None
        self.angle_var = None
        self.distance_var = None
        self.pan_var = None
        self.tilt_var = None
        self.scan_points_var = None
        self.field_points_var = None
        self.clusters_var = None
        self.walls_var = None
        self.midline_var = None
        
        self._init_gui()
    
    def _init_gui(self):
        """初始化GUI界面"""
        try:
            self.root = tk.Tk()
            self.root.title(GUI_CONFIG['window_title'])
            self.root.geometry(GUI_CONFIG['window_size'])
            
            # 创建主框架
            main_frame = ttk.Frame(self.root)
            main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # 创建左侧控制面板
            control_frame = ttk.Frame(main_frame)
            control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
            
            # 创建图形显示区域
            plot_frame = ttk.Frame(main_frame)
            plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
            
            # 设置matplotlib图形
            self._setup_plot(plot_frame)
            
            # 创建控制组件
            self._create_control_widgets(control_frame)
            
            print("GUI初始化成功")
            
        except Exception as e:
            print(f"GUI初始化失败: {e}")
            import traceback
            traceback.print_exc()
    
    def _setup_plot(self, parent):
        """设置matplotlib图形"""
        plt.style.use('dark_background')
        self.fig, self.ax = plt.subplots(figsize=(10, 10), facecolor='black')
        self.ax.set_facecolor('black')
        self.ax.set_xlim(GUI_CONFIG['plot_xlim'])
        self.ax.set_ylim(GUI_CONFIG['plot_ylim'])
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        
        # 创建canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def _create_control_widgets(self, parent):
        """创建控制组件"""
        try:
            # 系统状态显示
            ttk.Label(parent, text="System Status", font=('Arial', 12, 'bold')).pack(pady=5)
            self.status_var = tk.StringVar(value="Waiting for Trigger")
            self.status_label = ttk.Label(parent, textvariable=self.status_var, 
                                         background='red', foreground='white', font=('Arial', 10))
            self.status_label.pack(pady=5, fill=tk.X)
            
            # 启动/停止按钮
            self.start_stop_button = ttk.Button(parent, text="Manual Start", 
                                               command=self._toggle_system)
            self.start_stop_button.pack(pady=10, fill=tk.X)
            
            # 目标信息显示
            self._create_info_section(parent, "Target Information", [
                ("Angle:", "angle_var"),
                ("Distance:", "distance_var")
            ])
            
            # 舵机控制显示
            self._create_info_section(parent, "Servo Control", [
                ("Pan:", "pan_var"),
                ("Tilt:", "tilt_var")
            ])
            
            # 统计信息
            self._create_info_section(parent, "Statistics", [
                ("Scan Points:", "scan_points_var"),
                ("Field Points:", "field_points_var"),
                ("Clusters:", "clusters_var"),
                ("Walls:", "walls_var"),
                ("Midline Crossed:", "midline_var")
            ])
            
        except Exception as e:
            print(f"控件创建失败: {e}")
    
    def _create_info_section(self, parent, title, items):
        """创建信息显示区域"""
        ttk.Label(parent, text=title, font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        info_frame = ttk.Frame(parent)
        info_frame.pack(fill=tk.X, pady=5)
        
        for i, (label_text, var_name) in enumerate(items):
            ttk.Label(info_frame, text=label_text).grid(row=i, column=0, sticky='w')
            var = tk.StringVar(value="N/A")
            setattr(self, var_name, var)
            ttk.Label(info_frame, textvariable=var).grid(row=i, column=1, sticky='w')
    
    def _toggle_system(self):
        """切换系统状态"""
        if self.robot_system:
            self.robot_system.toggle_system()
    
    def start_gui_updates(self):
        """启动GUI更新"""
        if not self.gui_running:
            self.gui_running = True
            self.gui_thread = threading.Thread(target=self._update_loop, daemon=True)
            self.gui_thread.start()
            print("GUI更新线程已启动")
    
    def stop_gui_updates(self):
        """停止GUI更新"""
        self.gui_running = False
        if self.gui_thread:
            self.gui_thread.join(timeout=1.0)
    
    def _update_loop(self):
        """GUI更新循环"""
        while self.gui_running:
            try:
                self.update_display()
                time.sleep(GUI_CONFIG['update_frequency'])
            except Exception as e:
                print(f"GUI更新异常: {e}")
                time.sleep(0.5)
    
    def update_display(self):
        """更新显示"""
        if not self.robot_system:
            return
            
        try:
            # 获取数据
            data = self.robot_system.get_display_data()
            
            # 更新图形
            self._update_plot(data)
            
            # 更新状态信息
            self._update_status_info(data)
            
        except Exception as e:
            print(f"显示更新失败: {e}")
    
    def _update_plot(self, data):
        """更新图形显示"""
        try:
            scan_data = data.get('scan_data')
            field_points = data.get('field_points', [])
            clusters = data.get('clusters', [])
            detected_walls = data.get('walls', [])
            target_angle = data.get('target_angle')
            servo_angle = data.get('servo_angle', 0)
            
            if not scan_data:
                return
            
            # 清除上一次的绘图
            self.ax.clear()
            self.ax.set_xlim(GUI_CONFIG['plot_xlim'])
            self.ax.set_ylim(GUI_CONFIG['plot_ylim'])
            self.ax.set_xlabel('X (mm)', color='white')
            self.ax.set_ylabel('Y (mm)', color='white')
            self.ax.set_title('Lidar Scan and Target Detection', color='white')
            self.ax.grid(True, alpha=0.3)
            self.ax.tick_params(colors='white')
            self.ax.set_facecolor('black')
            
            # 绘制所有扫描点
            self._draw_scan_points(scan_data)
            
            # 绘制墙面
            self._draw_walls(detected_walls)
            
            # 绘制场地点
            self._draw_field_points(field_points)
            
            # 绘制聚类结果
            self._draw_clusters(clusters)
            
            # 绘制机器人和方向
            self._draw_robot_and_directions(target_angle, servo_angle)
            
            # 添加角度刻度
            self._draw_angle_markers()
            
            # 添加图例
            self.ax.legend(loc='upper right', fontsize=8)
            
            # 重绘canvas
            self.canvas.draw()
            
        except Exception as e:
            print(f"图形更新失败: {e}")
    
    def _draw_scan_points(self, scan_data):
        """绘制扫描点"""
        all_points_x = []
        all_points_y = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if distance > 0:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                all_points_x.append(x)
                all_points_y.append(y)
        
        if all_points_x:
            self.ax.scatter(all_points_x, all_points_y, s=1, c='gray', alpha=0.5, label='Scan Points')
    
    def _draw_walls(self, detected_walls):
        """绘制检测到的墙面"""
        if not detected_walls:
            return
            
        wall_colors = GUI_CONFIG['wall_colors']
        for i, wall in enumerate(detected_walls):
            wall_points = wall.get('points', [])
            if wall_points:
                wall_x = [p[0] for p in wall_points]
                wall_y = [p[1] for p in wall_points]
                
                wall_color = wall_colors[i % len(wall_colors)]
                self.ax.scatter(wall_x, wall_y, s=8, c=wall_color, alpha=0.8, 
                              label=f'Wall {i+1} ({len(wall_points)} pts)')
                
                # 绘制拟合直线
                line_params = wall.get('line', None)
                if line_params:
                    self._draw_wall_line(line_params, wall_color)
    
    def _draw_wall_line(self, line_params, color):
        """绘制墙面拟合直线"""
        a, b, c = line_params
        xlim = GUI_CONFIG['plot_xlim']
        ylim = GUI_CONFIG['plot_ylim']
        
        if abs(b) > 0.001:  # 非垂直线
            x_line = np.linspace(xlim[0], xlim[1], 100)
            y_line = -(a * x_line + c) / b
            valid_mask = (y_line >= ylim[0]) & (y_line <= ylim[1])
            if np.any(valid_mask):
                self.ax.plot(x_line[valid_mask], y_line[valid_mask], 
                           color=color, linestyle='--', alpha=0.7, linewidth=2)
        else:  # 垂直线
            x_line = -c / a
            if xlim[0] <= x_line <= xlim[1]:
                self.ax.axvline(x=x_line, color=color, linestyle='--', 
                              alpha=0.7, linewidth=2)
    
    def _draw_field_points(self, field_points):
        """绘制场地内的点"""
        if not field_points:
            return
            
        field_x = []
        field_y = []
        for p in field_points:
            angle = math.atan2(p[1], p[0])
            distance = math.sqrt(p[0]**2 + p[1]**2)
            car_angle = (math.degrees(angle) + 90) % 360

            display_angle = math.radians(car_angle - 90)
            x = distance * math.cos(display_angle)
            y = distance * math.sin(display_angle)
            field_x.append(x)
            field_y.append(y)

        if field_x:
            self.ax.scatter(field_x, field_y, s=5, c='green', alpha=0.7, label='Field Points')
    
    def _draw_clusters(self, clusters):
        """绘制聚类结果"""
        colors = GUI_CONFIG['colors']
        
        for i, cluster in enumerate(clusters):
            color = colors[i % len(colors)]
            cluster_angle = cluster['angle']
            cluster_distance = cluster['distance']
            confidence = cluster.get('confidence', 0)

            # 角度转换
            display_angle = math.radians((360 - cluster_angle) % 360)
            center_x = cluster_distance * math.cos(display_angle)
            center_y = -cluster_distance * math.sin(display_angle)

            # 根据置信度调整标记大小
            marker_size = 80 + confidence * 60

            self.ax.scatter(center_x, center_y, s=marker_size, c=color, marker='o', 
                   linewidths=2, alpha=0.8, label=f'Target {i+1} (C:{confidence:.2f})')
            
            # 添加标注
            distance_text = f"{cluster_distance:.0f}mm\n{cluster_angle:.0f}°\nC:{confidence:.2f}"
            self.ax.annotate(distance_text, (center_x, center_y), 
                        xytext=(5, 5), textcoords='offset points',
                        color=color, fontsize=9, weight='bold')
    
    def _draw_robot_and_directions(self, target_angle, servo_angle):
        """绘制机器人位置和方向"""
        # 绘制机器人位置（原点）
        self.ax.scatter(0, 0, s=100, c='white', marker='o', edgecolors='red', 
                    linewidths=2, label='Robot')

        # 绘制机器人朝向
        self.ax.arrow(0, 0, 0, 200, head_width=50, head_length=50, fc='white', ec='white')

        # 绘制舵机指向方向
        corrected_servo_angle = (servo_angle - 90) % 360
        servo_display_angle = math.radians(90 - corrected_servo_angle)
        servo_x = 300 * math.cos(servo_display_angle)
        servo_y = 300 * math.sin(servo_display_angle)
        self.ax.arrow(0, 0, servo_x, servo_y, 
                    head_width=30, head_length=30, fc='yellow', ec='yellow',
                    alpha=0.7, label='Servo Direction')

        # 如果有目标，绘制目标方向线
        if target_angle is not None:
            target_display_angle = math.radians((360 - target_angle) % 360)
            target_x = 500 * math.cos(target_display_angle)
            target_y = 500 * math.sin(target_display_angle)
            self.ax.plot([0, target_x], [0, target_y], 'r--', linewidth=3, alpha=0.8, label='Target Direction')
    
    def _draw_angle_markers(self):
        """绘制角度刻度线"""
        for angle in [0, 90, 180, 270]:
            display_angle = math.radians(90 - angle)
            end_x = 400 * math.cos(display_angle)
            end_y = 400 * math.sin(display_angle)
            self.ax.plot([0, end_x], [0, end_y], 'w--', alpha=0.3, linewidth=0.5)
            label_x = 450 * math.cos(display_angle)
            label_y = 450 * math.sin(display_angle)
            self.ax.text(label_x, label_y, f'{angle}°', color='white', 
                        ha='center', va='center', fontsize=10)
    
    def _update_status_info(self, data):
        """更新状态信息"""
        try:
            # 更新目标信息
            target_angle = data.get('target_angle')
            target_distance = data.get('target_distance')
            
            if target_angle is not None and self.angle_var:
                self.angle_var.set(f"{target_angle:.1f}°")
            elif self.angle_var:
                self.angle_var.set("N/A")
                
            if target_distance is not None and self.distance_var:
                self.distance_var.set(f"{target_distance:.0f}mm")
            elif self.distance_var:
                self.distance_var.set("N/A")
            
            # 更新舵机信息
            servo_pan = data.get('servo_pan', 0)
            servo_tilt = data.get('servo_tilt', 0)
            if self.pan_var:
                self.pan_var.set(f"{servo_pan:.0f}°")
            if self.tilt_var:
                self.tilt_var.set(f"{servo_tilt:.0f}°")
            
            # 更新统计信息
            stats = data.get('stats', {})
            if self.scan_points_var:
                self.scan_points_var.set(str(stats.get('scan_points', 0)))
            if self.field_points_var:
                self.field_points_var.set(str(stats.get('field_points', 0)))
            if self.clusters_var:
                self.clusters_var.set(str(stats.get('clusters', 0)))
            if self.walls_var:
                self.walls_var.set(str(stats.get('walls', 0)))
            if self.midline_var:
                self.midline_var.set("Yes" if data.get('crossed_midline', False) else "No")
                
        except Exception as e:
            print(f"状态信息更新失败: {e}")
    
    def update_system_status(self, status, active=False):
        """更新系统状态"""
        if self.status_var:
            self.status_var.set(status)
        if self.status_label:
            self.status_label.configure(background='green' if active else 'red')
        if self.start_stop_button:
            self.start_stop_button.configure(text="Stop System" if active else "Manual Start")
    
    def run(self):
        """运行GUI主循环"""
        if hasattr(self, 'root'):
            self.root.mainloop()
    
    def shutdown(self):
        """关闭GUI"""
        self.stop_gui_updates()
        if hasattr(self, 'root'):
            try:
                self.root.quit()
                self.root.destroy()
            except:
                pass