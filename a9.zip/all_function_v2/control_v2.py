import RPi.GPIO as GPIO
import time
import math
import threading
import random
import numpy as np
import serial
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from control import MecanumCar
from lidar_processor import LidarProcessor
from servo_controller import ServoController
from target_detector import TargetDetector
from Boundary_detector import BoundaryDetector

# 配置参数
BOUNDARY_CONFIG = {
    'wall_distance_threshold': 80,
    'wall_exclusion_distance': 150,
    'min_wall_points': 15,
    'angle_tolerance': 20
}

CLUSTERING_CONFIG = {
    'eps': 80,
    'min_samples': 3,
    'target_size_min': 50,
    'target_size_max': 300,
    'density_threshold': 1.0,
    'outlier_filter': True
}

def main():
    # 创建机器人实例
    bot = LidarBattleBot()
    
    try:
        print("机器人系统已初始化")
        print("等待视觉模块发送触发命令（格式：$+角度1+角度2$，角度范围360-999）")
        print("系统将执行运动序列：前进->停顿->后退，然后进入战斗模式")
        
        # 启动Tkinter主循环
        bot.root.mainloop()
    
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        bot.shutdown()

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 首先初始化所有基本属性
        self.is_running = False
        self.system_active = False
        self.gui_running = False
        self.target_angle = None
        self.target_distance = None
        self.crossed_midline = False
        self.right_wall_distance = None
        self.base_speed = base_speed
        
        self.boundary_detector = BoundaryDetector(**BOUNDARY_CONFIG)

        # 添加缺失的运动参数（设置默认值）
        self.forward_start_up_time = 0.5
        self.forward_start_duty_cycles = [70, 70, 70, 70]
        self.forward_normal_duty_cycles = [60, 60, 60, 60]
        self.forward_duration = 2.0
        self.backward_start_up_time = 0.3
        self.backward_start_duty_cycles = [50, 50, 50, 50]
        self.backward_normal_duty_cycles = [40, 40, 40, 40]
        self.backward_duration = 1.0
        
        # 线程锁
        self.data_lock = threading.Lock()
        
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        # 初始化各个组件
        try:
            self.lidar = LidarProcessor(port=lidar_port, baudrate=230400)
            print("雷达初始化成功")
        except Exception as e:
            print(f"雷达初始化失败: {e}")
            self.lidar = MockLidarProcessor()
            
        try:
            self.car = MecanumCar(motor_pins)
            print("车辆控制初始化成功")
        except Exception as e:
            print(f"车辆控制初始化失败: {e}")
            self.car = MockMecanumCar()
            
        try:
            self.servo = ServoController()
            print("舵机控制器初始化成功")
        except Exception as e:
            print(f"舵机控制初始化失败: {e}")
            self.servo = MockServoController()
            
        try:
            # 修复：使用BOUNDARY_CONFIG中的参数初始化边界检测器
            self.boundary_detector = BoundaryDetector(**BOUNDARY_CONFIG)
            self.boundary_detector.use_geometric_detection = True  # 设置检测方法
            
            self.detector = TargetDetector(**CLUSTERING_CONFIG)
            # 确保目标检测器有边界检测器的引用
            self.detector.boundary_detector = self.boundary_detector
            print("检测器初始化成功")
        except Exception as e:
            print(f"检测器初始化失败: {e}")
            self.detector = MockTargetDetector()
            self.boundary_detector = MockBoundaryDetector()

        # 串口通信
        try:
            self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
            print("串口初始化成功")
        except Exception as e:
            print(f"串口初始化失败: {e}")
            self.camera_serial = MockSerial()
        
        # GUI相关初始化 - 确保在启动线程前完成
        self._init_gui()
        
        # 设置运行状态
        self.gui_running = True
        self.is_running = True
        
        # 启动监听线程
        self._start_threads()

    def _init_gui(self):
        """初始化GUI界面"""
        try:
            self.root = tk.Tk()
            self.root.title("Lidar Battle Bot - Enhanced Geometric Boundary Detection with Wall Exclusion")
            self.root.geometry("1500x1000")
            
            # 创建主框架
            main_frame = ttk.Frame(self.root)
            main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # 创建左侧控制面板
            control_frame = ttk.Frame(main_frame)
            control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
            
            # 创建图形显示区域
            plot_frame = ttk.Frame(main_frame)
            plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
            
            # 设置matplotlib图形
            plt.style.use('dark_background')
            self.fig, self.ax = plt.subplots(figsize=(10, 10), facecolor='black')
            self.ax.set_facecolor('black')
            self.ax.set_xlim(-4000, 4000)
            self.ax.set_ylim(-4000, 4000)
            self.ax.set_xlabel('X (mm)', color='white')
            self.ax.set_ylabel('Y (mm)', color='white')
            self.ax.set_title('Lidar Scan and Target Detection (Wall Exclusion)', color='white')
            self.ax.grid(True, alpha=0.3)
            self.ax.tick_params(colors='white')
            
            # 创建canvas
            self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
            self.canvas.draw()
            self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            # 设置控制面板的滚动条
            canvas_frame = tk.Canvas(control_frame, width=300)
            scrollbar = ttk.Scrollbar(control_frame, orient="vertical", command=canvas_frame.yview)
            scrollable_frame = ttk.Frame(canvas_frame)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas_frame.configure(scrollregion=canvas_frame.bbox("all"))
            )
            
            canvas_frame.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas_frame.configure(yscrollcommand=scrollbar.set)
            
            canvas_frame.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            # 创建控制组件
            self._create_control_widgets(scrollable_frame)
            
            print("GUI初始化成功")
            
        except Exception as e:
            print(f"GUI初始化失败: {e}")
            import traceback
            traceback.print_exc()

    def _start_threads(self):
        """启动所有监听线程"""
        try:
            self.listen_thread = threading.Thread(target=self._listen_for_trigger, daemon=True)
            self.listen_thread.start()
            print("触发监听线程已启动")
            
            # 确保GUI线程独立启动
            if self.gui_running:
                self.gui_thread = threading.Thread(target=self._update_gui_loop, daemon=True)
                self.gui_thread.start()
                print("GUI更新线程已启动")
                
        except Exception as e:
            print(f"线程启动失败: {e}")
            import traceback
            traceback.print_exc()

    def start_move_to_center(self):
        """开始向中线移动"""
        try:
            # 启动时记录右边墙的距离
            scan_data = self.lidar.get_enhanced_scan_data()
            if scan_data:
                right_angle = 270  # 右边方向
                self.right_wall_distance = scan_data.get(right_angle, (0, 0))[0]
                print(f"记录右边墙的距离: {self.right_wall_distance} mm")
            
            # 开始前进
            self.is_running = True
            threading.Thread(target=self.move_to_center, daemon=True).start()
        except Exception as e:
            print(f"启动移动失败: {e}")

    def move_to_center(self):
        """前进到中线位置,使用自定义占空比控制"""
        try:
            print("开始执行运动序列...")
            
            # 前进阶段
            print("阶段1: 向前运动")
            self.car.move_forward_with_custom_duty_cycles(
                self.forward_start_up_time, 
                self.forward_start_duty_cycles, 
                self.forward_normal_duty_cycles, 
                self.forward_duration
            )
            
            if not self.is_running:
                return
            
            # 中间停顿
            print("阶段2: 中间停顿")
            time.sleep(1.5)
            
            if not self.is_running:
                return
            
            # 后退阶段
            print("阶段3: 向后运动")
            self.car.move_backward_with_custom_duty_cycles(
                self.backward_start_up_time, 
                self.backward_start_duty_cycles, 
                self.backward_normal_duty_cycles, 
                self.backward_duration
            )
            
            print("运动序列执行完成")
            
        except Exception as e:
            print(f"运动序列执行异常: {e}")
        finally:
            # 无论如何都要停止
            self.car.stop()
            print("运动序列结束，小车停止")
        
        self.crossed_midline = True
        print("到达中线,开始战斗模式")
        self.start_battle_mode()

    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False

    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待视觉模块触发命令...")
        
        while self.is_running:
            try:
                if hasattr(self.camera_serial, 'in_waiting') and self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    # 检查是否为触发命令
                    if self._parse_trigger_command(data):
                        if not self.system_active:
                            print(f"接收到启动命令: {data}")
                            self.system_active = True
                            self._start_system()
                        else:
                            print(f"接收到停止命令: {data}")
                            self.system_active = False
                            self._stop_system()
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)

    def _toggle_system(self):
        """手动切换系统状态"""
        try:
            if not self.system_active:
                self.system_active = True
                self._start_system()
            else:
                self.system_active = False
                self._stop_system()
        except Exception as e:
            print(f"系统切换失败: {e}")

    def _start_system(self):
        """启动系统"""
        try:
            print("系统启动，开始前进到中线...")
            self.status_var.set("System Active - Moving to Center")
            self.status_label.configure(background='green')
            self.start_stop_button.configure(text="Stop System")
            
            # 开始前进到中心位置
            self.start_move_to_center()
        except Exception as e:
            print(f"系统启动失败: {e}")

    def _stop_system(self):
        """停止系统"""
        try:
            print("系统停止")
            self.is_running = False
            self.car.stop()
            # 舵机回到中位
            self.servo.set_horizontal_angle(0)
            self.servo.set_vertical_angle(0)
            
            self.status_var.set("System Stopped")
            self.status_label.configure(background='red')
            self.start_stop_button.configure(text="Manual Start")
        except Exception as e:
            print(f"系统停止失败: {e}")

    def lidar_data_thread(self):
        """处理雷达数据的线程"""
        print("雷达数据线程已启动")
        while self.is_running and self.system_active:
            try:
                scan_data = self.lidar.get_enhanced_scan_data()
                if scan_data:
                    # 检测场地内的目标
                    field_points = self.boundary_detector.detect_field_boundary(scan_data)
                    clusters = self.detector.cluster_targets(field_points)
                    
                    if clusters:
                        # 选择最近的目标
                        target = min(clusters, key=lambda x: x['distance'])
                        target_angle = target['angle']
                        target_distance = target['distance']
                        
                        with self.data_lock:
                            self.target_angle = target_angle
                            self.target_distance = target_distance
                        
                        self.track_target_with_servo(target_angle)
                        print(f"雷达检测到目标: 角度={target_angle:.1f}°, 距离={target_distance:.0f}mm")
                    else:
                        # 没有目标，进行随机移动
                        self._random_movement()
                
                time.sleep(0.1)
            except Exception as e:
                print(f"雷达数据处理异常: {e}")
                time.sleep(0.5)

    def _random_movement(self):
        """随机移动避免被攻击"""
        try:
            movement_type = random.choice(['translate', 'rotate'])
            
            if movement_type == 'translate':
                # 随机平移
                angle = random.randint(0, 360)
                speed = random.randint(30, 60)
                duration = random.uniform(0.5, 1.0)
                self.car.move(angle, speed, duration)
            else:
                # 随机旋转
                direction = random.choice(['left', 'right'])
                angle = random.randint(15, 45)
                duration = random.uniform(0.3, 0.8)
                if direction == 'left':
                    self.car.rotate_left(angle, duration)
                else:
                    self.car.rotate_right(angle, duration)
        except Exception as e:
            print(f"随机移动失败: {e}")

    def victory_signal_thread(self):
        """胜利信号线程"""
        print("胜利信号线程已启动")
        while self.is_running and self.system_active:
            try:
                # 检查是否到了发送胜利信号的时间
                time.sleep(1.0)
            except Exception as e:
                print(f"胜利信号处理异常: {e}")
                time.sleep(1.0)

    def _send_victory_signal(self):
        """发送胜利信号"""
        # 这里可以添加具体的胜利信号发送逻辑
        # 例如串口发送、GPIO输出等
        print("发送胜利信号")

    def start_battle_mode(self):
        """启动战斗模式"""
        try:
            if not self.crossed_midline:
                return
                
            self.is_running = True
            
            # 启动各个处理线程
            lidar_thread = threading.Thread(target=self.lidar_data_thread, daemon=True)
            victory_thread = threading.Thread(target=self.victory_signal_thread, daemon=True)
            
            lidar_thread.start()
            victory_thread.start()
            
            print("战斗模式已启动！")
            
            self.status_var.set("System Active - Battle Mode")
            
            return lidar_thread, victory_thread
        except Exception as e:
            print(f"战斗模式启动失败: {e}")

    def _create_control_widgets(self, parent):
        """创建控制组件"""
        try:
            # 系统状态显示
            ttk.Label(parent, text="System Status", font=('Arial', 12, 'bold')).pack(pady=5)
            self.status_var = tk.StringVar(value="Waiting for Trigger")
            self.status_label = ttk.Label(parent, textvariable=self.status_var, 
                                         background='red', foreground='white', font=('Arial', 10))
            self.status_label.pack(pady=5, fill=tk.X)
            
            # 启动/停止按钮
            self.start_stop_button = ttk.Button(parent, text="Manual Start", 
                                               command=self._toggle_system)
            self.start_stop_button.pack(pady=10, fill=tk.X)
            
            # 目标信息显示
            ttk.Label(parent, text="Target Information", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
            
            self.target_info_frame = ttk.Frame(parent)
            self.target_info_frame.pack(fill=tk.X, pady=5)
            
            ttk.Label(self.target_info_frame, text="Angle:").grid(row=0, column=0, sticky='w')
            self.angle_var = tk.StringVar(value="N/A")
            ttk.Label(self.target_info_frame, textvariable=self.angle_var).grid(row=0, column=1, sticky='w')
            
            ttk.Label(self.target_info_frame, text="Distance:").grid(row=1, column=0, sticky='w')
            self.distance_var = tk.StringVar(value="N/A")
            ttk.Label(self.target_info_frame, textvariable=self.distance_var).grid(row=1, column=1, sticky='w')
            
            # 舵机控制显示
            ttk.Label(parent, text="Servo Control", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
            
            servo_frame = ttk.Frame(parent)
            servo_frame.pack(fill=tk.X, pady=5)
            
            ttk.Label(servo_frame, text="Pan:").grid(row=0, column=0, sticky='w')
            self.pan_var = tk.StringVar(value="0°")
            ttk.Label(servo_frame, textvariable=self.pan_var).grid(row=0, column=1, sticky='w')
            
            ttk.Label(servo_frame, text="Tilt:").grid(row=1, column=0, sticky='w')
            self.tilt_var = tk.StringVar(value="0°")
            ttk.Label(servo_frame, textvariable=self.tilt_var).grid(row=1, column=1, sticky='w')
            
            # 统计信息
            ttk.Label(parent, text="Statistics", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
            
            stats_frame = ttk.Frame(parent)
            stats_frame.pack(fill=tk.X, pady=5)
            
            ttk.Label(stats_frame, text="Scan Points:").grid(row=0, column=0, sticky='w')
            self.scan_points_var = tk.StringVar(value="0")
            ttk.Label(stats_frame, textvariable=self.scan_points_var).grid(row=0, column=1, sticky='w')
            
            ttk.Label(stats_frame, text="Field Points:").grid(row=1, column=0, sticky='w')
            self.field_points_var = tk.StringVar(value="0")
            ttk.Label(stats_frame, textvariable=self.field_points_var).grid(row=1, column=1, sticky='w')
            
            ttk.Label(stats_frame, text="Clusters:").grid(row=2, column=0, sticky='w')
            self.clusters_var = tk.StringVar(value="0")
            ttk.Label(stats_frame, textvariable=self.clusters_var).grid(row=2, column=1, sticky='w')
            
            ttk.Label(stats_frame, text="Walls:").grid(row=3, column=0, sticky='w')
            self.walls_var = tk.StringVar(value="0")
            ttk.Label(stats_frame, textvariable=self.walls_var).grid(row=3, column=1, sticky='w')
            
            ttk.Label(stats_frame, text="Midline Crossed:").grid(row=4, column=0, sticky='w')
            self.midline_var = tk.StringVar(value="No")
            ttk.Label(stats_frame, textvariable=self.midline_var).grid(row=4, column=1, sticky='w')
            
        except Exception as e:
            print(f"控件创建失败: {e}")

    def track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        try:
            # 统一使用与GUI显示相同的角度映射关系
            # GUI中：corrected_servo_angle = (self.servo.pan_angle - 90) % 360
            # 所以控制时：servo_angle = (target_angle + 90) % 360
            
            # 计算舵机应该转到的角度（与GUI显示逻辑一致）
            target_servo_angle = (target_angle + 90) % 360
            
            # 将360度角度系统转换为舵机的0-180度系统
            if target_servo_angle > 180:
                target_servo_angle = 360 - target_servo_angle
                # 或者选择最近的等效角度
                if target_servo_angle > 90:
                    target_servo_angle = 180 - (target_servo_angle - 180)
            
            # 限制在舵机有效范围内
            target_servo_angle = max(0, min(180, target_servo_angle))
            
            # 设置舵机角度
            current_servo_angle = getattr(self.servo, 'pan_angle', 90)
            new_angle = self.servo.set_pan_angle(target_servo_angle)
            
            print(f"目标角度{target_angle}° -> 舵机角度{new_angle}°")
            
            # 更新GUI显示
            if hasattr(self, 'pan_var'):
                self.pan_var.set(f"{getattr(self.servo, 'pan_angle', 0):.0f}°")
                
        except Exception as e:
            print(f"舵机跟踪失败: {e}")

    def _update_gui_loop(self):
        """GUI更新循环"""
        print("GUI更新循环已启动")
        while getattr(self, 'gui_running', False):
            try:
                self._update_gui()
                time.sleep(0.1)  # 10Hz更新频率
            except Exception as e:
                print(f"GUI更新异常: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(0.5)
        print("GUI更新循环已停止")
    
    def _update_gui(self):
        """更新GUI显示"""
        try:
            # 获取雷达数据
            scan_data = getattr(self.lidar, 'scan_data', None) or self.lidar.get_enhanced_scan_data()
            if not scan_data:
                return
            
            # 清除上一次的绘图
            self.ax.clear()
            self.ax.set_xlim(-4000, 4000)
            self.ax.set_ylim(-4000, 4000)
            self.ax.set_xlabel('X (mm)', color='white')
            self.ax.set_ylabel('Y (mm)', color='white')
            self.ax.set_title('Lidar Scan and Target Detection (Geometric Boundary)', color='white')
            self.ax.grid(True, alpha=0.3)
            self.ax.tick_params(colors='white')
            self.ax.set_facecolor('black')
            
            # 处理雷达数据
            field_points = self.boundary_detector.detect_field_boundary(scan_data)
            
            # 如果使用几何检测，获取墙面信息
            detected_walls = []
            if hasattr(self.boundary_detector, 'use_geometric_detection') and self.boundary_detector.use_geometric_detection:
                # 重新运行几何检测以获取墙面信息
                points = []
                for angle in range(360):
                    distance, intensity = scan_data.get(angle, (0, 0))
                    if 500 < distance < 5000:
                        display_angle = math.radians(angle + 90)
                        x = distance * math.cos(display_angle)
                        y = distance * math.sin(display_angle)
                        points.append((x, y, angle, distance))
                
                if len(points) >= 50:
                    if hasattr(self.boundary_detector, '_detect_walls_ransac'):
                        detected_walls = self.boundary_detector._detect_walls_ransac(points)
                        if hasattr(self.boundary_detector, '_validate_walls'):
                            detected_walls = self.boundary_detector._validate_walls(detected_walls, points)
            
            clusters = self.detector.cluster_targets(field_points)
            
            # 绘制所有扫描点（灰色小点）
            all_points_x = []
            all_points_y = []
            for angle in range(360):
                distance, intensity = scan_data.get(angle, (0, 0))
                if distance > 0:
                    display_angle = math.radians(angle + 90)
                    x = distance * math.cos(display_angle)
                    y = distance * math.sin(display_angle)
                    all_points_x.append(x)
                    all_points_y.append(y)
            
            if all_points_x:
                self.ax.scatter(all_points_x, all_points_y, s=1, c='gray', alpha=0.5, label='Scan Points')
            
            # 绘制检测到的墙面
            if detected_walls:
                for i, wall in enumerate(detected_walls):
                    wall_points = wall.get('points', [])
                    if wall_points:
                        wall_x = [p[0] for p in wall_points]
                        wall_y = [p[1] for p in wall_points]
                        
                        # 绘制墙面点
                        wall_color = ['red', 'blue', 'yellow', 'orange'][i % 4]
                        self.ax.scatter(wall_x, wall_y, s=8, c=wall_color, alpha=0.8, 
                                      label=f'Wall {i+1} ({len(wall_points)} pts)')
                        
                        # 绘制拟合直线
                        line_params = wall.get('line', None)
                        if line_params:
                            a, b, c = line_params
                            if abs(b) > 0.001:  # 非垂直线
                                x_line = np.linspace(-4000, 4000, 100)
                                y_line = -(a * x_line + c) / b
                                # 只绘制在视图范围内的部分
                                valid_mask = (y_line >= -4000) & (y_line <= 4000)
                                if np.any(valid_mask):
                                    self.ax.plot(x_line[valid_mask], y_line[valid_mask], 
                                               color=wall_color, linestyle='--', alpha=0.7, linewidth=2)
                            else:  # 垂直线
                                x_line = -c / a
                                if -4000 <= x_line <= 4000:
                                    self.ax.axvline(x=x_line, color=wall_color, linestyle='--', 
                                                  alpha=0.7, linewidth=2)
            
            # 绘制场地内的点（绿色）
            if field_points:
                field_x = []
                field_y = []
                for p in field_points:
                    angle = math.atan2(p[1], p[0])
                    distance = math.sqrt(p[0]**2 + p[1]**2)
                    car_angle = (math.degrees(angle) + 90) % 360

                    display_angle = math.radians(car_angle - 90)
                    x = distance * math.cos(display_angle)
                    y = distance * math.sin(display_angle)
                    field_x.append(x)
                    field_y.append(y)

                if field_x:
                    self.ax.scatter(field_x, field_y, s=5, c='green', alpha=0.7, label='Field Points')

            colors = ['red', 'blue', 'yellow', 'orange', 'purple', 'cyan']

            # 绘制聚类结果
            for i, cluster in enumerate(clusters):
                color = colors[i % len(colors)]

                cluster_angle = cluster['angle']
                cluster_distance = cluster['distance']
                confidence = cluster.get('confidence', 0)

                # 与舵机控制逻辑一致的角度转换
                display_angle = math.radians((360 - cluster_angle) % 360)
                center_x = cluster_distance * math.cos(display_angle)
                center_y = cluster_distance * math.sin(display_angle)

                # 由于GUI中Y轴正方向是向下的,需要再次转换
                center_y = -center_y

                # 根据置信度调整标记大小
                marker_size = 80 + confidence * 60

                self.ax.scatter(center_x, center_y, s=marker_size, c=color, marker='o', 
                       linewidths=2, alpha=0.8, label=f'Target {i+1} (C:{confidence:.2f})')
                # 添加距离、角度和置信度标注
                distance_text = f"{cluster_distance:.0f}mm\n{cluster_angle:.0f}°\nC:{confidence:.2f}"
                self.ax.annotate(distance_text, (center_x, center_y), 
                            xytext=(5, 5), textcoords='offset points',
                            color=color, fontsize=9, weight='bold')

            # 绘制机器人位置（原点）
            self.ax.scatter(0, 0, s=100, c='white', marker='o', edgecolors='red', 
                        linewidths=2, label='Robot')

            # 绘制机器人朝向（车头方向为90度，即Y轴正方向）
            self.ax.arrow(0, 0, 0, 200, head_width=50, head_length=50, fc='white', ec='white')

            # 绘制舵机指向方向
            servo_angle = getattr(self.servo, 'pan_angle', 0)
            corrected_servo_angle = (servo_angle - 90) % 360
            servo_display_angle = math.radians(90 - corrected_servo_angle)
            servo_x = 300 * math.cos(servo_display_angle)
            servo_y = 300 * math.sin(servo_display_angle)
            self.ax.arrow(0, 0, servo_x, servo_y, 
                        head_width=30, head_length=30, fc='yellow', ec='yellow',
                        alpha=0.7, label='Servo Direction')

            # 如果有目标，绘制目标方向线
            if self.target_angle is not None:
                # 与舵机控制逻辑一致的角度转换
                target_display_angle = math.radians((360 - self.target_angle) % 360)
                target_x = 500 * math.cos(target_display_angle)
                target_y = 500 * math.sin(target_display_angle)
                self.ax.plot([0, target_x], [0, target_y], 'r--', linewidth=3, alpha=0.8, label='Target Direction')

            # 添加角度刻度线
            for angle in [0, 90, 180, 270]:
                display_angle = math.radians(90 - angle)
                end_x = 400 * math.cos(display_angle)
                end_y = 400 * math.sin(display_angle)
                self.ax.plot([0, end_x], [0, end_y], 'w--', alpha=0.3, linewidth=0.5)
                label_x = 450 * math.cos(display_angle)
                label_y = 450 * math.sin(display_angle)
                self.ax.text(label_x, label_y, f'{angle}°', color='white', 
                            ha='center', va='center', fontsize=10)

            # 添加图例
            self.ax.legend(loc='upper right', fontsize=8)

            # 重绘canvas
            self.canvas.draw()
            
            # 更新状态信息
            with self.data_lock:
                if self.target_angle is not None:
                    if hasattr(self, 'angle_var'):
                        self.angle_var.set(f"{self.target_angle:.1f}°")
                    if hasattr(self, 'distance_var'):
                        self.distance_var.set(f"{self.target_distance:.0f}mm")
                else:
                    if hasattr(self, 'angle_var'):
                        self.angle_var.set("N/A")
                    if hasattr(self, 'distance_var'):
                        self.distance_var.set("N/A")
            
            # 更新舵机位置
            servo_pan = getattr(self.servo, 'pan_angle', 0)
            servo_tilt = getattr(self.servo, 'tilt_angle', 0)
            if hasattr(self, 'pan_var'):
                self.pan_var.set(f"{servo_pan:.0f}°")
            if hasattr(self, 'tilt_var'):
                self.tilt_var.set(f"{servo_tilt:.0f}°")
            
            # 更新统计信息
            if hasattr(self, 'scan_points_var'):
                self.scan_points_var.set(str(len(all_points_x)))
            if hasattr(self, 'field_points_var'):
                self.field_points_var.set(str(len(field_points)))
            if hasattr(self, 'clusters_var'):
                self.clusters_var.set(str(len(clusters)))
            if hasattr(self, 'walls_var'):
                self.walls_var.set(str(len(detected_walls)))
            if hasattr(self, 'midline_var'):
                self.midline_var.set("Yes" if self.crossed_midline else "No")
                
        except Exception as e:
            print(f"GUI更新失败: {e}")

    def shutdown(self):
        """关闭系统"""
        try:
            print("正在关闭系统...")
            self.is_running = False
            self.system_active = False
            self.gui_running = False
            
            try:
                self.car.stop()
            except:
                pass
                
            try:
                self.servo.cleanup()
            except:
                pass
                
            try:
                self.lidar.shutdown()
            except:
                pass
                
            try:
                self.camera_serial.close()
            except:
                pass
                
            print("系统已关闭")
        except Exception as e:
            print(f"系统关闭异常: {e}")

# Mock类用于测试和开发
class MockLidarProcessor:
    def __init__(self):
        self.scan_data = {}
        
    def get_enhanced_scan_data(self):
        # 返回模拟数据
        data = {}
        for angle in range(360):
            distance = 1000 + random.randint(-100, 100)
            intensity = random.randint(50, 100)
            data[angle] = (distance, intensity)
        return data
        
    def shutdown(self):
        pass

class MockMecanumCar:
    def __init__(self, motor_pins=None):
        pass
        
    def move_forward_with_custom_duty_cycles(self, start_time, start_cycles, normal_cycles, duration):
        print(f"Mock: 前进 {duration}秒")
        time.sleep(duration)
        
    def move_backward_with_custom_duty_cycles(self, start_time, start_cycles, normal_cycles, duration):
        print(f"Mock: 后退 {duration}秒")
        time.sleep(duration)
        
    def move(self, angle, speed, duration):
        print(f"Mock: 移动角度{angle}°，速度{speed}，持续{duration}秒")
        
    def rotate_left(self, angle, duration):
        print(f"Mock: 左转{angle}°，持续{duration}秒")
        
    def rotate_right(self, angle, duration):
        print(f"Mock: 右转{angle}°，持续{duration}秒")
        
    def stop(self):
        print("Mock: 停止")

class MockServoController:
    def __init__(self):
        self.pan_angle = 90
        self.tilt_angle = 90
        
    def set_pan_angle(self, angle):
        self.pan_angle = angle
        return angle
        
    def set_horizontal_angle(self, angle):
        self.pan_angle = angle + 90
        
    def set_vertical_angle(self, angle):
        self.tilt_angle = angle + 90
        
    def cleanup(self):
        pass

class MockTargetDetector:
    def __init__(self, **kwargs):
        pass
        
    def cluster_targets(self, points):
        # 返回模拟聚类结果
        if not points:
            return []
        return [{'angle': 45, 'distance': 500, 'confidence': 0.8}]

class MockBoundaryDetector:
    def __init__(self, **kwargs):
        self.use_geometric_detection = True
        
    def detect_field_boundary(self, scan_data):
        # 返回模拟场地点
        points = []
        for angle in range(0, 360, 10):
            distance, _ = scan_data.get(angle, (1000, 50))
            x = distance * math.cos(math.radians(angle))
            y = distance * math.sin(math.radians(angle))
            points.append((x, y))
        return points

class MockSerial:
    def __init__(self, port=None, baudrate=None, timeout=None):
        self.in_waiting = 0
        
    def readline(self):
        return b"mock data\n"
        
    def close(self):
        pass

if __name__ == '__main__':
    main()