# robot_controller.py
"""
机器人控制模块，整合各种硬件控制
"""

import time
import threading
import random
import math
from robot_config import MOTION_CONFIG, MOTOR_PINS

class RobotController:
    def __init__(self, car=None, servo=None, lidar=None):
        self.car = car
        self.servo = servo
        self.lidar = lidar
        self.is_running = False
        self.crossed_midline = False
        self.right_wall_distance = None
        
        # 运动参数
        self.motion_config = MOTION_CONFIG.copy()
    
    def start_move_to_center(self):
        """开始向中线移动"""
        try:
            # 启动时记录右边墙的距离
            if self.lidar:
                scan_data = self.lidar.get_enhanced_scan_data()
                if scan_data:
                    right_angle = 270  # 右边方向
                    self.right_wall_distance = scan_data.get(right_angle, (0, 0))[0]
                    print(f"记录右边墙的距离: {self.right_wall_distance} mm")
            
            # 开始前进
            self.is_running = True
            threading.Thread(target=self._move_to_center_sequence, daemon=True).start()
        except Exception as e:
            print(f"启动移动失败: {e}")
    
    def _move_to_center_sequence(self):
        """执行移动到中心的序列"""
        try:
            print("开始执行运动序列...")
            
            # 前进阶段
            print("阶段1: 向前运动")
            self.car.move_forward_with_custom_duty_cycles(
                self.motion_config['forward_start_up_time'], 
                self.motion_config['forward_start_duty_cycles'], 
                self.motion_config['forward_normal_duty_cycles'], 
                self.motion_config['forward_duration']
            )
            
            if not self.is_running:
                return
            
            # 中间停顿
            print("阶段2: 中间停顿")
            time.sleep(1.5)
            
            if not self.is_running:
                return
            
            # 后退阶段
            print("阶段3: 向后运动")
            self.car.move_backward_with_custom_duty_cycles(
                self.motion_config['backward_start_up_time'], 
                self.motion_config['backward_start_duty_cycles'], 
                self.motion_config['backward_normal_duty_cycles'], 
                self.motion_config['backward_duration']
            )
            
            print("运动序列执行完成")
            
        except Exception as e:
            print(f"运动序列执行异常: {e}")
        finally:
            self.car.stop()
            print("运动序列结束，小车停止")
        
        self.crossed_midline = True
        print("到达中线")
    
    def track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        try:
            # 计算舵机应该转到的角度
            target_servo_angle = (target_angle + 90) % 360
            
            # 将360度角度系统转换为舵机的0-180度系统
            if target_servo_angle > 180:
                target_servo_angle = 360 - target_servo_angle
                if target_servo_angle > 90:
                    target_servo_angle = 180 - (target_servo_angle - 180)
            
            # 限制在舵机有效范围内
            target_servo_angle = max(0, min(180, target_servo_angle))
            
            # 设置舵机角度
            new_angle = self.servo.set_pan_angle(target_servo_angle)
            print(f"目标角度{target_angle}° -> 舵机角度{new_angle}°")
            
            return new_angle
                
        except Exception as e:
            print(f"舵机跟踪失败: {e}")
            return None
    
    def random_movement(self):
        """随机移动避免被攻击"""
        try:
            movement_type = random.choice(['translate', 'rotate'])
            
            if movement_type == 'translate':
                # 随机平移
                angle = random.randint(0, 360)
                speed = random.randint(30, 60)
                duration = random.uniform(0.5, 1.0)
                self.car.move(angle, speed, duration)
            else:
                # 随机旋转
                direction = random.choice(['left', 'right'])
                angle = random.randint(15, 45)
                duration = random.uniform(0.3, 0.8)
                if direction == 'left':
                    self.car.rotate_left(angle, duration)
                else:
                    self.car.rotate_right(angle, duration)
        except Exception as e:
            print(f"随机移动失败: {e}")
    
    def stop_all(self):
        """停止所有运动"""
        self.is_running = False
        try:
            self.car.stop()
            self.servo.set_horizontal_angle(0)
            self.servo.set_vertical_angle(0)
        except Exception as e:
            print(f"停止运动失败: {e}")
    
    def shutdown(self):
        """关闭控制器"""
        self.stop_all()
        try:
            if self.servo:
                self.servo.cleanup()
        except:
            pass