# robot_system.py
"""
机器人主系统，集成所有模块 - 修复版本
"""

import threading
import time
from robot_config import *
from communication_manager import CommunicationManager
from robot_controller import RobotController
from gui_manager import GUIManager
from battle_system import BattleSystem

# 导入硬件控制模块
try:
    from control import MecanumCar
    from lidar_processor import LidarProcessor
    from servo_controller import ServoController
    from target_detector import TargetDetector
    from Boundary_detector import BoundaryDetector
except ImportError as e:
    print(f"硬件模块导入失败: {e}")

class RobotSystem:
    def __init__(self):
        self.system_active = False
        self.is_running = True
        
        # 初始化硬件
        self._init_hardware()
        
        # 初始化各个管理器
        self._init_managers()
        
        # 数据锁
        self.data_lock = threading.Lock()
        
        print("机器人系统初始化完成")
    
    def _init_hardware(self):
        """初始化硬件组件"""
        try:
            # 初始化雷达
            self.lidar = LidarProcessor(
                port=COMMUNICATION_CONFIG['lidar_port'], 
                baudrate=COMMUNICATION_CONFIG['lidar_baudrate']
            )
            print("雷达初始化成功")
        except Exception as e:
            print(f"雷达初始化失败: {e}")
            self.lidar = MockLidarProcessor()
            
        try:
            # 初始化车辆控制
            self.car = MecanumCar(MOTOR_PINS)
            print("车辆控制初始化成功")
        except Exception as e:
            print(f"车辆控制初始化失败: {e}")
            self.car = MockMecanumCar()
            
        try:
            # 初始化舵机
            self.servo = ServoController()
            print("舵机控制器初始化成功")
        except Exception as e:
            print(f"舵机控制初始化失败: {e}")
            self.servo = MockServoController()
            
        try:
            # 初始化边界检测器
            print("初始化边界检测器...")
            self.boundary_detector = BoundaryDetector(
                wall_distance_threshold=BOUNDARY_CONFIG['wall_distance_threshold'],
                wall_exclusion_distance=BOUNDARY_CONFIG['wall_exclusion_distance'],
                min_wall_points=BOUNDARY_CONFIG['min_wall_points'],
                angle_tolerance=BOUNDARY_CONFIG['angle_tolerance']
            )
            self.boundary_detector.use_geometric_detection = True
            
            # 初始化目标检测器 - 将boundary_detector作为第一个参数传入
            print("初始化目标检测器...")
            self.detector = TargetDetector(
                boundary_detector=self.boundary_detector,
                min_cluster_size=CLUSTERING_CONFIG['min_cluster_size'],
                max_cluster_distance=CLUSTERING_CONFIG['max_cluster_distance']
            )
            print("检测器初始化成功")
        except Exception as e:
            print(f"检测器初始化失败: {e}")
            import traceback
            traceback.print_exc()
            print("使用Mock检测器...")
            self.detector = MockTargetDetector()
            self.boundary_detector = MockBoundaryDetector()
    
    def _init_managers(self):
        """初始化各个管理器"""
        # 初始化通信管理器
        self.communication = CommunicationManager(
            camera_port=COMMUNICATION_CONFIG['camera_port'],
            callback=self._on_trigger_received
        )
        
        # 初始化机器人控制器
        self.robot_controller = RobotController(
            car=self.car,
            servo=self.servo,
            lidar=self.lidar
        )
        
        # 初始化战斗系统
        self.battle_system = BattleSystem(
            lidar=self.lidar,
            detector=self.detector,
            boundary_detector=self.boundary_detector,
            robot_controller=self.robot_controller,
            communication=self.communication
        )
        
        # 初始化GUI管理器
        self.gui_manager = GUIManager(robot_system=self)
    
    def start(self):
        """启动系统"""
        try:
            print("启动机器人系统...")
            
            # 启动通信监听
            self.communication.start_listening()
            
            # 启动GUI更新
            self.gui_manager.start_gui_updates()
            
            print("等待视觉模块发送触发命令...")
            print("系统将执行运动序列：前进->停顿->后退，然后进入战斗模式")
            
            # 运行GUI主循环
            self.gui_manager.run()
            
        except KeyboardInterrupt:
            print("\n程序被用户中断")
        except Exception as e:
            print(f"程序异常: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.shutdown()
    
    def _on_trigger_received(self, trigger_data):
        """处理接收到的触发命令"""
        try:
            if not self.system_active:
                print(f"接收到启动命令: {trigger_data}")
                self._start_system()
            else:
                print(f"接收到停止命令: {trigger_data}")
                self._stop_system()
        except Exception as e:
            print(f"处理触发命令失败: {e}")
    
    def toggle_system(self):
        """手动切换系统状态"""
        try:
            if not self.system_active:
                self._start_system()
            else:
                self._stop_system()
        except Exception as e:
            print(f"系统切换失败: {e}")
    
    def _start_system(self):
        """启动系统"""
        try:
            print("系统启动，开始前进到中线...")
            self.system_active = True
            
            # 更新GUI状态
            self.gui_manager.update_system_status("System Active - Moving to Center", True)
            
            # 开始前进到中心位置
            self.robot_controller.start_move_to_center()
            
            # 等待到达中线后启动战斗模式
            threading.Thread(target=self._wait_and_start_battle, daemon=True).start()
            
        except Exception as e:
            print(f"系统启动失败: {e}")
    
    def _wait_and_start_battle(self):
        """等待到达中线后启动战斗模式"""
        # 等待运动序列完成
        while self.system_active and not self.robot_controller.crossed_midline:
            time.sleep(0.5)
        
        if self.system_active and self.robot_controller.crossed_midline:
            print("到达中线，启动战斗模式")
            self.battle_system.start_battle_mode()
            self.gui_manager.update_system_status("System Active - Battle Mode", True)
    
    def _stop_system(self):
        """停止系统"""
        try:
            print("系统停止")
            self.system_active = False
            
            # 停止各个子系统
            self.robot_controller.stop_all()
            self.battle_system.stop_battle_mode()
            
            # 更新GUI状态
            self.gui_manager.update_system_status("System Stopped", False)
            
        except Exception as e:
            print(f"系统停止失败: {e}")
    
    def get_display_data(self):
        """获取用于显示的数据"""
        try:
            # 获取雷达数据
            scan_data = self.lidar.get_enhanced_scan_data()
            
            # 处理雷达数据
            field_points = []
            detected_walls = []
            clusters = []
            
            if scan_data:
                # 使用boundary_detector检测边界
                boundary_points = self.boundary_detector.detect_boundary(scan_data)
                
                # 从边界点中提取场地内的点
                field_points = []
                for point in boundary_points:
                    x, y, angle, distance, intensity = point
                    # 判断是否为场地内的点
                    if distance < self.boundary_detector.max_target_distance:
                        field_points.append((x, y))
                
                # 检测目标聚类
                clusters = self.detector.cluster_targets(field_points)
                
                # 获取检测统计信息
                stats = self.boundary_detector.get_detection_statistics()
                if stats['total_detections'] > 0:
                    print(f"边界检测统计: 成功率 {stats['success_rate']:.1f}%")
            
            # 获取目标信息
            target_info = self.battle_system.get_current_target_info()
            
            # 统计信息
            scan_points = len([1 for angle in range(360) if scan_data and scan_data.get(angle, (0, 0))[0] > 0]) if scan_data else 0
            
            return {
                'scan_data': scan_data,
                'field_points': field_points,
                'clusters': clusters,
                'walls': detected_walls,
                'target_angle': target_info['angle'],
                'target_distance': target_info['distance'],
                'servo_angle': getattr(self.servo, 'pan_angle', 0),
                'servo_pan': getattr(self.servo, 'pan_angle', 0),
                'servo_tilt': getattr(self.servo, 'tilt_angle', 0),
                'crossed_midline': self.robot_controller.crossed_midline,
                'stats': {
                    'scan_points': scan_points,
                    'field_points': len(field_points),
                    'clusters': len(clusters),
                    'walls': len(detected_walls)
                }
            }
            
        except Exception as e:
            print(f"获取显示数据失败: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def shutdown(self):
        """关闭系统"""
        try:
            print("正在关闭系统...")
            self.is_running = False
            self.system_active = False
            
            # 关闭各个子系统
            if hasattr(self, 'battle_system'):
                self.battle_system.shutdown()
            
            if hasattr(self, 'robot_controller'):
                self.robot_controller.shutdown()
            
            if hasattr(self, 'communication'):
                self.communication.shutdown()
            
            if hasattr(self, 'gui_manager'):
                self.gui_manager.shutdown()
            
            # 关闭硬件
            try:
                if hasattr(self, 'lidar'):
                    self.lidar.shutdown()
            except:
                pass
                
            print("系统已关闭")
            
        except Exception as e:
            print(f"系统关闭异常: {e}")

# Mock类（用于开发和测试）
class MockLidarProcessor:
    def __init__(self):
        import random
        self.scan_data = {}
        
    def get_enhanced_scan_data(self):
        import random
        data = {}
        for angle in range(360):
            distance = 1000 + random.randint(-100, 100)
            intensity = random.randint(50, 100)
            data[angle] = (distance, intensity)
        return data
        
    def shutdown(self):
        pass

class MockMecanumCar:
    def __init__(self, motor_pins=None):
        pass
        
    def move_forward_with_custom_duty_cycles(self, start_time, start_cycles, normal_cycles, duration):
        print(f"Mock: 前进 {duration}秒")
        time.sleep(duration)
        
    def move_backward_with_custom_duty_cycles(self, start_time, start_cycles, normal_cycles, duration):
        print(f"Mock: 后退 {duration}秒")
        time.sleep(duration)
        
    def move(self, angle, speed, duration):
        print(f"Mock: 移动角度{angle}°，速度{speed}，持续{duration}秒")
        
    def rotate_left(self, angle, duration):
        print(f"Mock: 左转{angle}°，持续{duration}秒")
        
    def rotate_right(self, angle, duration):
        print(f"Mock: 右转{angle}°，持续{duration}秒")
        
    def stop(self):
        print("Mock: 停止")

class MockServoController:
    def __init__(self):
        self.pan_angle = 90
        self.tilt_angle = 90
        
    def set_pan_angle(self, angle):
        self.pan_angle = angle
        return angle
        
    def set_horizontal_angle(self, angle):
        self.pan_angle = angle + 90
        
    def set_vertical_angle(self, angle):
        self.tilt_angle = angle + 90
        
    def cleanup(self):
        pass

class MockTargetDetector:
    def __init__(self, boundary_detector=None, **kwargs):
        self.boundary_detector = boundary_detector
        
    def cluster_targets(self, points):
        import random
        if not points:
            return []
        return [{'angle': 45, 'distance': 500, 'confidence': 0.8}]

class MockBoundaryDetector:
    def __init__(self, **kwargs):
        self.use_geometric_detection = True
        self.max_target_distance = 3000
        
    def detect_boundary(self, scan_data):
        import math
        points = []
        for angle in range(0, 360, 10):
            distance, intensity = scan_data.get(angle, (1000, 50))
            x = distance * math.cos(math.radians(angle))
            y = distance * math.sin(math.radians(angle))
            points.append((x, y, angle, distance, intensity))
        return points
        
    def get_detection_statistics(self):
        return {'total_detections': 10, 'successful_detections': 8, 'success_rate': 80.0}
        
    def reset_statistics(self):
        pass