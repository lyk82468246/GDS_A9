# battle_system.py
"""
战斗系统模块，处理目标检测和战斗逻辑
"""

import threading
import time
import random

class BattleSystem:
    def __init__(self, lidar=None, detector=None, boundary_detector=None, robot_controller=None, communication=None):
        self.lidar = lidar
        self.detector = detector
        self.boundary_detector = boundary_detector
        self.robot_controller = robot_controller
        self.communication = communication
        
        self.is_active = False
        self.battle_thread = None
        self.victory_thread = None
        
        # 当前目标信息
        self.current_target = None
        self.target_angle = None
        self.target_distance = None
        
        # 数据锁
        self.data_lock = threading.Lock()
    
    def start_battle_mode(self):
        """启动战斗模式"""
        if not self.robot_controller.crossed_midline:
            print("尚未到达中线，无法启动战斗模式")
            return False
            
        try:
            self.is_active = True
            
            # 启动战斗线程
            self.battle_thread = threading.Thread(target=self._battle_loop, daemon=True)
            self.victory_thread = threading.Thread(target=self._victory_loop, daemon=True)
            
            self.battle_thread.start()
            self.victory_thread.start()
            
            print("战斗模式已启动！")
            return True
            
        except Exception as e:
            print(f"战斗模式启动失败: {e}")
            return False
    
    def stop_battle_mode(self):
        """停止战斗模式"""
        self.is_active = False
        if self.battle_thread:
            self.battle_thread.join(timeout=1.0)
        if self.victory_thread:
            self.victory_thread.join(timeout=1.0)
        print("战斗模式已停止")
    
    def _battle_loop(self):
        """战斗主循环"""
        print("战斗循环已启动")
        while self.is_active:
            try:
                # 获取雷达数据
                scan_data = self.lidar.get_enhanced_scan_data()
                if not scan_data:
                    time.sleep(0.1)
                    continue
                
                # 检测场地内的目标
                field_points = self.boundary_detector.detect_field_boundary(scan_data)
                clusters = self.detector.cluster_targets(field_points)
                
                if clusters:
                    # 选择最近的目标
                    target = min(clusters, key=lambda x: x['distance'])
                    
                    with self.data_lock:
                        self.current_target = target
                        self.target_angle = target['angle']
                        self.target_distance = target['distance']
                    
                    # 用舵机跟踪目标
                    self.robot_controller.track_target_with_servo(target['angle'])
                    print(f"检测到目标: 角度={target['angle']:.1f}°, 距离={target['distance']:.0f}mm")
                    
                    # 这里可以添加攻击逻辑
                    self._attack_target(target)
                    
                else:
                    # 没有目标，进行随机移动
                    with self.data_lock:
                        self.current_target = None
                        self.target_angle = None
                        self.target_distance = None
                    
                    self.robot_controller.random_movement()
                
                time.sleep(0.1)
                
            except Exception as e:
                print(f"战斗循环异常: {e}")
                time.sleep(0.5)
    
    def _attack_target(self, target):
        """攻击目标的逻辑"""
        try:
            # 这里可以添加具体的攻击逻辑
            # 例如：发射机制、移动策略等
            
            distance = target['distance']
            angle = target['angle']
            confidence = target.get('confidence', 0)
            
            # 根据距离和置信度决定攻击策略
            if distance < 1000 and confidence > 0.7:
                print(f"近距离高置信度目标，执行攻击！")
                # 这里添加攻击代码
            elif distance < 2000 and confidence > 0.5:
                print(f"中距离目标，调整位置后攻击")
                # 这里添加位置调整代码
            else:
                print(f"目标距离较远或置信度低，继续跟踪")
            
        except Exception as e:
            print(f"攻击目标失败: {e}")
    
    def _victory_loop(self):
        """胜利信号检测循环"""
        print("胜利信号循环已启动")
        while self.is_active:
            try:
                # 这里可以添加胜利条件检测
                # 例如：敌方机器人被击中、时间到等
                
                # 模拟胜利条件检测
                if self._check_victory_conditions():
                    self._send_victory_signal()
                    break
                
                time.sleep(1.0)
                
            except Exception as e:
                print(f"胜利信号循环异常: {e}")
                time.sleep(1.0)
    
    def _check_victory_conditions(self):
        """检查胜利条件"""
        # 这里可以添加具体的胜利条件检测逻辑
        # 例如：检测敌方机器人状态、比赛时间等
        return False
    
    def _send_victory_signal(self):
        """发送胜利信号"""
        try:
            if self.communication:
                self.communication.send_victory_signal()
            print("胜利信号已发送！")
        except Exception as e:
            print(f"发送胜利信号失败: {e}")
    
    def get_current_target_info(self):
        """获取当前目标信息"""
        with self.data_lock:
            return {
                'target': self.current_target,
                'angle': self.target_angle,
                'distance': self.target_distance
            }
    
    def shutdown(self):
        """关闭战斗系统"""
        self.stop_battle_mode()