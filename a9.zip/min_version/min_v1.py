import RPi.GPIO as GPIO
import time
import math
import serial
import threading

# 首先定义 MecanumCar 类
class MecanumCar:
    def __init__(self, pins):
        GPIO.setmode(GPIO.BCM)
        self.pins = pins
        self.pwm_frequency = 1000
        self.pwms = {}
        self.encoder_counts = {motor: 0 for motor in pins.keys()}
        
        for motor_name, motor_pins in pins.items():
            GPIO.setup(motor_pins['in1'], GPIO.OUT)
            GPIO.setup(motor_pins['in2'], GPIO.OUT)
            GPIO.setup(motor_pins['encoder_a'], GPIO.IN, pull_up_down=GPIO.PUD_UP)
            
            pwm1 = GPIO.PWM(motor_pins['in1'], self.pwm_frequency)
            pwm2 = GPIO.PWM(motor_pins['in2'], self.pwm_frequency)
            pwm1.start(0)
            pwm2.start(0)
            
            self.pwms[motor_name] = {'pwm1': pwm1, 'pwm2': pwm2}
            
            GPIO.add_event_detect(motor_pins['encoder_a'], GPIO.RISING, 
                                callback=lambda channel, name=motor_name: self._encoder_callback(channel, name))
    
    def _encoder_callback(self, channel, motor_name):
        self.encoder_counts[motor_name] += 1
    
    def set_motor_speed(self, motor_name, duty_cycle):
        if motor_name not in self.pwms:
            return
        
        pwm1 = self.pwms[motor_name]['pwm1']
        pwm2 = self.pwms[motor_name]['pwm2']
        
        if duty_cycle > 0:
            pwm1.ChangeDutyCycle(min(abs(duty_cycle), 100))
            pwm2.ChangeDutyCycle(0)
        elif duty_cycle < 0:
            pwm1.ChangeDutyCycle(0)
            pwm2.ChangeDutyCycle(min(abs(duty_cycle), 100))
        else:
            pwm1.ChangeDutyCycle(0)
            pwm2.ChangeDutyCycle(0)
    
    def move(self, direction_angle, speed, rotation_speed=0):
        angle_rad = math.radians(direction_angle)
        
        vx = speed * math.cos(angle_rad)
        vy = speed * math.sin(angle_rad)
        
        front_left_speed = vx - vy - rotation_speed
        front_right_speed = vx + vy + rotation_speed
        rear_left_speed = vx + vy - rotation_speed
        rear_right_speed = vx - vy + rotation_speed
        
        self.set_motor_speed('front_left', front_left_speed)
        self.set_motor_speed('front_right', front_right_speed)
        self.set_motor_speed('rear_left', rear_left_speed)
        self.set_motor_speed('rear_right', rear_right_speed)
    
    def move_forward_with_custom_duty_cycles(self, start_up_time, start_duty_cycles, normal_duty_cycles, duration):
        for motor_name, duty_cycle in start_duty_cycles.items():
            self.set_motor_speed(motor_name, duty_cycle)
        
        time.sleep(start_up_time)
        
        for motor_name, duty_cycle in normal_duty_cycles.items():
            self.set_motor_speed(motor_name, duty_cycle)
        
        time.sleep(duration)
        self.stop()
    
    def move_backward_with_custom_duty_cycles(self, start_up_time, start_duty_cycles, normal_duty_cycles, duration):
        for motor_name, duty_cycle in start_duty_cycles.items():
            self.set_motor_speed(motor_name, -duty_cycle)  # 负号表示反向
        
        time.sleep(start_up_time)
        
        for motor_name, duty_cycle in normal_duty_cycles.items():
            self.set_motor_speed(motor_name, -duty_cycle)  # 负号表示反向
        
        time.sleep(duration)
        self.stop()
    
    def stop(self):
        for motor_name in self.pwms.keys():
            self.set_motor_speed(motor_name, 0)
    
    def read_speeds(self):
        initial_counts = self.encoder_counts.copy()
        time.sleep(0.1)
        final_counts = self.encoder_counts.copy()
        
        speeds = {}
        for motor_name in self.encoder_counts.keys():
            count_diff = final_counts[motor_name] - initial_counts[motor_name]
            speed = count_diff / 0.1
            speeds[motor_name] = speed
        
        return speeds
    
    def __del__(self):
        try:
            for motor_name in self.pwms.keys():
                self.pwms[motor_name]['pwm1'].stop()
                self.pwms[motor_name]['pwm2'].stop()
            GPIO.cleanup()
        except:
            pass

# 然后定义 MecanumCarController 类
class MecanumCarController:
    def __init__(self, pins, serial_port='/dev/ttyUSB0', baudrate=9600):
        """
        初始化麦轮小车控制器
        
        参数:
        pins: 电机引脚配置
        serial_port: 串口设备路径
        baudrate: 串口波特率
        """
        # 初始化麦轮小车
        self.car = MecanumCar(pins)
        
        # 系统状态
        self.system_active = False
        self.is_running = False
        
        # 串口配置
        try:
            self.camera_serial = serial.Serial(serial_port, baudrate, timeout=1)
            print(f"串口 {serial_port} 连接成功")
        except Exception as e:
            print(f"串口连接失败: {e}")
            self.camera_serial = None
        
        # 启动监听线程
        if self.camera_serial:
            self.listen_thread = threading.Thread(target=self._listen_for_trigger, daemon=True)
            self.listen_thread.start()
    
    def _parse_trigger_command(self, data_str):
        """
        解析触发命令，格式为 $START$ 或 $STOP$
        也可以使用原始格式 $+角度1+角度2$
        """
        try:
            data_str = data_str.strip()
            
            # 简单的启动/停止命令
            if data_str == '$START$':
                return 'start'
            elif data_str == '$STOP$':
                return 'stop'
            
            # 原始格式兼容
            elif data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    try:
                        angle1 = int(parts[0])
                        angle2 = int(parts[1])
                        if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                            return 'start'
                    except ValueError:
                        pass
            
            return None
        except Exception as e:
            print(f"解析命令异常: {e}")
            return None
    
    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待摄像头触发命令...")
        
        while True:
            try:
                if self.camera_serial and self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode('utf-8', errors='ignore').strip()
                    print(f"接收到数据: {data}")
                    
                    command = self._parse_trigger_command(data)
                    
                    if command == 'start' and not self.system_active:
                        print(f"接收到启动命令: {data}")
                        self._start_system()
                    elif command == 'stop' and self.system_active:
                        print(f"接收到停止命令: {data}")
                        self._stop_system()
                    elif command:
                        print(f"系统已处于{'运行' if self.system_active else '停止'}状态")
                        
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                time.sleep(1)  # 异常时延长等待时间
                
            time.sleep(0.05)
    
    def _start_system(self):
        """启动系统并执行运动逻辑"""
        if self.system_active:
            return
            
        print("=== 系统启动 ===")
        self.system_active = True
        self.is_running = True
        
        # 在新线程中执行运动逻辑，避免阻塞串口监听
        motion_thread = threading.Thread(target=self._execute_motion_sequence, daemon=True)
        motion_thread.start()
    
    def _stop_system(self):
        """停止系统"""
        print("=== 系统停止 ===")
        self.system_active = False
        self.is_running = False
        self.car.stop()
    
    def _execute_motion_sequence(self):
        """执行完整的运动序列"""
        try:
            print("开始执行运动序列...")
            
            # 前进阶段
            print("阶段1: 向前运动")
            self.car.move_forward_with_custom_duty_cycles(
                forward_start_up_time, 
                forward_start_duty_cycles, 
                forward_normal_duty_cycles, 
                forward_duration
            )
            
            if not self.is_running:
                return
            
            # 中间停顿
            print("阶段2: 中间停顿")
            time.sleep(1.5)
            
            if not self.is_running:
                return
            
            # 后退阶段
            print("阶段3: 向后运动")
            self.car.move_backward_with_custom_duty_cycles(
                backward_start_up_time, 
                backward_start_duty_cycles, 
                backward_normal_duty_cycles, 
                backward_duration
            )
            
            print("运动序列执行完成")
            
        except Exception as e:
            print(f"运动序列执行异常: {e}")
        finally:
            # 无论如何都要停止
            self.car.stop()
            print("运动序列结束，小车停止")
    
    def manual_start(self):
        """手动启动"""
        if not self.system_active:
            print("手动启动系统")
            self._start_system()
        else:
            print("系统已在运行中")
    
    def manual_stop(self):
        """手动停止"""
        if self.system_active:
            print("手动停止系统")
            self._stop_system()
        else:
            print("系统已停止")
    
    def cleanup(self):
        """清理资源"""
        self._stop_system()
        if self.camera_serial:
            self.camera_serial.close()
    pass

# 修改主程序部分
if __name__ == "__main__":
    pins = {
        'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
        'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
        'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
        'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
    }
    
    # 运动参数
    forward_start_up_time = 0.05
    forward_start_duty_cycles = {
        'front_left': 99, 'front_right': 99,
        'rear_left': 99, 'rear_right': 99
    }
    forward_normal_duty_cycles = {
        'front_left': 100, 'front_right': 100,
        'rear_left': 100, 'rear_right': 100
    }
    forward_duration = 1.2
    
    backward_start_up_time = 0.3
    backward_start_duty_cycles = {
        'front_left': 99, 'front_right': 99,
        'rear_left': 70, 'rear_right': 99
    }
    backward_normal_duty_cycles = {
        'front_left': 100, 'front_right': 100,
        'rear_left': 75, 'rear_right': 100
    }
    backward_duration = 2.4
    
    controller = None  # 初始化变量
    
    try:
        # 创建控制器
        controller = MecanumCarController(pins, serial_port='/dev/ttyCH343USB0', baudrate=115200)
        
        print("麦轮小车控制系统启动")
        print("等待摄像头发送启动命令：$START$ 或 $STOP$")
        print("按 Ctrl+C 退出程序")
        
        # 主循环
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
        import traceback
        traceback.print_exc()  # 打印详细错误信息
    finally:
        if controller is not None:  # 检查 controller 是否已创建
            controller.cleanup()
        print("程序退出，资源已清理")