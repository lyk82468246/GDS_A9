import numpy as np
from sklearn.cluster import DBSCAN
from boundary_detector import BOUNDARY_CONFIG, EnhancedBoundaryDetector

CLUSTERING_CONFIG = {
    'eps': 100,
    'min_samples': 3,
    'target_size_min': 80,
    'target_size_max': 250,
    'min_cluster_points': 3,
    'density_threshold': 0.7,
    'confidence_weight_points': 0.4,
    'confidence_weight_density': 0.6,
    'max_clusters': 5,
    'outlier_filter': True,
    'outlier_threshold': 2.0,
}

class ImprovedTargetDetector:
    def __init__(self):
        self.field_size = 4000
        self.min_distance_threshold = 200
        self.max_distance_threshold = 5000
        
        self.boundary_change_threshold = BOUNDARY_CONFIG['change_threshold']
        self.smoothing_window = BOUNDARY_CONFIG['smoothing_window']
        self.outlier_tolerance = BOUNDARY_CONFIG['outlier_tolerance']
        self.boundary_percentile = BOUNDARY_CONFIG['boundary_percentile']
        self.min_continuity_points = BOUNDARY_CONFIG['min_continuity_points']
        self.distance_variance_threshold = BOUNDARY_CONFIG['distance_variance_threshold']
        self.use_geometric_detection = BOUNDARY_CONFIG['use_geometric_detection']
        
        self.clustering_eps = CLUSTERING_CONFIG['eps']
        self.clustering_min_samples = CLUSTERING_CONFIG['min_samples']
        self.target_size_range = (CLUSTERING_CONFIG['target_size_min'], CLUSTERING_CONFIG['target_size_max'])
        self.min_cluster_points = CLUSTERING_CONFIG['min_cluster_points']
        self.density_threshold = CLUSTERING_CONFIG['density_threshold']
        self.confidence_weight_points = CLUSTERING_CONFIG['confidence_weight_points']
        self.confidence_weight_density = CLUSTERING_CONFIG['confidence_weight_density']
        self.max_clusters = CLUSTERING_CONFIG['max_clusters']
        self.outlier_filter = CLUSTERING_CONFIG['outlier_filter']
        self.outlier_threshold = CLUSTERING_CONFIG['outlier_threshold']
        
        self.boundary_detector = EnhancedBoundaryDetector()

    def detect_field_boundary(self, scan_data):
        if self.use_geometric_detection:
            print("使用几何形状检测算法...")
            field_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
            
            if len(field_points) > 20:
                print(f"几何检测成功，识别到 {len(field_points)} 个场地内点")
                return field_points
            else:
                print("几何检测失败，回退到统计方法")
        
        return self._statistical_boundary_detection(scan_data)

    def _statistical_boundary_detection(self, scan_data):
        print("使用统计边界检测算法...")
        
        valid_points = []
        distances = []
        
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if self.min_distance_threshold < distance < self.max_distance_threshold:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                valid_points.append((x, y, angle, distance))
                distances.append(distance)
        
        print(f"统计检测收集到有效点数: {len(valid_points)}")
        
        if len(valid_points) < 10:
            return valid_points
        
        field_points = []
        
        distances_array = np.array(distances)
        median_distance = np.median(distances_array)
        std_distance = np.std(distances_array)
        q25 = np.percentile(distances_array, 25)
        q75 = np.percentile(distances_array, 75)
        
        print(f"距离统计: 中位数={median_distance:.0f}, 标准差={std_distance:.0f}, Q25={q25:.0f}, Q75={q75:.0f}")
        
        threshold_distance = q75 + (q75 - q25) * 0.3
        
        for i, (x, y, angle, distance) in enumerate(valid_points):
            if distance <= threshold_distance:
                field_points.append((x, y, angle, distance))
        
        print(f"统计检测识别到 {len(field_points)} 个场地内点 (阈值: {threshold_distance:.0f}mm)")
        return field_points

    def cluster_targets(self, field_points):
        if len(field_points) < self.min_cluster_points:
            return []
            
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        print(f"开始聚类分析，输入点数: {len(coordinates)}")
        
        if self.outlier_filter and len(coordinates) > 5:
            coordinates_before = len(coordinates)
            coordinates = self._filter_outliers(coordinates)
            print(f"异常值过滤: {coordinates_before} -> {len(coordinates)} 点")
            if len(coordinates) < self.min_cluster_points:
                return []
        
        clustering = DBSCAN(
            eps=self.clustering_eps,
            min_samples=self.clustering_min_samples
        ).fit(coordinates)
        
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:
                continue
                
            cluster_indices = [i for i in range(len(coordinates)) if labels[i] == label]
            cluster_points = [field_points[i] for i in cluster_indices if i < len(field_points)]
            
            if len(cluster_points) < self.min_cluster_points:
                continue
            
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range)
            
            cluster_area = x_range * y_range if x_range > 0 and y_range > 0 else 1
            density = len(cluster_points) / cluster_area * 1000
            
            if (self.target_size_range[0] <= cluster_size <= self.target_size_range[1] or 
                (cluster_size < self.target_size_range[0] and density > self.density_threshold)):
                
                center_x = np.mean(cluster_coords[:, 0])
                center_y = np.mean(cluster_coords[:, 1])
                
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                points_score = min(1.0, len(cluster_points) / 10.0)
                density_score = min(1.0, density / 2.0)
                confidence = (self.confidence_weight_points * points_score + 
                             self.confidence_weight_density * density_score)
                
                clusters.append({
                    'angle': target_angle,
                    'distance': target_distance,
                    'size': cluster_size,
                    'points': cluster_points,
                    'center': (center_x, center_y),
                    'confidence': confidence,
                    'density': density
                })
                
                print(f"发现目标聚类: 尺寸={cluster_size:.0f}mm, 点数={len(cluster_points)}, 置信度={confidence:.2f}")
        
        clusters.sort(key=lambda x: x['confidence'], reverse=True)
        clusters = clusters[:self.max_clusters]
        
        print(f"最终识别出 {len(clusters)} 个目标聚类")
        return clusters

    def _filter_outliers(self, coordinates):
        if len(coordinates) < 5:
            return coordinates
            
        distances = np.sqrt(coordinates[:, 0]**2 + coordinates[:, 1]**2)
        
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)
        
        valid_mask = np.abs(distances - mean_dist) <= self.outlier_threshold * std_dist
        
        return coordinates[valid_mask]

    def find_target(self, scan_data):
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        
        if clusters:
            best_target = clusters[0]
            for cluster in clusters[1:]:
                if (abs(cluster['confidence'] - best_target['confidence']) < 0.2 and 
                    cluster['distance'] < best_target['distance']):
                    best_target = cluster
            
            return best_target['angle'], best_target['distance']
        
        return None, None

    def update_clustering_params(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self, f'clustering_{key}'):
                setattr(self, f'clustering_{key}', value)
                CLUSTERING_CONFIG[key] = value
            elif key in ['target_size_min', 'target_size_max']:
                if key == 'target_size_min':
                    self.target_size_range = (value, self.target_size_range[1])
                    CLUSTERING_CONFIG['target_size_min'] = value
                else:
                    self.target_size_range = (self.target_size_range[0], value)
                    CLUSTERING_CONFIG['target_size_max'] = value
            elif hasattr(self, key):
                setattr(self, key, value)
                CLUSTERING_CONFIG[key] = value
        
        print(f"聚类参数已更新: {kwargs}")