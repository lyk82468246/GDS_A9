import serial
import threading
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation
from lidar_processor import EnhancedLidarProcessor
from servo_controller import ServoController
from target_detector import ImprovedTargetDetector
from mecanum_wheel_car import MecanumCar

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        self.lidar = EnhancedLidarProcessor(port=lidar_port, baudrate=230400)
        self.car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.detector = ImprovedTargetDetector()
    
        self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
        
        self.base_speed = base_speed
        self.is_running = False
        self.system_active = False
        self.target_angle = None
        self.target_distance = None
        
        self.right_wall_distance = None
        self.forward_distance = 1000
        
        self.data_lock = threading.Lock()
        
        self.root = tk.Tk()
        self.root.title("Lidar Battle Bot - Enhanced Geometric Boundary Detection with Wall Exclusion")
        self.root.geometry("1500x1000")
        
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        plot_frame = ttk.Frame(main_frame)
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        plt.style.use('dark_background')
        self.fig, self.ax = plt.subplots(figsize=(10, 10), facecolor='black')
        self.ax.set_facecolor('black')
        self.ax.set_xlim(-4000, 4000)
        self.ax.set_ylim(-4000, 4000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Wall Exclusion)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        canvas_frame = tk.Canvas(control_frame)
        scrollbar = ttk.Scrollbar(control_frame, orient="vertical", command=canvas_frame.yview)
        scrollable_frame = ttk.Frame(canvas_frame)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas_frame.configure(scrollregion=canvas_frame.bbox("all"))
        )
        
        canvas_frame.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas_frame.configure(yscrollcommand=scrollbar.set)

    def start_move_to_center(self):
        scan_data = self.lidar.scan_data
        right_angle = 180
        self.right_wall_distance = scan_data.get(right_angle, (0, 0))[0]
        print(f"记录右边墙的距离: {self.right_wall_distance} mm")
        
        self.is_running = True
        threading.Thread(target=self.move_to_center).start()

    def move_to_center(self):
        current_distance = 0
        while self.is_running and current_distance < self.forward_distance:
            scan_data = self.lidar.scan_data

if __name__ == "__main__":
    bot = LidarBattleBot()
    bot.start_move_to_center()
    bot.root.mainloop()