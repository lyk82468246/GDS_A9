import serial
import threading
import time
import math
import random
import numpy as np

class EnhancedLidarProcessor:
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        self._valid_point_count = 0 
        self._total_point_count = 0

        self._point_buffer = {}
        self._complete_scans = []
        self.interpolation_density = 2

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[0:47]
                        del buffer[0:47]
                    
                        data = frame_data[2:]
                        frame = self._parse_frame(data)

                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_enhanced_scan_dict()
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        del buffer[0]
                    
                if len(buffer) > 1024:
                    del buffer[0:512]
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                buffer.clear()
                time.sleep(0.1)

    def _generate_enhanced_scan_dict(self):
        if not self._raw_points:
            return

        angle_groups = {}
        for angle, distance, intensity in self._raw_points:
            rounded_angle = round(angle * 2) / 2
            if rounded_angle not in angle_groups:
                angle_groups[rounded_angle] = []
            angle_groups[rounded_angle].append((distance, intensity))

        processed_points = {}
        angles = sorted(angle_groups.keys())
        
        for i in range(720):
            target_angle = i * 0.5
            
            if target_angle in angle_groups:
                distances = [d for d, i in angle_groups[target_angle]]
                if distances:
                    distances.sort()
                    median_dist = distances[len(distances)//2]
                    
                    if len(distances) > 1:
                        threshold = median_dist * 0.2
                        valid_distances = [d for d in distances 
                                         if abs(d - median_dist) <= threshold]
                        if valid_distances:
                            final_distance = sum(valid_distances) / len(valid_distances)
                        else:
                            final_distance = median_dist
                    else:
                        final_distance = median_dist
                    
                    processed_points[target_angle] = (final_distance, 50)
            else:
                interpolated_value = self._advanced_interpolate(target_angle, angle_groups)
                processed_points[target_angle] = interpolated_value

        final_dict = {}
        for target_angle in range(360):
            candidates = []
            for precise_angle in [target_angle - 0.5, target_angle, target_angle + 0.5]:
                if precise_angle in processed_points:
                    candidates.append(processed_points[precise_angle])
            
            if candidates:
                distances = [c[0] for c in candidates]
                distances.sort()
                final_distance = distances[len(distances)//2]
                final_dict[target_angle] = (final_distance, 50)
            else:
                final_dict[target_angle] = (0, 0)

        adjusted_dict = {}
        for lidar_angle in range(360):
            car_angle = (360 - (lidar_angle + 90) - 90 + 7) % 360
            adjusted_dict[car_angle] = final_dict[lidar_angle]

        with self._lock:
            self._scan_dict = adjusted_dict

    def _advanced_interpolate(self, target_angle, angle_groups):
        angles = sorted(angle_groups.keys())
        if not angles:
            return (0, 0)

        prev_angle = None
        next_angle = None
        
        for angle in angles:
            if angle <= target_angle:
                prev_angle = angle
            if angle >= target_angle and next_angle is None:
                next_angle = angle
                break

        if prev_angle is None:
            prev_angle = angles[-1]
        if next_angle is None:
            next_angle = angles[0]

        if prev_angle == next_angle:
            distances = [d for d, i in angle_groups[prev_angle]]
            return (sum(distances)/len(distances), 25) if distances else (0, 0)

        prev_distances = [d for d, i in angle_groups[prev_angle]]
        next_distances = [d for d, i in angle_groups[next_angle]]
        
        if not prev_distances or not next_distances:
            return (0, 0)

        prev_dist = sum(prev_distances) / len(prev_distances)
        next_dist = sum(next_distances) / len(next_distances)

        angle_diff = next_angle - prev_angle
        if angle_diff < 0:
            angle_diff += 360

        weight = (target_angle - prev_angle) / angle_diff if angle_diff > 0 else 0
        if weight < 0:
            weight += 1

        interpolated_distance = prev_dist + weight * (next_dist - prev_dist)
        return (interpolated_distance, 25)

    @property
    def scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def shutdown(self):
        self._running = False
        self.ser.close()