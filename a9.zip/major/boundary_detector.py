import math
import random
import numpy as np

BOUNDARY_CONFIG = {
    'change_threshold': 150,
    'smoothing_window': 7,
    'outlier_tolerance': 0.3,
    'boundary_percentile': 0.4,
    'min_continuity_points': 3,
    'distance_variance_threshold': 200,
    'use_geometric_detection': True,
    'wall_distance_threshold': 80,
    'min_wall_points': 10,
    'angle_tolerance': 15,
    'wall_exclusion_distance': 100,
}

class EnhancedBoundaryDetector:
    def __init__(self):
        self.field_size = 4000
        self.expected_field_shape = 'rectangle'
        self.wall_detection_distance = 3500
        self.min_wall_points = BOUNDARY_CONFIG['min_wall_points']
        self.angle_tolerance = BOUNDARY_CONFIG['angle_tolerance']
        self.wall_distance_threshold = BOUNDARY_CONFIG['wall_distance_threshold']
        self.wall_exclusion_distance = BOUNDARY_CONFIG['wall_exclusion_distance']
        self.detected_walls = []

    def detect_walls_by_geometry(self, scan_data):
        print("开始几何形状检测...")
        
        points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 5000:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                points.append((x, y, angle, distance))
        
        print(f"收集到有效点数: {len(points)}")
        
        if len(points) < 50:
            print("有效点数不足,无法进行几何检测")
            return []
        
        walls = self._detect_walls_ransac(points)
        print(f"检测到墙面数量: {len(walls)}")
        
        valid_walls = self._validate_walls(walls, points)
        print(f"有效墙面数量: {len(valid_walls)}")
        
        self.detected_walls = valid_walls
        
        field_points = self._filter_points_by_walls_with_exclusion(points, valid_walls)
        print(f"场地内点数: {len(field_points)}")
        
        return field_points

    def _detect_walls_ransac(self, points, max_walls=4):
        walls = []
        remaining_points = points.copy()
        
        for wall_idx in range(max_walls):
            if len(remaining_points) < 20:
                break
            
            best_wall = None
            best_inliers = []
            max_inliers = 0
            
            for iteration in range(200):
                if len(remaining_points) < 2:
                    break
                    
                sample = random.sample(remaining_points, 2)
                p1, p2 = sample[0][:2], sample[1][:2]
                
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                
                if abs(dx) < 1 and abs(dy) < 1:
                    continue
                
                a = dy
                b = -dx
                c = dx * p1[1] - dy * p1[0]
                
                norm = math.sqrt(a*a + b*b)
                if norm > 0:
                    a, b, c = a/norm, b/norm, c/norm
                else:
                    continue
                
                inliers = []
                for point in remaining_points:
                    x, y = point[0], point[1]
                    dist = abs(a*x + b*y + c)
                    if dist < self.wall_distance_threshold:
                        inliers.append(point)
                
                if len(inliers) > max_inliers and len(inliers) >= self.min_wall_points:
                    max_inliers = len(inliers)
                    best_wall = (a, b, c)
                    best_inliers = inliers.copy()
            
            if best_wall and len(best_inliers) >= self.min_wall_points:
                wall_info = {
                    'line': best_wall,
                    'points': best_inliers,
                    'point_count': len(best_inliers),
                    'id': wall_idx
                }
                walls.append(wall_info)
                
                print(f"检测到墙面 {wall_idx}: {len(best_inliers)} 个点")
                
                remaining_points = [p for p in remaining_points if p not in best_inliers]
        
        return walls

    def _validate_walls(self, walls, all_points):
        valid_walls = []
        
        for wall in walls:
            a, b, c = wall['line']
            points = wall['points']
            
            if len(points) < self.min_wall_points:
                continue
            
            wall_angle = math.degrees(math.atan2(-a, -b)) % 180
            
            angle_diff_horizontal = min(abs(wall_angle), abs(wall_angle - 180))
            angle_diff_vertical = abs(wall_angle - 90)
            angle_diff_diagonal1 = min(abs(wall_angle - 45), abs(wall_angle - 135))
            angle_diff_diagonal2 = min(abs(wall_angle - 225), abs(wall_angle - 315))
            
            if (angle_diff_horizontal <= self.angle_tolerance or 
                angle_diff_vertical <= self.angle_tolerance or
                angle_diff_diagonal1 <= self.angle_tolerance or
                angle_diff_diagonal2 <= self.angle_tolerance):
                
                wall['angle'] = wall_angle
                valid_walls.append(wall)
                print(f"验证墙面 {wall['id']}: 角度={wall_angle:.1f}°")
        
        return valid_walls

    def _filter_points_by_walls_with_exclusion(self, points, walls):
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points
        
        field_points = []
        wall_points = []
        excluded_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            is_excluded_point = False
            min_wall_distance = float('inf')
            
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                if distance_to_wall < self.wall_distance_threshold * 1.5:
                    is_wall_point = True
                    wall_points.append(point)
                    break
                elif distance_to_wall < self.wall_exclusion_distance:
                    is_excluded_point = True
                    excluded_points.append(point)
                    print(f"排除墙面附近的点: 距离={distance_to_wall:.0f}mm")
                    break
            
            if not is_wall_point and not is_excluded_point and min_wall_distance > self.wall_exclusion_distance:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 排除点={len(excluded_points)}, 场地点={len(field_points)}")
        return field_points

    def _filter_points_by_walls(self, points, walls):
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points
        
        field_points = []
        wall_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            min_wall_distance = float('inf')
            
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                if distance_to_wall < self.wall_distance_threshold * 1.5:
                    is_wall_point = True
                    wall_points.append(point)
                    break
            
            if not is_wall_point and min_wall_distance > self.wall_distance_threshold * 2:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 场地点={len(field_points)}")
        return field_points