#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import re
import serial
import threading
import time
import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
from peripherals import Peripherals
from mecanum_wheel_car import MecanumCar
from adafruit_servokit import ServoKit

# 全局边界检测配置
BOUNDARY_CONFIG = {
    'change_threshold': 150,      # 边界变化阈值(mm) - 增大以容忍更多不规则
    'smoothing_window': 7,        # 平滑窗口大小 - 增大以减少噪声影响
    'outlier_tolerance': 0.3,     # 异常值容忍度 (0-1) - 高值容忍更多异常点
    'boundary_percentile': 0.4,   # 边界检测百分位数 - 使用更保守的百分位
    'min_continuity_points': 3,   # 边界连续性最小点数
    'distance_variance_threshold': 200,  # 距离方差阈值
    'use_geometric_detection': True,  # 启用几何形状检测
    'wall_distance_threshold': 80,    # 墙面点距离阈值(mm)
    'min_wall_points': 10,            # 每面墙最少点数
    'angle_tolerance': 20,            # 墙面角度容忍度
}

# 全局聚类识别配置
CLUSTERING_CONFIG = {
    'eps': 120,                    # DBSCAN聚类半径(mm) - 控制聚类的紧密程度
    'min_samples': 2,             # DBSCAN最小样本数 - 形成聚类所需的最少点数
    'target_size_min': 50,        # 目标最小尺寸(mm)
    'target_size_max': 250,       # 目标最大尺寸(mm) 
    'min_cluster_points': 2,      # 有效聚类最少点数
    'density_threshold': 0.5,     # 小目标密度阈值 - 允许小但密集的目标
    'confidence_weight_points': 0.4,    # 点数在置信度计算中的权重
    'confidence_weight_density': 0.7,   # 密度在置信度计算中的权重
    'max_clusters': 3,           # 最大聚类数量限制
    'outlier_filter': True,       # 启用异常值过滤
    'outlier_threshold': 2.0,     # 异常值标准差阈值
}

class BoundaryDetector:
    """增强的边界检测器,专门处理平行四边形场地"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.expected_field_shape = 'rectangle'  # 期望的场地形状
        self.wall_detection_distance = 3500  # 墙面检测距离阈值
        self.min_wall_points = BOUNDARY_CONFIG['min_wall_points']
        self.angle_tolerance = BOUNDARY_CONFIG['angle_tolerance']
        self.wall_distance_threshold = BOUNDARY_CONFIG['wall_distance_threshold']
        
    def detect_walls_by_geometry(self, scan_data):
        """基于几何形状检测墙面边界"""
        #print("开始几何形状检测...")
        
        # 1. 收集所有有效点
        points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 5000:  # 有效距离范围
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                points.append((x, y, angle, distance))
        
        print(f"收集到有效点数: {len(points)}")
        
        if len(points) < 50:
            print("有效点数不足,无法进行几何检测")
            return []
        
        # 2. 使用RANSAC算法检测直线（墙面）
        walls = self._detect_walls_ransac(points)
        #print(f"检测到墙面数量: {len(walls)}")
        
        # 3. 过滤和验证墙面
        valid_walls = self._validate_walls(walls, points)
        #print(f"有效墙面数量: {len(valid_walls)}")
        
        # 4. 根据墙面确定场地内的点
        field_points = self._filter_points_by_walls(points, valid_walls)
        #print(f"场地内点数: {len(field_points)}")
        
        return field_points
    
    def _detect_walls_ransac(self, points, max_walls=4):
        """使用RANSAC算法检测墙面直线"""
        walls = []
        remaining_points = points.copy()
        
        for wall_idx in range(max_walls):
            if len(remaining_points) < 20:
                break
            
            best_wall = None
            best_inliers = []
            max_inliers = 0
            
            # RANSAC迭代
            for iteration in range(200):  # 增加迭代次数
                # 随机选择两个点
                if len(remaining_points) < 2:
                    break
                    
                sample = random.sample(remaining_points, 2)
                p1, p2 = sample[0][:2], sample[1][:2]
                
                # 计算直线参数 ax + by + c = 0
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                
                if abs(dx) < 1 and abs(dy) < 1:
                    continue
                
                # 直线方程: (y2-y1)x - (x2-x1)y + (x2-x1)y1 - (y2-y1)x1 = 0
                a = dy
                b = -dx
                c = dx * p1[1] - dy * p1[0]
                
                # 归一化
                norm = math.sqrt(a*a + b*b)
                if norm > 0:
                    a, b, c = a/norm, b/norm, c/norm
                else:
                    continue
                
                # 找到内点
                inliers = []
                for point in remaining_points:
                    x, y = point[0], point[1]
                    dist = abs(a*x + b*y + c)
                    if dist < self.wall_distance_threshold:  # 距离阈值
                        inliers.append(point)
                
                # 更新最佳结果
                if len(inliers) > max_inliers and len(inliers) >= self.min_wall_points:
                    max_inliers = len(inliers)
                    best_wall = (a, b, c)
                    best_inliers = inliers.copy()
            
            # 如果找到有效墙面
            if best_wall and len(best_inliers) >= self.min_wall_points:
                wall_info = {
                    'line': best_wall,
                    'points': best_inliers,
                    'point_count': len(best_inliers),
                    'id': wall_idx
                }
                walls.append(wall_info)
                
                #print(f"检测到墙面 {wall_idx}: {len(best_inliers)} 个点")
                
                # 从剩余点中移除已识别的墙面点
                remaining_points = [p for p in remaining_points if p not in best_inliers]
        
        return walls
    
    def _validate_walls(self, walls, all_points):
        """验证检测到的墙面"""
        valid_walls = []
        
        for wall in walls:
            a, b, c = wall['line']
            points = wall['points']
            
            if len(points) < self.min_wall_points:
                continue
            
            # 计算墙面的方向角
            wall_angle = math.degrees(math.atan2(-a, -b)) % 180
            
            # 检查是否接近水平或垂直（期望的墙面方向）
            # 但对于平行四边形,可能需要更宽松的角度判断
            angle_diff_horizontal = min(abs(wall_angle), abs(wall_angle - 180))
            angle_diff_vertical = abs(wall_angle - 90)
            angle_diff_diagonal1 = min(abs(wall_angle - 45), abs(wall_angle - 135))
            angle_diff_diagonal2 = min(abs(wall_angle - 225), abs(wall_angle - 315))
            
            # 接受水平、垂直或斜向的墙面（适应平行四边形）
            if (angle_diff_horizontal <= self.angle_tolerance or 
                angle_diff_vertical <= self.angle_tolerance or
                angle_diff_diagonal1 <= self.angle_tolerance or
                angle_diff_diagonal2 <= self.angle_tolerance):
                
                wall['angle'] = wall_angle
                valid_walls.append(wall)
                #print(f"验证墙面 {wall['id']}: 角度={wall_angle:.1f}°")
        
        return valid_walls
    
    def _filter_points_by_walls(self, points, walls):
        """根据检测到的墙面过滤场地内的点"""
        if not walls:
            #print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
            
            if not is_wall_point and min_wall_distance > self.wall_distance_threshold * 2:
                field_points.append(point)
        
        #print(f"分类结果: 墙面点={len(wall_points)}, 场地点={len(field_points)}")
        return field_points

class LidarProcessor:
    """增强的雷达数据处理器,提高数据密度和准确性"""
    
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        # 增加数据缓存用于插值
        self._point_buffer = {}  # 按角度存储多个点
        self._complete_scans = []  # 存储最近的完整扫描
        self.interpolation_density = 2  # 插值密度倍数

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[0:47]
                        del buffer[0:47]
                    
                        data = frame_data[2:]
                        frame = self._parse_frame(data)

                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_enhanced_scan_dict()
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        del buffer[0]
                    
                if len(buffer) > 1024:
                    del buffer[0:512]
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                buffer.clear()
                time.sleep(0.1)

    def _generate_enhanced_scan_dict(self):
        """生成增强的扫描字典,通过多层优化提高数据质量"""
        with self._lock:
            # 1. 创建新的扫描字典
            new_scan_dict = dict.fromkeys(range(360), (0, 0))
            
            # 2. 数据预处理和去噪
            filtered_points = self._filter_noise(self._raw_points)
            
            # 3. 按角度分组
            angle_groups = {}
            for angle, distance, intensity in filtered_points:
                angle_int = int(round(angle)) % 360
                if angle_int not in angle_groups:
                    angle_groups[angle_int] = []
                angle_groups[angle_int].append((distance, intensity))
            
            # 4. 对每个角度计算最优值
            for angle, values in angle_groups.items():
                if values:
                    # 计算中位数距离以减少异常值影响
                    distances = [v[0] for v in values]
                    intensities = [v[1] for v in values]
                    
                    median_distance = np.median(distances)
                    mean_intensity = np.mean(intensities)
                    
                    new_scan_dict[angle] = (int(median_distance), int(mean_intensity))
            
            # 5. 插值填充空缺角度
            new_scan_dict = self._interpolate_missing_angles(new_scan_dict)
            
            # 6. 平滑滤波
            new_scan_dict = self._smooth_scan_data(new_scan_dict)
            
            # 7. 更新扫描字典
            self._scan_dict = new_scan_dict

    def _filter_noise(self, points):
        """多层噪声过滤"""
        if not points:
            return []
        
        filtered = []
        for angle, distance, intensity in points:
            # 基本范围检查
            if not (50 <= distance <= 6000 and 0 <= intensity <= 255):
                continue
            
            # 强度过滤 - 保留一定强度的点
            if intensity < 5:  # 降低强度阈值,保留更多数据
                continue
                
            filtered.append((angle, distance, intensity))
        
        return filtered

    def _interpolate_missing_angles(self, scan_dict):
        """智能插值填充缺失角度"""
        angles_with_data = [a for a in range(360) if scan_dict[a][0] > 0]
        
        if len(angles_with_data) < 2:
            return scan_dict
        
        # 对没有数据的角度进行插值
        for angle in range(360):
            if scan_dict[angle][0] == 0:  # 如果该角度没有数据
                # 找到最近的有数据的角度
                distances = []
                for offset in range(1, 15):  # 搜索范围增加到±15度
                    for direction in [-1, 1]:
                        check_angle = (angle + direction * offset) % 360
                        if scan_dict[check_angle][0] > 0:
                            distances.append(check_angle)
                            break
                    if len(distances) >= 2:
                        break
                
                if len(distances) >= 2:
                    # 使用最近两个点进行线性插值
                    a1, a2 = distances[0], distances[1]
                    d1, i1 = scan_dict[a1]
                    d2, i2 = scan_dict[a2]
                    
                    # 角度差异处理(考虑360度循环)
                    if abs(a2 - a1) > 180:
                        if a1 > a2:
                            a2 += 360
                        else:
                            a1 += 360
                    
                    # 计算插值
                    if a1 != a2:
                        ratio = (angle - a1) / (a2 - a1) if angle >= a1 else (360 + angle - a1) / (a2 - a1)
                        ratio = max(0, min(1, ratio))
                        
                        interpolated_distance = int(d1 + (d2 - d1) * ratio)
                        interpolated_intensity = int(i1 + (i2 - i1) * ratio)
                        
                        scan_dict[angle] = (interpolated_distance, interpolated_intensity)
        
        return scan_dict

    def _smooth_scan_data(self, scan_dict):
        """应用平滑滤波减少噪声"""
        smoothed = scan_dict.copy()
        window_size = 3  # 减小窗口以保持更多细节
        
        for angle in range(360):
            distances = []
            intensities = []
            
            for offset in range(-window_size//2, window_size//2 + 1):
                check_angle = (angle + offset) % 360
                d, i = scan_dict[check_angle]
                if d > 0:
                    distances.append(d)
                    intensities.append(i)
            
            if distances:
                # 使用中位数而不是均值,更好地保持边缘
                smooth_distance = int(np.median(distances))
                smooth_intensity = int(np.median(intensities))
                smoothed[angle] = (smooth_distance, smooth_intensity)
        
        return smoothed

    def get_scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def stop(self):
        self._running = False
        if self._thread.is_alive():
            self._thread.join()
        self.ser.close()

class TargetTracker:
    """增强的目标跟踪器"""
    
    def __init__(self):
        self.boundary_detector = BoundaryDetector()
        self.last_targets = []
        self.target_history = []
        self.max_history = 10
        
        # 目标跟踪参数
        self.max_target_speed = 1000  # mm/s
        self.association_distance = 300  # mm
        
    def process_scan(self, scan_data):
        """处理扫描数据并识别目标"""
        # 1. 边界检测
        if BOUNDARY_CONFIG['use_geometric_detection']:
            field_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
        else:
            field_points = self._simple_boundary_filter(scan_data)
        
        if not field_points:
            print("没有检测到场地内的点")
            return []
        
        # 2. 聚类分析
        targets = self._cluster_and_identify_targets(field_points)
        
        # 3. 目标跟踪
        tracked_targets = self._track_targets(targets)
        
        # 4. 更新历史记录
        self.last_targets = tracked_targets
        self.target_history.append(tracked_targets)
        if len(self.target_history) > self.max_history:
            self.target_history.pop(0)
        
        return tracked_targets
    
    def _simple_boundary_filter(self, scan_data):
        """简单的边界过滤"""
        field_points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 3500:  # 简单距离过滤
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                field_points.append((x, y, angle, distance))
        return field_points
    
    def _cluster_and_identify_targets(self, field_points):
        """使用聚类算法识别目标"""
        if len(field_points) < CLUSTERING_CONFIG['min_samples']:
            return []
        
        # 准备聚类数据
        points_array = np.array([[p[0], p[1]] for p in field_points])
        
        # 执行DBSCAN聚类
        clustering = DBSCAN(
            eps=CLUSTERING_CONFIG['eps'],
            min_samples=CLUSTERING_CONFIG['min_samples']
        ).fit(points_array)
        
        labels = clustering.labels_
        unique_labels = set(labels)
        
        targets = []
        for label in unique_labels:
            if label == -1:  # 噪声点
                continue
            
            # 获取该聚类的所有点
            cluster_mask = (labels == label)
            cluster_points = points_array[cluster_mask]
            cluster_data = [field_points[i] for i in range(len(field_points)) if cluster_mask[i]]
            
            if len(cluster_points) < CLUSTERING_CONFIG['min_cluster_points']:
                continue
            
            # 计算目标特征
            target = self._calculate_target_features(cluster_points, cluster_data)
            if target:
                targets.append(target)
        
        # 限制目标数量
        if len(targets) > CLUSTERING_CONFIG['max_clusters']:
            targets.sort(key=lambda t: t['confidence'], reverse=True)
            targets = targets[:CLUSTERING_CONFIG['max_clusters']]
        
        return targets
    
    def _calculate_target_features(self, cluster_points, cluster_data):
        """计算目标特征"""
        if len(cluster_points) == 0:
            return None
        
        # 基本统计
        center_x = np.mean(cluster_points[:, 0])
        center_y = np.mean(cluster_points[:, 1])
        
        # 计算目标大小
        x_range = np.max(cluster_points[:, 0]) - np.min(cluster_points[:, 0])
        y_range = np.max(cluster_points[:, 1]) - np.min(cluster_points[:, 1])
        size = max(x_range, y_range)
        
        # 尺寸过滤
        if not (CLUSTERING_CONFIG['target_size_min'] <= size <= CLUSTERING_CONFIG['target_size_max']):
            return None
        
        # 计算密度
        area = max(x_range * y_range, 1)
        density = len(cluster_points) / area * 10000  # 归一化到每平方厘米
        
        # 计算置信度
        point_score = min(len(cluster_points) / 10.0, 1.0)  # 点数得分
        density_score = min(density / 5.0, 1.0)  # 密度得分
        
        confidence = (point_score * CLUSTERING_CONFIG['confidence_weight_points'] +
                     density_score * CLUSTERING_CONFIG['confidence_weight_density'])
        
        # 计算距离和角度
        distance = math.sqrt(center_x**2 + center_y**2)
        angle = math.degrees(math.atan2(center_y, center_x))
        if angle < 0:
            angle += 360
        
        return {
            'x': center_x,
            'y': center_y,
            'size': size,
            'point_count': len(cluster_points),
            'density': density,
            'confidence': confidence,
            'distance': distance,
            'angle': angle,
            'cluster_points': cluster_points.tolist()
        }
    
    def _track_targets(self, current_targets):
        """目标跟踪"""
        if not self.last_targets:
            return current_targets
        
        # 简单的最近邻关联
        tracked_targets = []
        used_indices = set()
        
        for last_target in self.last_targets:
            best_match = None
            best_distance = float('inf')
            best_index = -1
            
            for i, current_target in enumerate(current_targets):
                if i in used_indices:
                    continue
                
                # 计算距离
                dx = current_target['x'] - last_target['x']
                dy = current_target['y'] - last_target['y']
                distance = math.sqrt(dx*dx + dy*dy)
                
                if distance < self.association_distance and distance < best_distance:
                    best_match = current_target
                    best_distance = distance
                    best_index = i
            
            if best_match:
                used_indices.add(best_index)
                # 添加速度信息
                if 'x' in last_target and 'y' in last_target:
                    dt = 0.1  # 假设100ms更新间隔
                    vx = (best_match['x'] - last_target['x']) / dt
                    vy = (best_match['y'] - last_target['y']) / dt
                    best_match['velocity_x'] = vx
                    best_match['velocity_y'] = vy
                    best_match['speed'] = math.sqrt(vx*vx + vy*vy)
                tracked_targets.append(best_match)
        
        # 添加新发现的目标
        for i, target in enumerate(current_targets):
            if i not in used_indices:
                target['velocity_x'] = 0
                target['velocity_y'] = 0
                target['speed'] = 0
                tracked_targets.append(target)
        
        return tracked_targets

class RadarTargetDetector:
    """主要的雷达目标检测系统"""
    
    def __init__(self):
        print("初始化雷达目标检测系统...")
        
        try:
            self.lidar = LidarProcessor()
            print("✓ 雷达初始化成功")
        except Exception as e:
            print(f"✗ 雷达初始化失败: {e}")
            self.lidar = None
        
        self.target_tracker = TargetTracker()
        
        # 系统状态
        self.running = False
        self.detection_thread = None
        
        # 性能统计
        self.stats = {
            'total_scans': 0,
            'targets_detected': 0,
            'processing_time_avg': 0
        }
        
        print("雷达目标检测系统初始化完成")
    
    def start_detection(self):
        """启动目标检测"""
        if self.running:
            print("检测已在运行中")
            return
        
        if not self.lidar:
            print("雷达未初始化,无法启动检测")
            return
        
        self.running = True
        self.detection_thread = threading.Thread(target=self._detection_loop)
        self.detection_thread.daemon = True
        self.detection_thread.start()
        
        print("目标检测已启动")
    
    def stop_detection(self):
        """停止目标检测"""
        self.running = False
        if self.detection_thread and self.detection_thread.is_alive():
            self.detection_thread.join()
        print("目标检测已停止")
    
    def _detection_loop(self):
        """检测循环"""
        while self.running:
            try:
                start_time = time.time()
                
                # 获取扫描数据
                scan_data = self.lidar.get_scan_data()
                
                # 处理目标检测
                targets = self.target_tracker.process_scan(scan_data)
                
                # 更新统计
                processing_time = time.time() - start_time
                self.stats['total_scans'] += 1
                self.stats['targets_detected'] = len(targets)
                self.stats['processing_time_avg'] = (
                    self.stats['processing_time_avg'] * 0.9 + 
                    processing_time * 0.1
                )
                
                # 输出检测结果
                if targets:
                    print(f"检测到 {len(targets)} 个目标:")
                    for i, target in enumerate(targets):
                        print(f"  目标{i+1}: 位置({target['x']:.0f}, {target['y']:.0f})mm, "
                              f"距离{target['distance']:.0f}mm, 置信度{target['confidence']:.2f}")
                
                # 控制检测频率
                time.sleep(0.1)  # 10Hz检测频率
                
            except Exception as e:
                print(f"检测循环异常: {e}")
                time.sleep(0.5)
    
    def get_current_targets(self):
        """获取当前检测到的目标"""
        return self.target_tracker.last_targets
    
    def get_stats(self):
        """获取系统统计信息"""
        return self.stats.copy()
    
    def cleanup(self):
        """清理资源"""
        print("清理系统资源...")
        self.stop_detection()
        if self.lidar:
            self.lidar.stop()
        print("资源清理完成")

def main():
    """主函数 - 无GUI版本"""
    detector = RadarTargetDetector()
    
    try:
        print("启动雷达目标检测...")
        detector.start_detection()
        
        # 运行检测
        while True:
            time.sleep(1)
            
            # 每秒输出一次统计信息
            stats = detector.get_stats()
            targets = detector.get_current_targets()
            
            print(f"\n=== 系统状态 ===")
            print(f"总扫描次数: {stats['total_scans']}")
            print(f"当前目标数: {len(targets)}")
            print(f"平均处理时间: {stats['processing_time_avg']*1000:.1f}ms")
            
            if targets:
                print(f"目标详情:")
                for i, target in enumerate(targets):
                    print(f"  目标{i+1}: "
                          f"位置({target['x']:.0f},{target['y']:.0f}), "
                          f"大小{target['size']:.0f}mm, "
                          f"置信度{target['confidence']:.2f}")
    
    except KeyboardInterrupt:
        print("\n收到停止信号...")
    except Exception as e:
        print(f"运行异常: {e}")
    finally:
        detector.cleanup()
        print("程序结束")

if __name__ == "__main__":
    main()