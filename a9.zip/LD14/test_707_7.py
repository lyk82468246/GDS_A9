#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import serial
import threading
import bisect
import time
import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
from mecanum_wheel_car import MecanumCar
from adafruit_servokit import ServoKit
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

# 全局边界检测配置
BOUNDARY_CONFIG = {
    'change_threshold': 150,      # 边界变化阈值(mm) - 增大以容忍更多不规则
    'smoothing_window': 7,        # 平滑窗口大小 - 增大以减少噪声影响
    'outlier_tolerance': 0.3,     # 异常值容忍度 (0-1) - 高值容忍更多异常点
    'boundary_percentile': 0.4,   # 边界检测百分位数 - 使用更保守的百分位
    'min_continuity_points': 3,   # 边界连续性最小点数
    'distance_variance_threshold': 200,  # 距离方差阈值
    'use_geometric_detection': True,  # 启用几何形状检测
    'wall_distance_threshold': 80,    # 墙面点距离阈值(mm)
    'min_wall_points': 10,            # 每面墙最少点数
    'angle_tolerance': 15,            # 墙面角度容忍度
    'wall_exclusion_distance': 100,  # 墙面拟合线两侧排除距离(mm) - 新增全局变量
}

# 全局聚类识别配置
CLUSTERING_CONFIG = {
    'eps': 100,                    # DBSCAN聚类半径(mm) - 控制聚类的紧密程度
    'min_samples': 3,             # DBSCAN最小样本数 - 形成聚类所需的最少点数
    'target_size_min': 80,        # 目标最小尺寸(mm)
    'target_size_max': 250,       # 目标最大尺寸(mm) 
    'min_cluster_points': 3,      # 有效聚类最少点数
    'density_threshold': 0.7,     # 小目标密度阈值 - 允许小但密集的目标
    'confidence_weight_points': 0.4,    # 点数在置信度计算中的权重
    'confidence_weight_density': 0.6,   # 密度在置信度计算中的权重
    'max_clusters': 5,           # 最大聚类数量限制
    'outlier_filter': True,       # 启用异常值过滤
    'outlier_threshold': 2.0,     # 异常值标准差阈值
}

class EnhancedBoundaryDetector:
    """增强的边界检测器，专门处理平行四边形场地"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.expected_field_shape = 'rectangle'  # 期望的场地形状
        self.wall_detection_distance = 3500  # 墙面检测距离阈值
        self.min_wall_points = BOUNDARY_CONFIG['min_wall_points']
        self.angle_tolerance = BOUNDARY_CONFIG['angle_tolerance']
        self.wall_distance_threshold = BOUNDARY_CONFIG['wall_distance_threshold']
        self.wall_exclusion_distance = BOUNDARY_CONFIG['wall_exclusion_distance']  # 新增：墙面排除距离
        self.detected_walls = []  # 存储检测到的墙面信息
        
    def detect_walls_by_geometry(self, scan_data):
        """基于几何形状检测墙面边界"""
        print("开始几何形状检测...")
        
        # 1. 收集所有有效点
        points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 5000:  # 有效距离范围
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                points.append((x, y, angle, distance))
        
        print(f"收集到有效点数: {len(points)}")
        
        if len(points) < 50:
            print("有效点数不足,无法进行几何检测")
            return []
        
        # 2. 使用RANSAC算法检测直线（墙面）
        walls = self._detect_walls_ransac(points)
        print(f"检测到墙面数量: {len(walls)}")
        
        # 3. 过滤和验证墙面
        valid_walls = self._validate_walls(walls, points)
        print(f"有效墙面数量: {len(valid_walls)}")
        
        # 4. 存储检测到的墙面信息
        self.detected_walls = valid_walls
        
        # 5. 根据墙面确定场地内的点，排除墙面附近的点
        field_points = self._filter_points_by_walls_with_exclusion(points, valid_walls)
        print(f"场地内点数: {len(field_points)}")
        
        return field_points
    
    def _detect_walls_ransac(self, points, max_walls=4):
        """使用RANSAC算法检测墙面直线"""
        walls = []
        remaining_points = points.copy()
        
        for wall_idx in range(max_walls):
            if len(remaining_points) < 20:
                break
            
            best_wall = None
            best_inliers = []
            max_inliers = 0
            
            # RANSAC迭代
            for iteration in range(200):  # 增加迭代次数
                # 随机选择两个点
                if len(remaining_points) < 2:
                    break
                    
                sample = random.sample(remaining_points, 2)
                p1, p2 = sample[0][:2], sample[1][:2]
                
                # 计算直线参数 ax + by + c = 0
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                
                if abs(dx) < 1 and abs(dy) < 1:
                    continue
                
                # 直线方程: (y2-y1)x - (x2-x1)y + (x2-x1)y1 - (y2-y1)x1 = 0
                a = dy
                b = -dx
                c = dx * p1[1] - dy * p1[0]
                
                # 归一化
                norm = math.sqrt(a*a + b*b)
                if norm > 0:
                    a, b, c = a/norm, b/norm, c/norm
                else:
                    continue
                
                # 找到内点
                inliers = []
                for point in remaining_points:
                    x, y = point[0], point[1]
                    dist = abs(a*x + b*y + c)
                    if dist < self.wall_distance_threshold:  # 距离阈值
                        inliers.append(point)
                
                # 更新最佳结果
                if len(inliers) > max_inliers and len(inliers) >= self.min_wall_points:
                    max_inliers = len(inliers)
                    best_wall = (a, b, c)
                    best_inliers = inliers.copy()
            
            # 如果找到有效墙面
            if best_wall and len(best_inliers) >= self.min_wall_points:
                wall_info = {
                    'line': best_wall,
                    'points': best_inliers,
                    'point_count': len(best_inliers),
                    'id': wall_idx
                }
                walls.append(wall_info)
                
                print(f"检测到墙面 {wall_idx}: {len(best_inliers)} 个点")
                
                # 从剩余点中移除已识别的墙面点
                remaining_points = [p for p in remaining_points if p not in best_inliers]
        
        return walls
    
    def _validate_walls(self, walls, all_points):
        """验证检测到的墙面"""
        valid_walls = []
        
        for wall in walls:
            a, b, c = wall['line']
            points = wall['points']
            
            if len(points) < self.min_wall_points:
                continue
            
            # 计算墙面的方向角
            wall_angle = math.degrees(math.atan2(-a, -b)) % 180
            
            # 检查是否接近水平或垂直（期望的墙面方向）
            # 但对于平行四边形，可能需要更宽松的角度判断
            angle_diff_horizontal = min(abs(wall_angle), abs(wall_angle - 180))
            angle_diff_vertical = abs(wall_angle - 90)
            angle_diff_diagonal1 = min(abs(wall_angle - 45), abs(wall_angle - 135))
            angle_diff_diagonal2 = min(abs(wall_angle - 225), abs(wall_angle - 315))
            
            # 接受水平、垂直或斜向的墙面（适应平行四边形）
            if (angle_diff_horizontal <= self.angle_tolerance or 
                angle_diff_vertical <= self.angle_tolerance or
                angle_diff_diagonal1 <= self.angle_tolerance or
                angle_diff_diagonal2 <= self.angle_tolerance):
                
                wall['angle'] = wall_angle
                valid_walls.append(wall)
                print(f"验证墙面 {wall['id']}: 角度={wall_angle:.1f}°")
        
        return valid_walls
    
    def _filter_points_by_walls_with_exclusion(self, points, walls):
        """根据检测到的墙面过滤场地内的点，排除墙面拟合线两侧指定距离内的点"""
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        excluded_points = []  # 新增：被排除的点
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            is_excluded_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面或在排除区域内
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
                # 检查是否在墙面拟合线两侧的排除区域内
                elif distance_to_wall < self.wall_exclusion_distance:
                    is_excluded_point = True
                    excluded_points.append(point)
                    print(f"排除墙面附近的点: 距离={distance_to_wall:.0f}mm")
                    break
            
            # 只有既不是墙面点也不在排除区域的点才加入场地点
            if not is_wall_point and not is_excluded_point and min_wall_distance > self.wall_exclusion_distance:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 排除点={len(excluded_points)}, 场地点={len(field_points)}")
        return field_points
    
    def _filter_points_by_walls(self, points, walls):
        """根据检测到的墙面过滤场地内的点（原有方法保持不变作为备用）"""
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
            
            if not is_wall_point and min_wall_distance > self.wall_distance_threshold * 2:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 场地点={len(field_points)}")
        return field_points


class EnhancedLidarProcessor:
    """增强的雷达数据处理器，提高数据密度和准确性"""
    
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        # 增加数据缓存用于插值
        self._point_buffer = {}  # 按角度存储多个点
        self._complete_scans = []  # 存储最近的完整扫描
        self.interpolation_density = 2  # 插值密度倍数

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[0:47]
                        del buffer[0:47]
                    
                        data = frame_data[2:]
                        frame = self._parse_frame(data)

                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_enhanced_scan_dict()
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        del buffer[0]
                    
                if len(buffer) > 1024:
                    del buffer[0:512]
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                buffer.clear()
                time.sleep(0.1)

    def _generate_enhanced_scan_dict(self):
        """增强的扫描字典生成，提高数据密度和准确性"""
        if not self._raw_points:
            return

        # 按角度分组存储原始点，提高角度精度到0.5度
        angle_groups = {}
        for angle, distance, intensity in self._raw_points:
            # 提高角度精度到0.5度
            rounded_angle = round(angle * 2) / 2
            if rounded_angle not in angle_groups:
                angle_groups[rounded_angle] = []
            angle_groups[rounded_angle].append((distance, intensity))

        # 生成高密度插值数据
        processed_points = {}
        angles = sorted(angle_groups.keys())
        
        # 为每个0.5度生成数据
        for i in range(720):  # 360度 * 2 = 720个0.5度步长
            target_angle = i * 0.5
            
            if target_angle in angle_groups:
                # 有实际数据
                distances = [d for d, i in angle_groups[target_angle]]
                if distances:
                    distances.sort()
                    median_dist = distances[len(distances)//2]
                    
                    # 如果有多个点，取接近中位数的点的平均值
                    if len(distances) > 1:
                        # 选择距离中位数±20%范围内的点
                        threshold = median_dist * 0.2
                        valid_distances = [d for d in distances 
                                         if abs(d - median_dist) <= threshold]
                        if valid_distances:
                            final_distance = sum(valid_distances) / len(valid_distances)
                        else:
                            final_distance = median_dist
                    else:
                        final_distance = median_dist
                    
                    processed_points[target_angle] = (final_distance, 50)
            else:
                # 插值
                interpolated_value = self._advanced_interpolate(target_angle, angle_groups)
                processed_points[target_angle] = interpolated_value

        # 转换为整数角度并应用坐标变换
        final_dict = {}
        for target_angle in range(360):
            # 从高密度数据中选择最佳值
            candidates = []
            for precise_angle in [target_angle - 0.5, target_angle, target_angle + 0.5]:
                if precise_angle in processed_points:
                    candidates.append(processed_points[precise_angle])
            
            if candidates:
                # 选择中位数距离
                distances = [c[0] for c in candidates]
                distances.sort()
                final_distance = distances[len(distances)//2]
                final_dict[target_angle] = (final_distance, 50)
            else:
                final_dict[target_angle] = (0, 0)

        # 应用坐标变换
        adjusted_dict = {}
        for lidar_angle in range(360):
            car_angle = (360 - (lidar_angle + 90) - 90 + 7) % 360
            adjusted_dict[car_angle] = final_dict[lidar_angle]

        with self._lock:
            self._scan_dict = adjusted_dict

    def _advanced_interpolate(self, target_angle, angle_groups):
        """高级插值算法"""
        angles = sorted(angle_groups.keys())
        if not angles:
            return (0, 0)

        # 寻找最近的前后角度
        prev_angle = None
        next_angle = None
        
        for angle in angles:
            if angle <= target_angle:
                prev_angle = angle
            if angle >= target_angle and next_angle is None:
                next_angle = angle
                break

        if prev_angle is None:
            prev_angle = angles[-1]
        if next_angle is None:
            next_angle = angles[0]

        if prev_angle == next_angle:
            distances = [d for d, i in angle_groups[prev_angle]]
            return (sum(distances)/len(distances), 25) if distances else (0, 0)

        # 获取距离值
        prev_distances = [d for d, i in angle_groups[prev_angle]]
        next_distances = [d for d, i in angle_groups[next_angle]]
        
        if not prev_distances or not next_distances:
            return (0, 0)

        prev_dist = sum(prev_distances) / len(prev_distances)
        next_dist = sum(next_distances) / len(next_distances)

        # 角度差计算（处理环绕）
        angle_diff = next_angle - prev_angle
        if angle_diff < 0:
            angle_diff += 360

        weight = (target_angle - prev_angle) / angle_diff if angle_diff > 0 else 0
        if weight < 0:
            weight += 1

        interpolated_distance = prev_dist + weight * (next_dist - prev_dist)
        return (interpolated_distance, 25)

    @property
    def scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def shutdown(self):
        self._running = False
        self.ser.close()

class ServoController:
    """舵机云台控制器，使用I2C PWM控制器"""
    
    def __init__(self):
        self.servo_kit = ServoKit(channels=16)
        
        self.pan_channel = 1
        self.tilt_channel = 0
        self.pan_angle = 90
        self.tilt_angle = 80
        self.angle_min = 0
        self.angle_max = 180
        
        self.set_pan_angle(self.pan_angle)
        self.set_tilt_angle(self.tilt_angle)
        print("I2C舵机控制器已初始化")
    
    def set_pan_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.pan_angle = angle
        self.servo_kit.servo[self.pan_channel].angle = angle
        return self.pan_angle
    
    def set_tilt_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.tilt_angle = angle
        self.servo_kit.servo[self.tilt_channel].angle = angle
        return self.tilt_angle
    
    def set_horizontal_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_pan_angle(absolute_angle)
        
    def set_vertical_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_tilt_angle(absolute_angle)
    
    def cleanup(self):
        self.set_pan_angle(90)
        self.set_tilt_angle(90)
        time.sleep(0.5)
        print("舵机已复位到中位位置")

class ImprovedTargetDetector:
    """改进的目标检测器，集成几何和统计检测方法"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.min_distance_threshold = 200   # 最小有效距离(mm)
        self.max_distance_threshold = 5000  # 最大有效距离(mm)
        
        # 边界检测配置 - 使用全局配置
        self.boundary_change_threshold = BOUNDARY_CONFIG['change_threshold']
        self.smoothing_window = BOUNDARY_CONFIG['smoothing_window']
        self.outlier_tolerance = BOUNDARY_CONFIG['outlier_tolerance']
        self.boundary_percentile = BOUNDARY_CONFIG['boundary_percentile']
        self.min_continuity_points = BOUNDARY_CONFIG['min_continuity_points']
        self.distance_variance_threshold = BOUNDARY_CONFIG['distance_variance_threshold']
        self.use_geometric_detection = BOUNDARY_CONFIG['use_geometric_detection']
        
        # 聚类配置 - 使用全局配置
        self.clustering_eps = CLUSTERING_CONFIG['eps']
        self.clustering_min_samples = CLUSTERING_CONFIG['min_samples']
        self.target_size_range = (CLUSTERING_CONFIG['target_size_min'], CLUSTERING_CONFIG['target_size_max'])
        self.min_cluster_points = CLUSTERING_CONFIG['min_cluster_points']
        self.density_threshold = CLUSTERING_CONFIG['density_threshold']
        self.confidence_weight_points = CLUSTERING_CONFIG['confidence_weight_points']
        self.confidence_weight_density = CLUSTERING_CONFIG['confidence_weight_density']
        self.max_clusters = CLUSTERING_CONFIG['max_clusters']
        self.outlier_filter = CLUSTERING_CONFIG['outlier_filter']
        self.outlier_threshold = CLUSTERING_CONFIG['outlier_threshold']
        
        # 创建边界检测器
        self.boundary_detector = EnhancedBoundaryDetector()
        
    def detect_field_boundary(self, scan_data):
        """改进的场地边界检测"""
        if self.use_geometric_detection:
            print("使用几何形状检测算法...")
            # 使用几何形状检测
            field_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
            
            if len(field_points) > 20:  # 如果几何检测成功
                print(f"几何检测成功，识别到 {len(field_points)} 个场地内点")
                return field_points
            else:
                print("几何检测失败，回退到统计方法")
        
        # 回退到原有的统计方法，但使用更宽松的参数
        return self._statistical_boundary_detection(scan_data)
    
    def _statistical_boundary_detection(self, scan_data):
        """改进的统计边界检测"""
        print("使用统计边界检测算法...")
        
        valid_points = []
        distances = []
        
        # 收集有效点
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if self.min_distance_threshold < distance < self.max_distance_threshold:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                valid_points.append((x, y, angle, distance))
                distances.append(distance)
        
        print(f"统计检测收集到有效点数: {len(valid_points)}")
        
        if len(valid_points) < 10:
            return valid_points
        
        # 使用更宽松的边界检测
        field_points = []
        
        # 计算全局距离统计
        distances_array = np.array(distances)
        median_distance = np.median(distances_array)
        std_distance = np.std(distances_array)
        q25 = np.percentile(distances_array, 25)
        q75 = np.percentile(distances_array, 75)
        
        print(f"距离统计: 中位数={median_distance:.0f}, 标准差={std_distance:.0f}, Q25={q25:.0f}, Q75={q75:.0f}")
        
        # 动态阈值：更接近中位数的点更可能是场地内的点
        # 使用四分位数范围来确定边界
        threshold_distance = q75 + (q75 - q25) * 0.3  # 更宽松的阈值
        
        for i, (x, y, angle, distance) in enumerate(valid_points):
            # 使用更宽松的条件
            if distance <= threshold_distance:
                field_points.append((x, y, angle, distance))
        
        print(f"统计检测识别到 {len(field_points)} 个场地内点 (阈值: {threshold_distance:.0f}mm)")
        return field_points
        
    def cluster_targets(self, field_points):
        """优化的目标聚类分析，已自动排除墙面附近的点"""
        if len(field_points) < self.min_cluster_points:
            return []
            
        # 提取坐标进行聚类
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        print(f"开始聚类分析，输入点数: {len(coordinates)}")
        
        # 异常值过滤
        if self.outlier_filter and len(coordinates) > 5:
            coordinates_before = len(coordinates)
            coordinates = self._filter_outliers(coordinates)
            print(f"异常值过滤: {coordinates_before} -> {len(coordinates)} 点")
            if len(coordinates) < self.min_cluster_points:
                return []
        
        # 使用全局配置的DBSCAN参数
        clustering = DBSCAN(
            eps=self.clustering_eps,
            min_samples=self.clustering_min_samples
        ).fit(coordinates)
        
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:  # 跳过噪声点
                continue
                
            cluster_indices = [i for i in range(len(coordinates)) if labels[i] == label]
            cluster_points = [field_points[i] for i in cluster_indices if i < len(field_points)]
            
            if len(cluster_points) < self.min_cluster_points:
                continue
            
            # 计算聚类的尺寸和特征
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range)
            
            # 计算聚类密度
            cluster_area = x_range * y_range if x_range > 0 and y_range > 0 else 1
            density = len(cluster_points) / cluster_area * 1000  # 密度归一化
            
            # 使用全局配置的尺寸筛选条件
            if (self.target_size_range[0] <= cluster_size <= self.target_size_range[1] or 
                (cluster_size < self.target_size_range[0] and density > self.density_threshold)):
                
                # 计算聚类中心
                center_x = np.mean(cluster_coords[:, 0])
                center_y = np.mean(cluster_coords[:, 1])
                
                # 计算角度和距离
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                # 使用全局配置的权重计算置信度
                points_score = min(1.0, len(cluster_points) / 10.0)
                density_score = min(1.0, density / 2.0)
                confidence = (self.confidence_weight_points * points_score + 
                             self.confidence_weight_density * density_score)
                
                clusters.append({
                    'angle': target_angle,
                    'distance': target_distance,
                    'size': cluster_size,
                    'points': cluster_points,
                    'center': (center_x, center_y),
                    'confidence': confidence,
                    'density': density
                })
                
                print(f"发现目标聚类: 尺寸={cluster_size:.0f}mm, 点数={len(cluster_points)}, 置信度={confidence:.2f}")
        
        # 限制聚类数量
        clusters.sort(key=lambda x: x['confidence'], reverse=True)
        clusters = clusters[:self.max_clusters]
        
        print(f"最终识别出 {len(clusters)} 个目标聚类")
        return clusters
    
    def _filter_outliers(self, coordinates):
        """过滤异常值点"""
        if len(coordinates) < 5:
            return coordinates
            
        # 计算距离原点的距离
        distances = np.sqrt(coordinates[:, 0]**2 + coordinates[:, 1]**2)
        
        # 使用标准差方法过滤异常值
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)
        
        # 保留在合理范围内的点
        valid_mask = np.abs(distances - mean_dist) <= self.outlier_threshold * std_dist
        
        return coordinates[valid_mask]
    
    def find_target(self, scan_data):
        """主要的目标检测函数"""
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        
        if clusters:
            # 优先选择置信度最高的目标，如果置信度相近则选择最近的
            best_target = clusters[0]
            for cluster in clusters[1:]:
                # 如果置信度差距不大(小于0.2)，选择更近的目标
                if (abs(cluster['confidence'] - best_target['confidence']) < 0.2 and 
                    cluster['distance'] < best_target['distance']):
                    best_target = cluster
            
            return best_target['angle'], best_target['distance']
        
        return None, None
    
    def update_clustering_params(self, **kwargs):
        """动态更新聚类参数"""
        for key, value in kwargs.items():
            if hasattr(self, f'clustering_{key}'):
                setattr(self, f'clustering_{key}', value)
                CLUSTERING_CONFIG[key] = value
            elif key in ['target_size_min', 'target_size_max']:
                if key == 'target_size_min':
                    self.target_size_range = (value, self.target_size_range[1])
                    CLUSTERING_CONFIG['target_size_min'] = value
                else:
                    self.target_size_range = (self.target_size_range[0], value)
                    CLUSTERING_CONFIG['target_size_max'] = value
            elif hasattr(self, key):
                setattr(self, key, value)
                CLUSTERING_CONFIG[key] = value
        
        print(f"聚类参数已更新: {kwargs}")

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 17, 'encoder_a': 22},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 12},
                'rear_right': {'in1': 25, 'in2': 16, 'encoder_a': 20}
            }
        
        # 初始化组件
        self.lidar = EnhancedLidarProcessor(port=lidar_port)
        self.mecanum_car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.target_detector = ImprovedTargetDetector()
        
        # 运动参数
        self.base_speed = base_speed
        self.rotation_speed = 40
        self.target_lost_timeout = 3.0  # 秒
        self.last_target_time = 0
        
        # 状态
        self.running = False
        self.current_action = "scanning"  # scanning, moving_to_target, attacking
        
        # 创建GUI
        self.root = tk.Tk()
        self.root.title("Lidar战斗机器人控制系统")
        self.root.geometry("1200-800")
        
        # 创建主框架
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, pad=10)
        
        # 左侧控制面板
        self.control_frame = ttk.LabelFrame(self.main_frame, text="控制面板")
        self.control_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pad=5)
        
        # 右侧显示面板
        self.display_frame = ttk.LabelFrame(self.main_frame, text="Lidar显示")
        self.display_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, pad=5)
        
        # 控制面板内容
        self.create_control_panel()
        
        # 显示面板内容
        self.create_display_panel()
        
        # 初始化图表
        self.init_chart()
        
        # 状态变量
        self.scan_data = {}
        self.field_points = []
        self.clusters = []
        self.best_target = None
        
        print("Lidar战斗机器人系统初始化完成")
    
    def create_control_panel(self):
        """创建控制面板"""
        # 启动/停止按钮
        self.start_button = ttk.Button(self.control_frame, text="启动", command=self.start)
        self.start_button.pack(pady=10)
        
        # 状态标签
        self.status_label = ttk.Label(self.control_frame, text="状态: 就绪", font=("Arial", 12, "bold"))
        self.status_label.pack(pady=5)
        
        # 目标信息
        self.target_info = ttk.Label(self.control_frame, text="目标: 无", font=("Arial", 10))
        self.target_info.pack(pady=5)
        
        # 边界检测参数
        self.boundary_frame = ttk.LabelFrame(self.control_frame, text="边界检测参数")
        self.boundary_frame.pack(fill=tk.X, pady=5)
        
        # 聚类参数
        self.clustering_frame = ttk.LabelFrame(self.control_frame, text="聚类参数")
        self.clustering_frame.pack(fill=tk.X, pady=5)
        
        # 手动控制
        self.manual_frame = ttk.LabelFrame(self.control_frame, text="手动控制")
        self.manual_frame.pack(fill=tk.X, pady=5)
        
        # 速度控制
        self.speed_frame = ttk.LabelFrame(self.control_frame, text="速度控制")
        self.speed_frame.pack(fill=tk.X, pady=5)
        
        # 舵机控制
        self.servo_frame = ttk.LabelFrame(self.control_frame, text="舵机控制")
        self.servo_frame.pack(fill=tk.X, pady=5)
        
        # 填充控制面板内容
        self.populate_control_panels()
    
    def populate_control_panels(self):
        """填充控制面板内容"""
        # 边界检测参数
        ttk.Label(self.boundary_frame, text="变化阈值(mm):").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.change_threshold_var = tk.DoubleVar(value=BOUNDARY_CONFIG['change_threshold'])
        ttk.Scale(self.boundary_frame, from_=50, to=300, variable=self.change_threshold_var, 
                 command=lambda s: self.change_threshold_var.set(round(float(s)))).grid(row=0, column=1, sticky=tk.EW, padx=5)
        
        ttk.Label(self.boundary_frame, text="平滑窗口大小:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.smoothing_window_var = tk.IntVar(value=BOUNDARY_CONFIG['smoothing_window'])
        ttk.Scale(self.boundary_frame, from_=3, to=15, variable=self.smoothing_window_var, 
                 command=lambda s: self.smoothing_window_var.set(int(s))).grid(row=1, column=1, sticky=tk.EW, padx=5)
        
        # 聚类参数
        ttk.Label(self.clustering_frame, text="聚类半径(mm):").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.eps_var = tk.DoubleVar(value=CLUSTERING_CONFIG['eps'])
        ttk.Scale(self.clustering_frame, from_=50, to=200, variable=self.eps_var, 
                 command=lambda s: self.eps_var.set(round(float(s)))).grid(row=0, column=1, sticky=tk.EW, padx=5)
        
        ttk.Label(self.clustering_frame, text="最小样本数:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.min_samples_var = tk.IntVar(value=CLUSTERING_CONFIG['min_samples'])
        ttk.Scale(self.clustering_frame, from_=2, to=10, variable=self.min_samples_var, 
                 command=lambda s: self.min_samples_var.set(int(s))).grid(row=1, column=1, sticky=tk.EW, padx=5)
        
        # 手动控制按钮
        manual_controls_frame = ttk.Frame(self.manual_frame)
        manual_controls_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(manual_controls_frame, text="前进", command=lambda: self.mecanum_car.move_forward(self.base_speed)).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="后退", command=lambda: self.mecanum_car.move_backward(self.base_speed)).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="左转", command=lambda: self.mecanum_car.rotate_left(self.rotation_speed)).grid(row=1, column=0, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="右转", command=lambda: self.mecanum_car.rotate_right(self.rotation_speed)).grid(row=1, column=2, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="左平移", command=lambda: self.mecanum_car.strafe_left(self.base_speed)).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="右平移", command=lambda: self.mecanum_car.strafe_right(self.base_speed)).grid(row=0, column=2, padx=5, pady=5)
        ttk.Button(manual_controls_frame, text="停止", command=lambda: self.mecanum_car.stop()).grid(row=2, column=1, padx=5, pady=5)
        
        # 速度控制
        ttk.Label(self.speed_frame, text="基础速度:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.speed_var = tk.IntVar(value=self.base_speed)
        ttk.Scale(self.speed_frame, from_=20, to=100, variable=self.speed_var, 
                 command=lambda s: self.set_speed(int(s))).grid(row=0, column=1, sticky=tk.EW, padx=5)
        
        # 舵机控制
        ttk.Label(self.servo_frame, text="水平角度:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        self.pan_angle_var = tk.IntVar(value=self.servo.pan_angle)
        ttk.Scale(self.servo_frame, from_=0, to=180, variable=self.pan_angle_var, 
                 command=lambda s: self.servo.set_pan_angle(int(s))).grid(row=0, column=1, sticky=tk.EW, padx=5)
        
        ttk.Label(self.servo_frame, text="垂直角度:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
        self.tilt_angle_var = tk.IntVar(value=self.servo.tilt_angle)
        ttk.Scale(self.servo_frame, from_=0, to=180, variable=self.tilt_angle_var, 
                 command=lambda s: self.servo.set_tilt_angle(int(s))).grid(row=1, column=1, sticky=tk.EW, padx=5)
    
    def create_display_panel(self):
        """创建显示面板"""
        # 创建图表
        self.fig, self.ax = plt.subplots(figsize=(8, 8))
        self.ax.set_xlim(-2500, 2500)
        self.ax.set_ylim(-2500, 2500)
        self.ax.set_aspect('equal')
        self.ax.set_title('Lidar扫描数据')
        self.ax.grid(True)
        
        # 创建Canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.display_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def init_chart(self):
        """初始化图表"""
        # 绘制机器人位置
        self.robot_marker = self.ax.plot(0, 0, 'ro', markersize=10)[0]
        
        # 绘制Lidar点
        self.lidar_points, = self.ax.plot([], [], 'bo', markersize=2)
        
        # 绘制边界点
        self.boundary_points, = self.ax.plot([], [], 'go', markersize=3)
        
        # 绘制聚类
        self.cluster_points = []
        self.cluster_centers = []
        
        # 绘制目标
        self.target_marker, = self.ax.plot([], [], 'mo', markersize=12, markerfacecolor='none', markeredgewidth=2)
        
        # 绘制墙面
        self.wall_lines = []
        
        # 绘制机器人方向
        self.direction_line, = self.ax.plot([0, 0], [0, 200], 'r-', linewidth=2)
    
    def update_chart(self):
        """更新图表显示"""
        self.ax.clear()
        self.ax.set_xlim(-2500, 2500)
        self.ax.set_ylim(-2500, 2500)
        self.ax.set_aspect('equal')
        self.ax.set_title('Lidar扫描数据')
        self.ax.grid(True)
        
        # 绘制机器人位置
        self.ax.plot(0, 0, 'ro', markersize=10)
        
        # 绘制Lidar点
        lidar_x = []
        lidar_y = []
        for angle in range(360):
            distance, intensity = self.scan_data.get(angle, (0, 0))
            if distance > 0:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                lidar_x.append(x)
                lidar_y.append(y)
        self.ax.plot(lidar_x, lidar_y, 'bo', markersize=2, label='Lidar点')
        
        # 绘制边界点
        boundary_x = [p[0] for p in self.field_points]
        boundary_y = [p[1] for p in self.field_points]
        self.ax.plot(boundary_x, boundary_y, 'go', markersize=3, label='场地内点')
        
        # 绘制聚类
        colors = ['#FF5733', '#33FF57', '#3357FF', '#FF33F7', '#F7FF33']
        for i, cluster in enumerate(self.clusters):
            color = colors[i % len(colors)]
            cluster_x = [p[0] for p in cluster['points']]
            cluster_y = [p[1] for p in cluster['points']]
            self.ax.plot(cluster_x, cluster_y, color=color, marker='o', linestyle='', markersize=4, label=f'聚类 {i+1}')
            
            # 绘制聚类中心
            cx, cy = cluster['center']
            self.ax.plot(cx, cy, color=color, marker='*', markersize=10)
            
            # 绘制聚类边界框
            x_min = min([p[0] for p in cluster['points']])
            x_max = max([p[0] for p in cluster['points']])
            y_min = min([p[1] for p in cluster['points']])
            y_max = max([p[1] for p in cluster['points']])
            
            self.ax.plot([x_min, x_max, x_max, x_min, x_min], [y_min, y_min, y_max, y_max, y_min], color=color, linestyle='--')
        
        # 绘制目标
        if self.best_target:
            tx, ty = self.best_target['center']
            self.ax.plot(tx, ty, 'mo', markersize=12, markerfacecolor='none', markeredgewidth=2, label='目标')
            
            # 绘制从机器人到目标的连线
            self.ax.plot([0, tx], [0, ty], 'm--', linewidth=1)
            
            # 显示目标信息
            target_info = f"目标: 角度={self.best_target['angle']:.1f}°, 距离={self.best_target['distance']:.0f}mm, 大小={self.best_target['size']:.0f}mm"
            self.target_info.config(text=target_info)
        
        # 绘制墙面
        for wall in self.target_detector.boundary_detector.detected_walls:
            a, b, c = wall['line']
            
            # 计算墙面直线的两个端点
            x_min, x_max = -2500, 2500
            if abs(b) > 0.1:  # 不是垂直墙
                y1 = (-a * x_min - c) / b
                y2 = (-a * x_max - c) / b
                self.ax.plot([x_min, x_max], [y1, y2], 'k-', linewidth=2, alpha=0.7)
            else:  # 垂直墙
                x = -c / a
                self.ax.plot([x, x], [-2500, 2500], 'k-', linewidth=2, alpha=0.7)
            
            # 绘制墙面排除区域
            if BOUNDARY_CONFIG['wall_exclusion_distance'] > 0:
                # 计算墙面的法线方向
                norm = math.sqrt(a*a + b*b)
                nx, ny = a/norm, b/norm
                
                # 计算排除区域的边界线
                c1 = c + BOUNDARY_CONFIG['wall_exclusion_distance']
                c2 = c - BOUNDARY_CONFIG['wall_exclusion_distance']
                
                if abs(b) > 0.1:  # 不是垂直墙
                    y1_1 = (-a * x_min - c1) / b
                    y1_2 = (-a * x_max - c1) / b
                    y2_1 = (-a * x_min - c2) / b
                    y2_2 = (-a * x_max - c2) / b
                    self.ax.plot([x_min, x_max], [y1_1, y1_2], 'k--', linewidth=1, alpha=0.3)
                    self.ax.plot([x_min, x_max], [y2_1, y2_2], 'k--', linewidth=1, alpha=0.3)
                else:  # 垂直墙
                    x1 = -c1 / a
                    x2 = -c2 / a
                    self.ax.plot([x1, x1], [-2500, 2500], 'k--', linewidth=1, alpha=0.3)
                    self.ax.plot([x2, x2], [-2500, 2500], 'k--', linewidth=1, alpha=0.3)
        
        # 绘制机器人方向
        direction_angle = math.radians(0)  # 机器人默认方向
        dir_x = 300 * math.cos(direction_angle)
        dir_y = 300 * math.sin(direction_angle)
        self.ax.plot([0, dir_x], [0, dir_y], 'r-', linewidth=2)
        
        # 添加图例
        self.ax.legend(loc='upper right')
        
        # 更新画布
        self.canvas.draw()
    
    def set_speed(self, speed):
        """设置基础速度"""
        self.base_speed = speed
        self.speed_var.set(speed)
        print(f"基础速度已设置为: {speed}")
    
    def start(self):
        """启动机器人"""
        if not self.running:
            self.running = True
            self.start_button.config(text="停止")
            self.status_label.config(text="状态: 运行中")
            
            # 启动主循环
            self.root.after(100, self.main_loop)
    
    def stop(self):
        """停止机器人"""
        if self.running:
            self.running = False
            self.start_button.config(text="启动")
            self.status_label.config(text="状态: 已停止")
            self.mecanum_car.stop()
    
    def main_loop(self):
        """主控制循环"""
        if not self.running:
            return
        
        try:
            # 更新扫描数据
            self.scan_data = self.lidar.scan_data
            
            # 检测边界和目标
            self.field_points = self.target_detector.detect_field_boundary(self.scan_data)
            self.clusters = self.target_detector.cluster_targets(self.field_points)
            
            # 选择最佳目标
            if self.clusters:
                self.best_target = max(self.clusters, key=lambda c: c['confidence'])
                self.last_target_time = time.time()
            else:
                self.best_target = None
            
            # 控制逻辑
            self.control_logic()
            
            # 更新显示
            self.update_chart()
            
            # 更新参数
            self.update_parameters()
            
            # 继续循环
            self.root.after(100, self.main_loop)
            
        except Exception as e:
            print(f"主循环异常: {str(e)}")
            self.status_label.config(text=f"状态: 错误 - {str(e)}")
            self.root.after(1000, self.main_loop)
    
    def update_parameters(self):
        """更新参数"""
        # 更新边界检测参数
        BOUNDARY_CONFIG['change_threshold'] = self.change_threshold_var.get()
        BOUNDARY_CONFIG['smoothing_window'] = self.smoothing_window_var.get()
        
        # 更新聚类参数
        self.target_detector.update_clustering_params(
            eps=self.eps_var.get(),
            min_samples=self.min_samples_var.get()
        )
    
    def control_logic(self):
        """机器人控制逻辑"""
        if self.best_target:
            target_angle = self.best_target['angle']
            target_distance = self.best_target['distance']
            confidence = self.best_target['confidence']
            
            # 根据目标角度和距离控制机器人
            if confidence > 0.5:  # 仅处理置信度足够高的目标
                # 计算角度误差
                angle_error = target_angle - 180  # 目标在前方时角度应为180度
                
                # 将角度误差限制在±180度
                if angle_error > 180:
                    angle_error -= 360
                elif angle_error < -180:
                    angle_error += 360
                
                # 计算距离误差（目标距离约为1000mm）
                distance_error = target_distance - 1000
                
                # 控制舵机跟踪目标
                servo_angle = 90 - angle_error / 2  # 将角度误差转换为舵机角度
                servo_angle = max(0, min(180, servo_angle))
                self.servo.set_pan_angle(servo_angle)
                
                # 控制机器人移动
                if abs(angle_error) > 10:  # 如果角度误差大于10度，先转向
                    if angle_error > 0:
                        self.mecanum_car.rotate_right(min(40, abs(angle_error) * 0.3))
                    else:
                        self.mecanum_car.rotate_left(min(40, abs(angle_error) * 0.3))
                    self.current_action = "rotating"
                elif abs(distance_error) > 200:  # 如果距离误差大于200mm，前进或后退
                    if distance_error > 0:
                        self.mecanum_car.move_forward(min(60, distance_error * 0.05))
                    else:
                        self.mecanum_car.move_backward(min(60, abs(distance_error) * 0.05))
                    self.current_action = "moving"
                else:  # 角度和距离都在范围内，保持位置
                    self.mecanum_car.stop()
                    self.current_action = "attacking"
                    print("准备攻击目标!")
            else:
                self.mecanum_car.stop()
                self.current_action = "scanning"
        else:
            # 如果一段时间没有检测到目标，开始搜索
            if time.time() - self.last_target_time > self.target_lost_timeout:
                self.mecanum_car.rotate_right(30)
                self.current_action = "searching"
            else:
                self.mecanum_car.stop()
                self.current_action = "waiting"
        
        # 更新状态标签
        self.status_label.config(text=f"状态: {self.current_action}")
    
    def run(self):
        """运行GUI主循环"""
        self.root.mainloop()
    
    def cleanup(self):
        """清理资源"""
        self.stop()
        self.lidar.shutdown()
        self.servo.cleanup()
        print("系统已关闭")

if __name__ == "__main__":
    # 创建并运行机器人
    bot = LidarBattleBot()
    try:
        bot.run()
    except KeyboardInterrupt:
        bot.cleanup()    