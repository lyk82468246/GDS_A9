#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import serial
import threading
import bisect
import time
import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
from mecanum_wheel_car import MecanumCar
from adafruit_servokit import ServoKit

class StableLidarProcessor:
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            # 调试输出原始数据头
            # print(f"Raw header: {data[0:4].hex()}")

            # 修正解析逻辑
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                # 确保不会越界
                if offset+2 >= len(data):
                    break
                
                # 修正距离解析方式
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low  # 手动组合高低字节
                intensity = data[offset+2]

                # 调试输出原始距离值
                # print(f"Point {i}: dist_bytes=[{dist_low}, {dist_high}] -> {distance}")

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                # 读取可用数据到缓冲区
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)  # 短暂休眠避免CPU占用过高
                    continue
                
                buffer.extend(new_data)
            
                # 使用滑动窗口查找帧头并处理
                while len(buffer) >= 47:  # 帧头(2字节) + 数据(45字节)
                    if buffer[0:2] == b'\x54\x2C':
                        # 找到有效帧头
                        frame_data = buffer[0:47]
                        del buffer[0:47]  # 移除已处理的数据
                    
                        # 处理帧数据
                        data = frame_data[2:]  # 跳过帧头
                        frame = self._parse_frame(data)

                        # 原有的处理逻辑
                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []
                            # print("--- 开始新扫描 ---")

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_scan_dict()
                                # print("--- 完成扫描 ---")
                                # 重置调试计数器
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        # 无效帧头,只移除一个字节,继续查找
                        del buffer[0]
                    
                # 缓冲区管理:如果缓冲区过大但没找到帧头,清理一部分旧数据
                if len(buffer) > 1024:
                    del buffer[0:512]  # 删除前半部分,保留后半部分继续查找
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                # 出现异常时清空缓冲区,重新开始
                buffer.clear()
                time.sleep(0.1)

    def _generate_scan_dict(self):
        if not self._raw_points:
            # print("警告: 无有效数据点")
            return

        sorted_points = sorted(self._raw_points, key=lambda x: x[0])
        angles = [p[0] for p in sorted_points]
        
        final_dict = {}
        
        for target_angle in range(360):
            idx = bisect.bisect_left(angles, target_angle)
            candidates = []
            
            # 向前后各扩展2度的范围搜索
            search_range = 2
            start_idx = max(0, idx - search_range)
            end_idx = min(len(sorted_points),idx + search_range)
            
            for p in sorted_points[start_idx:end_idx]:
                angle_diff = abs(p[0] - target_angle)
                if angle_diff > 180:
                    angle_diff = 360 - angle_diff
                if angle_diff <= search_range:
                    candidates.append(p)

            if candidates:
                # 选择最近的三个点取中位数
                distances = sorted([p[1] for p in candidates])
                median_dist = distances[len(distances)//2]
                final_dict[target_angle] = (median_dist, 50)  # 示例强度值
            else:
                final_dict[target_angle] = (0, 0)

        with self._lock:
            self._scan_dict = final_dict

    @property
    def scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def shutdown(self):
        self._running = False
        self.ser.close()

class ServoController:
    """舵机云台控制器，使用I2C PWM控制器"""
    
    def __init__(self):
        # 创建舵机控制套件，使用16通道PWM控制器
        self.servo_kit = ServoKit(channels=16)
        
        # 设置默认参数
        self.pan_channel = 0       # 水平舵机通道
        self.tilt_channel = 1      # 垂直舵机通道
        self.pan_angle = 90        # 水平初始角度（中位）
        self.tilt_angle = 90       # 垂直初始角度（中位）
        self.angle_min = 0         # 最小角度
        self.angle_max = 180       # 最大角度
        
        # 初始化舵机位置
        self.set_pan_angle(self.pan_angle)
        self.set_tilt_angle(self.tilt_angle)
        print("I2C舵机控制器已初始化")
    
    def set_pan_angle(self, angle):
        """设置水平舵机角度"""
        # 确保角度在有效范围内
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.pan_angle = angle
        self.servo_kit.servo[self.pan_channel].angle = angle
        return self.pan_angle
    
    def set_tilt_angle(self, angle):
        """设置垂直舵机角度"""
        # 确保角度在有效范围内
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.tilt_angle = angle
        self.servo_kit.servo[self.tilt_channel].angle = angle
        return self.tilt_angle
    
    def set_horizontal_angle(self, relative_angle):
        """设置水平角度（相对于中位的角度，兼容原接口）"""
        # 将相对角度(-75到75)转换为绝对角度(15到165)
        absolute_angle = 90 + relative_angle
        return self.set_pan_angle(absolute_angle)
        
    def set_vertical_angle(self, relative_angle):
        """设置垂直角度（相对于中位的角度，兼容原接口）"""
        # 将相对角度(-90到90)转换为绝对角度(0到180)
        absolute_angle = 90 + relative_angle
        return self.set_tilt_angle(absolute_angle)
    
    def cleanup(self):
        """清理资源"""
        # 将舵机恢复到初始位置
        self.set_pan_angle(90)
        self.set_tilt_angle(90)
        time.sleep(0.5)  # 等待舵机移动到位
        print("舵机已复位到中位位置")

class TargetDetector:
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.target_size_range = (150, 300)  # 目标尺寸15-30cm
        
    def detect_field_boundary(self, scan_data):
        """检测场地边界，返回有效检测区域"""
        valid_points = []
        
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if distance > 0:
                # 转换为笛卡尔坐标
                x = distance * math.cos(math.radians(angle))
                y = distance * math.sin(math.radians(angle))
                valid_points.append((x, y, angle, distance))
        
        if not valid_points:
            return []
            
        # 识别距离突变点作为场地边界
        distances = [p[3] for p in valid_points]
        boundary_threshold = 500  # 距离突变阈值500mm
        
        field_points = []
        for i, (x, y, angle, distance) in enumerate(valid_points):
            # 检查是否在合理的场地范围内（小于4米且不是边界）
            if distance < self.field_size:
                # 检查前后点的距离变化
                prev_dist = distances[i-1] if i > 0 else distance
                next_dist = distances[(i+1) % len(distances)] if i < len(distances)-1 else distance
                
                # 如果不是边界突变点，则认为是场地内的目标
                if abs(distance - prev_dist) < boundary_threshold and abs(distance - next_dist) < boundary_threshold:
                    field_points.append((x, y, angle, distance))
        
        return field_points
    
    def cluster_targets(self, field_points):
        """对场地内的点进行聚类分析"""
        if len(field_points) < 5:
            return []
            
        # 提取坐标进行聚类
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        # 使用DBSCAN聚类
        clustering = DBSCAN(eps=100, min_samples=3).fit(coordinates)  # eps=100mm
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:  # 噪声点
                continue
                
            cluster_points = [field_points[i] for i in range(len(field_points)) if labels[i] == label]
            
            # 计算聚类的尺寸
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range)
            
            # 筛选符合目标尺寸的聚类
            if self.target_size_range[0] <= cluster_size <= self.target_size_range[1]:
                # 计算聚类中心
                center_x = np.mean(cluster_coords[:, 0])
                center_y = np.mean(cluster_coords[:, 1])
                
                # 计算角度和距离
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                clusters.append({
                    'angle': target_angle,
                    'distance': target_distance,
                    'size': cluster_size,
                    'points': cluster_points
                })
        
        return clusters
    
    def find_target(self, scan_data):
        """主要的目标检测函数"""
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        
        if clusters:
            # 返回最近的目标
            nearest_target = min(clusters, key=lambda x: x['distance'])
            return nearest_target['angle'], nearest_target['distance']
        
        return None, None

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 17, 'encoder_a': 22},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        # 初始化各个组件
        self.lidar = StableLidarProcessor(port=lidar_port, baudrate=230400)
        self.car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.detector = TargetDetector()
    
        # 串口通信
        self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
        
        # 控制参数
        self.base_speed = base_speed
        self.is_running = False
        self.system_active = False  # 系统是否激活状态
        self.target_angle = None
        self.target_distance = None
        
        # 线程锁
        self.data_lock = threading.Lock()
        
        # 启动监听线程
        self.listen_thread = threading.Thread(target=self._listen_for_trigger)
        self.listen_thread.daemon = True
        self.listen_thread.start()
        
    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                # 移除开头的$+和结尾的$
                content = data_str[2:-1]
                # 按+分割
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    # 检查角度范围
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False
    
    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待视觉模块触发命令...")
        
        while True:
            try:
                if self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    if self._parse_trigger_command(data):
                        if not self.system_active:
                            print(f"接收到启动命令: {data}")
                            self.system_active = True
                            self._start_system()
                        else:
                            print(f"接收到停止命令: {data}")
                            self.system_active = False
                            self._stop_system()
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)
    
    def _start_system(self):
        """启动系统"""
        print("系统启动，开始前进2.5米...")
        
        # 前进到中心位置
        self.move_to_center()
        
        # 启动战斗模式
        self.start_battle_mode()
        
    def _stop_system(self):
        """停止系统"""
        print("系统停止")
        self.is_running = False
        self.car.stop()
        # 舵机回到中位
        self.servo.set_horizontal_angle(0)
        self.servo.set_vertical_angle(0)
        
    def move_to_center(self):
        """快速前进2.5米到场地中心，基于前方障碍物距离判断"""
        print("开始前进，目标：距离前方障碍物1.5米...")

        start_time = time.time()
        target_distance = 1500  # 目标距离1.5米 = 1500mm
    
        while time.time() - start_time < 15:  # 增加超时时间到15秒
            # 检查系统状态
            if not self.system_active:
                self.car.stop()
                return
                
            scan_data = self.lidar.scan_data
            if scan_data:
                # 获取前方距离（扩大检测范围到85-95度，提高可靠性）
                front_distances = [scan_data.get(a, (10000, 0))[0] 
                                for a in range(85, 95) 
                                if scan_data.get(a, (0, 0))[0] > 0]
                
                if front_distances:
                    current_front_distance = min(front_distances)
                    print(f"当前前方距离: {current_front_distance}mm")
                    
                    # 判断是否达到目标距离
                    if current_front_distance <= target_distance:
                        self.car.stop()
                        print(f"已达到目标位置，距离前方障碍物: {current_front_distance}mm")
                        break
                    
                    # 根据距离调整速度（距离越近速度越慢）
                    if current_front_distance > 3000:  # 距离大于3米，正常速度
                        speed = 80
                    elif current_front_distance > 2000:  # 距离2-3米，减速
                        speed = 70
                    else:  # 距离小于2米，慢速接近
                        speed = 60
                    
                    # 继续前进
                    self.car.move(90, speed)  # 90度方向
                else:
                    # 没有检测到前方障碍物，可能是数据问题，降低速度继续前进
                    print("警告: 未检测到前方障碍物，降速前进")
                    self.car.move(90, 40)
            else:
                # 雷达数据不可用，短暂等待
                print("等待雷达数据...")
                time.sleep(0.1)
                continue
            
            time.sleep(0.05)
        
        # 无论如何都要停车
        self.car.stop()
    
        # 最终检查和确认
        final_scan = self.lidar.scan_data
        if final_scan:
            final_distances = [final_scan.get(a, (10000, 0))[0] 
                            for a in range(80, 100) 
                            if final_scan.get(a, (0, 0))[0] > 0]
            if final_distances:
                final_distance = min(final_distances)
                print(f"最终位置确认 - 距离前方障碍物: {final_distance}mm")
                
                if final_distance <= target_distance:
                    print("成功到达目标位置！")
                else:
                    print(f"未完全到达目标位置，当前距离: {final_distance}mm")
            else:
                print("无法确认最终位置 - 雷达数据异常")
        else:
            print("无法确认最终位置 - 雷达无数据")
        
        print("前进完成，到达中心位置")
            
    def camera_data_thread(self):
        """处理摄像头数据的线程"""
        while self.is_running and self.system_active:
            try:
                if self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    # 先检查是否是触发命令
                    if self._parse_trigger_command(data):
                        continue  # 触发命令由监听线程处理
                    
                    try:
                        angle = int(data)
                        
                        if 0 <= angle <= 359:
                            # 有效角度数据，控制垂直舵机
                            # 将0-359映射到垂直舵机角度范围(-90到+90度)
                            vertical_angle = (angle - 180) * 90 / 180  # 映射到-90到+90度
                            self.servo.set_vertical_angle(vertical_angle)
                        else:
                            # 无效数据，执行随机移动
                            self.random_movement()
                            
                    except ValueError:
                        # 非数字数据，执行随机移动
                        self.random_movement()
                        
            except Exception as e:
                print(f"摄像头数据处理异常: {e}")
                
            time.sleep(0.05)
    
    def lidar_data_thread(self):
        """处理雷达数据的线程"""
        while self.is_running and self.system_active:
            try:
                scan_data = self.lidar.scan_data
                if scan_data:
                    target_angle, target_distance = self.detector.find_target(scan_data)
                    
                    if target_angle is not None:
                        with self.data_lock:
                            self.target_angle = target_angle
                            self.target_distance = target_distance
                        
                        # 控制舵机水平方向跟踪目标
                        self.track_target_with_servo(target_angle)
                        
            except Exception as e:
                print(f"雷达数据处理异常: {e}")
                
            time.sleep(0.1)
    
    def victory_signal_thread(self):
        """发送胜利信号的线程"""
        while self.is_running and self.system_active:
            try:
                # 发送胜利信号
                victory_message = "VICTORY\n"
                self.camera_serial.write(victory_message.encode())
                print("发送胜利信号")
                
                # 生成随机时间间隔（5-10秒）
                interval = random.randint(5000, 10000) / 1000.0
                
                # 分段睡眠，以便快速响应停止命令
                sleep_count = 0
                while sleep_count < interval and self.is_running and self.system_active:
                    time.sleep(0.1)
                    sleep_count += 0.1
                
            except Exception as e:
                print(f"胜利信号发送异常: {e}")
                time.sleep(5)
    
    def track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        # 计算相对于车头的角度差
        angle_diff = target_angle - 90  # 假设车头为90度方向
        
        # 归一化到-180到180度
        while angle_diff > 180:
            angle_diff -= 360
        while angle_diff < -180:
            angle_diff += 360
        
        # I2C舵机的角度范围调整
        max_servo_angle = 75  # 舵机最大偏转角度
        
        if abs(angle_diff) <= max_servo_angle:
            # 舵机可以直接转到目标位置
            self.servo.set_horizontal_angle(angle_diff)
        else:
            # 需要小车转动来补偿
            if angle_diff > max_servo_angle:
                # 小车向左转
                car_rotation = angle_diff - max_servo_angle
                self.servo.set_horizontal_angle(max_servo_angle)
            else:
                # 小车向右转
                car_rotation = angle_diff + max_servo_angle
                self.servo.set_horizontal_angle(-max_servo_angle)
            
            # 执行小车转动
            self.car.rotate(car_rotation, 50)
            time.sleep(abs(car_rotation) / 90)  # 根据角度计算转动时间
            self.car.stop()
    
    def random_movement(self):
        """执行随机平动和转动"""
        if not self.system_active:
            return
            
        # 随机选择移动类型
        movement_type = random.choice(['translate', 'rotate'])
        
        if movement_type == 'translate':
            # 随机平动
            direction = random.randint(0, 359)
            speed = random.randint(40, 60)
            duration = random.uniform(0.5, 1.5)
            
            self.car.move(direction, speed)
            time.sleep(duration)
            self.car.stop()
            
        else:
            # 随机转动
            angle = random.randint(-90, 90)
            speed = random.randint(40, 60)
            
            self.car.rotate(angle, speed)
            time.sleep(abs(angle) / 90)
            self.car.stop()
    
    def start_battle_mode(self):
        """启动战斗模式"""
        self.is_running = True
        
        # 启动各个处理线程
        camera_thread = threading.Thread(target=self.camera_data_thread)
        lidar_thread = threading.Thread(target=self.lidar_data_thread)
        victory_thread = threading.Thread(target=self.victory_signal_thread)
        
        camera_thread.daemon = True
        lidar_thread.daemon = True
        victory_thread.daemon = True
        
        camera_thread.start()
        lidar_thread.start()
        victory_thread.start()
        
        print("战斗模式已启动！")
        
        return camera_thread, lidar_thread, victory_thread
    
    def shutdown(self):
        """关闭系统"""
        self.is_running = False
        self.system_active = False
        self.car.stop()
        self.servo.cleanup()
        self.lidar.shutdown()
        self.camera_serial.close()
        print("系统已关闭")

def main():
    # 创建机器人实例
    bot = LidarBattleBot()
    
    try:
        print("机器人系统已初始化")
        print("等待视觉模块发送触发命令（格式：$+角度1+角度2$，角度范围360-999）")
        print("发送相同格式的命令可以启动/停止系统")
        
        # 主循环保持程序运行
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
    finally:
        bot.shutdown()

if __name__ == '__main__':
    main()