#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import serial
import threading
import bisect
import time
import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
from mecanum_wheel_car import MecanumCar
from adafruit_servokit import ServoKit
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

class StableLidarProcessor:
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        # 增加数据缓存用于插值
        self._point_buffer = {}  # 按角度存储多个点
        self._complete_scans = []  # 存储最近的完整扫描

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[0:47]
                        del buffer[0:47]
                    
                        data = frame_data[2:]
                        frame = self._parse_frame(data)

                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_enhanced_scan_dict()
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        del buffer[0]
                    
                if len(buffer) > 1024:
                    del buffer[0:512]
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                buffer.clear()
                time.sleep(0.1)

    def _generate_enhanced_scan_dict(self):
        """增强的扫描字典生成，提高数据密度和准确性"""
        if not self._raw_points:
            return

        # 按角度分组存储原始点
        angle_groups = {}
        for angle, distance, intensity in self._raw_points:
            rounded_angle = int(round(angle))
            if rounded_angle not in angle_groups:
                angle_groups[rounded_angle] = []
            angle_groups[rounded_angle].append((distance, intensity))

        # 对每个角度的多个测量值进行处理
        processed_points = {}
        for angle in range(360):
            if angle in angle_groups:
                distances = [d for d, i in angle_groups[angle]]
                if distances:
                    # 使用中位数滤波减少噪声
                    distances.sort()
                    median_dist = distances[len(distances)//2]
                    
                    # 如果有多个点，取接近中位数的点的平均值
                    if len(distances) > 1:
                        # 选择距离中位数±20%范围内的点
                        threshold = median_dist * 0.2
                        valid_distances = [d for d in distances 
                                         if abs(d - median_dist) <= threshold]
                        if valid_distances:
                            final_distance = sum(valid_distances) / len(valid_distances)
                        else:
                            final_distance = median_dist
                    else:
                        final_distance = median_dist
                    
                    processed_points[angle] = (final_distance, 50)

        # 插值填充缺失角度
        final_dict = {}
        for target_angle in range(360):
            if target_angle in processed_points:
                final_dict[target_angle] = processed_points[target_angle]
            else:
                # 寻找最近的有效点进行插值
                interpolated_value = self._interpolate_missing_angle(
                    target_angle, processed_points)
                final_dict[target_angle] = interpolated_value

        # 应用坐标变换
        adjusted_dict = {}
        for lidar_angle in range(360):
            car_angle = (360 - (lidar_angle + 90) - 90 + 7) % 360
            adjusted_dict[car_angle] = final_dict[lidar_angle]

        with self._lock:
            self._scan_dict = adjusted_dict

    def _interpolate_missing_angle(self, target_angle, processed_points):
        """为缺失角度进行插值"""
        if not processed_points:
            return (0, 0)

        # 寻找前后最近的有效点
        angles = list(processed_points.keys())
        angles.sort()

        if not angles:
            return (0, 0)

        # 处理角度环绕问题
        prev_angle = None
        next_angle = None
        
        for angle in angles:
            if angle <= target_angle:
                prev_angle = angle
            if angle >= target_angle and next_angle is None:
                next_angle = angle
                break

        # 处理边界情况
        if prev_angle is None:
            prev_angle = angles[-1]  # 使用最大角度
        if next_angle is None:
            next_angle = angles[0]   # 使用最小角度

        # 获取距离值
        prev_dist, _ = processed_points[prev_angle]
        next_dist, _ = processed_points[next_angle]

        # 简单线性插值
        if prev_angle == next_angle:
            return (prev_dist, 25)

        # 处理角度环绕
        angle_diff = next_angle - prev_angle
        if angle_diff < 0:
            angle_diff += 360

        if angle_diff == 0:
            return (prev_dist, 25)

        weight = (target_angle - prev_angle) / angle_diff
        if weight < 0:
            weight += 1

        interpolated_distance = prev_dist + weight * (next_dist - prev_dist)
        
        # 插值点的强度值设为较低值以区分
        return (interpolated_distance, 25)

    @property
    def scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def shutdown(self):
        self._running = False
        self.ser.close()

class ServoController:
    """舵机云台控制器，使用I2C PWM控制器"""
    
    def __init__(self):
        self.servo_kit = ServoKit(channels=16)
        
        self.pan_channel = 1
        self.tilt_channel = 0
        self.pan_angle = 90
        self.tilt_angle = 80
        self.angle_min = 0
        self.angle_max = 180
        
        self.set_pan_angle(self.pan_angle)
        self.set_tilt_angle(self.tilt_angle)
        print("I2C舵机控制器已初始化")
    
    def set_pan_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.pan_angle = angle
        self.servo_kit.servo[self.pan_channel].angle = angle
        return self.pan_angle
    
    def set_tilt_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.tilt_angle = angle
        self.servo_kit.servo[self.tilt_channel].angle = angle
        return self.tilt_angle
    
    def set_horizontal_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_pan_angle(absolute_angle)
        
    def set_vertical_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_tilt_angle(absolute_angle)
    
    def cleanup(self):
        self.set_pan_angle(90)
        self.set_tilt_angle(90)
        time.sleep(0.5)
        print("舵机已复位到中位位置")

class TargetDetector:
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.target_size_range = (50, 400)  # 放宽目标尺寸范围，支持更小物品
        self.boundary_change_threshold = 50  # 边界变化阈值(mm)
        self.min_distance_threshold = 200   # 最小有效距离(mm)
        self.max_distance_threshold = 5000  # 最大有效距离(mm)
        
        # 新增属性,用于记录场地边界
        self.field_boundary = None
        self.boundary_distances = {}  # 存储各角度的边界距离
        
    def detect_field_boundary(self, scan_data):
        """增强的场地边界检测，提高容错性"""
        valid_points = []
        angle_distances = {}

        # 首先收集所有有效点并按角度分组
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if (self.min_distance_threshold < distance < self.max_distance_threshold):
                if angle not in angle_distances:
                    angle_distances[angle] = []
                angle_distances[angle].append(distance)

        # 对每个角度的多个测量值进行处理
        processed_distances = {}
        for angle in range(360):
            if angle in angle_distances:
                distances = angle_distances[angle]
                # 使用中位数作为该角度的代表距离
                distances.sort()
                median_distance = distances[len(distances)//2]
                processed_distances[angle] = median_distance

        # 使用滑动窗口平滑处理，增强边界识别
        smoothed_distances = self._smooth_boundary_with_threshold(processed_distances)
        
        # 计算边界距离（使用更宽松的阈值）
        boundary_distances = self._calculate_adaptive_boundary(smoothed_distances)
        self.boundary_distances = boundary_distances

        # 筛选场地内的点
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if distance > 0:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                
                # 检查是否在边界内（使用更宽松的判断）
                boundary_dist = boundary_distances.get(angle, distance + 100)
                if distance <= boundary_dist + self.boundary_change_threshold:
                    valid_points.append((x, y, angle, distance))

        # 根据场地内点计算边界模型
        self._calculate_field_boundary(valid_points)

        return valid_points

    def _smooth_boundary_with_threshold(self, distances):
        """使用阈值的滑动窗口平滑，减少小幅突变的影响"""
        if not distances:
            return {}
        
        smoothed = {}
        window_size = 15  # 增大窗口尺寸提高稳定性
        
        # 填充缺失角度（线性插值）
        filled_distances = self._fill_missing_angles(distances)
        
        for angle in range(360):
            if angle in filled_distances:
                # 收集窗口内的距离值
                window_distances = []
                for offset in range(-window_size//2, window_size//2 + 1):
                    check_angle = (angle + offset) % 360
                    if check_angle in filled_distances:
                        window_distances.append(filled_distances[check_angle])
                
                if window_distances:
                    # 使用带阈值的中位数滤波
                    window_distances.sort()
                    median_dist = window_distances[len(window_distances)//2]
                    
                    # 过滤掉与中位数差异过大的值
                    filtered_distances = [d for d in window_distances 
                                        if abs(d - median_dist) <= self.boundary_change_threshold]
                    
                    if filtered_distances:
                        smoothed[angle] = sum(filtered_distances) / len(filtered_distances)
                    else:
                        smoothed[angle] = median_dist
                else:
                    smoothed[angle] = filled_distances.get(angle, 3000)
        
        return smoothed

    def _fill_missing_angles(self, distances):
        """填充缺失角度的距离值"""
        if not distances:
            return {}
        
        filled = distances.copy()
        angles = sorted(distances.keys())
        
        # 线性插值填充缺失角度
        for angle in range(360):
            if angle not in filled:
                # 找到前后最近的有效角度
                prev_angle = None
                next_angle = None
                
                for a in angles:
                    if a <= angle:
                        prev_angle = a
                    if a >= angle and next_angle is None:
                        next_angle = a
                        break
                
                # 处理边界情况
                if prev_angle is None:
                    prev_angle = angles[-1]
                if next_angle is None:
                    next_angle = angles[0]
                
                # 线性插值
                if prev_angle != next_angle:
                    prev_dist = distances[prev_angle]
                    next_dist = distances[next_angle]
                    
                    # 处理角度环绕
                    angle_diff = next_angle - prev_angle
                    if angle_diff < 0:
                        angle_diff += 360
                    
                    if angle_diff > 0:
                        weight = ((angle - prev_angle) % 360) / angle_diff
                        filled[angle] = prev_dist + weight * (next_dist - prev_dist)
                    else:
                        filled[angle] = prev_dist
                else:
                    filled[angle] = distances[prev_angle]
        
        return filled

    def _calculate_adaptive_boundary(self, smoothed_distances):
        """自适应计算边界距离"""
        if not smoothed_distances:
            return {}
        
        boundary_distances = {}
        
        for angle in range(360):
            if angle in smoothed_distances:
                current_dist = smoothed_distances[angle]
                
                # 收集邻近角度的距离
                neighbor_distances = []
                for offset in range(-5, 6):  # ±5度范围
                    neighbor_angle = (angle + offset) % 360
                    if neighbor_angle in smoothed_distances:
                        neighbor_distances.append(smoothed_distances[neighbor_angle])
                
                if neighbor_distances:
                    # 使用较小的距离作为边界（更保守的策略）
                    neighbor_distances.sort()
                    boundary_dist = neighbor_distances[len(neighbor_distances)//3]  # 使用33%分位数
                    boundary_distances[angle] = boundary_dist
                else:
                    boundary_distances[angle] = current_dist
            else:
                boundary_distances[angle] = 3000  # 默认值
        
        return boundary_distances

    def cluster_targets(self, field_points):
        """增强的目标聚类分析"""
        if len(field_points) < 3:  # 降低最小点数要求
            return []
            
        # 提取坐标进行聚类
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        # 使用更小的eps值和更低的min_samples来检测更小的物品
        clustering = DBSCAN(eps=80, min_samples=2).fit(coordinates)  # 降低参数
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:  # 噪声点
                continue
                
            cluster_points = [field_points[i] for i in range(len(field_points)) if labels[i] == label]
            
            if len(cluster_points) < 2:  # 降低最小聚类点数
                continue
            
            # 计算聚类的特征
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            center_x = np.mean(cluster_coords[:, 0])
            center_y = np.mean(cluster_coords[:, 1])
            
            # 计算聚类尺寸（使用更精确的方法）
            distances_from_center = [math.sqrt((x-center_x)**2 + (y-center_y)**2) 
                                   for x, y in cluster_coords]
            cluster_radius = np.mean(distances_from_center) * 2  # 估计直径
            
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range, cluster_radius)
            
            # 计算聚类密度（点数/面积）
            cluster_area = x_range * y_range if x_range > 0 and y_range > 0 else 1
            density = len(cluster_points) / max(cluster_area, 1)
            
            # 更宽松的目标筛选条件
            is_valid_size = self.target_size_range[0] <= cluster_size <= self.target_size_range[1]
            is_dense_enough = density > 0.0001 or len(cluster_points) >= 3
            
            if is_valid_size and is_dense_enough:
                # 计算角度和距离
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                # 计算置信度（基于点数、密度和尺寸）
                point_score = min(len(cluster_points) / 10.0, 1.0)
                density_score = min(density * 10000, 1.0)
                size_score = 1.0 - abs(cluster_size - 150) / 300.0  # 150mm为理想尺寸
                confidence = (point_score + density_score + size_score) / 3.0
                
                # 检查是否在场地内
                if self.is_point_in_field(center_x, center_y):
                    clusters.append({
                        'angle': target_angle,
                        'distance': target_distance,
                        'size': cluster_size,
                        'points': cluster_points,
                        'center': (center_x, center_y),
                        'confidence': confidence,
                        'point_count': len(cluster_points),
                        'density': density
                    })
        
        # 按置信度排序
        clusters.sort(key=lambda x: x['confidence'], reverse=True)
        return clusters

    def find_target(self, scan_data):
        """主要的目标检测函数"""
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        
        if clusters:
            # 返回置信度最高的目标
            best_target = clusters[0]
            return best_target['angle'], best_target['distance']
        
        return None, None

    def _calculate_field_boundary(self, field_points):
        """根据场地内点计算边界模型"""
        if not field_points:
            self.field_boundary = None
            return

        # 提取坐标
        x_coords = [p[0] for p in field_points]
        y_coords = [p[1] for p in field_points]

        # 计算边界值（添加一些余量）
        margin = 100  # 100mm余量
        min_x, max_x = min(x_coords) - margin, max(x_coords) + margin
        min_y, max_y = min(y_coords) - margin, max(y_coords) + margin

        # 构建边界模型
        self.field_boundary = {
            'min_x': min_x,
            'max_x': max_x,
            'min_y': min_y,
            'max_y': max_y
        }

    def is_point_in_field(self, x, y):
        """检查点是否在场地内"""
        if self.field_boundary:
            if (self.field_boundary['min_x'] <= x <= self.field_boundary['max_x'] and
                self.field_boundary['min_y'] <= y <= self.field_boundary['max_y']):
                return True
        return False

    def get_debug_info(self):
        """获取调试信息"""
        return {
            'field_boundary': self.field_boundary,
            'boundary_distances_count': len(self.boundary_distances) if self.boundary_distances else 0
        }

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 17, 'encoder_a': 22},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        # 初始化各个组件
        self.lidar = StableLidarProcessor(port=lidar_port, baudrate=230400)
        self.car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.detector = TargetDetector()
    
        # 串口通信
        self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
        
        # 控制参数
        self.base_speed = base_speed
        self.is_running = False
        self.system_active = False
        self.target_angle = None
        self.target_distance = None
        
        # 线程锁
        self.data_lock = threading.Lock()
        
        # GUI相关初始化
        self.root = tk.Tk()
        self.root.title("Lidar Battle Bot Monitoring")
        self.root.geometry("1200x800")
        
        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建左侧控制面板
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # 创建图形显示区域
        plot_frame = ttk.Frame(main_frame)
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 设置matplotlib图形
        plt.style.use('dark_background')
        self.fig, self.ax = plt.subplots(figsize=(8, 8), facecolor='black')
        self.ax.set_facecolor('black')
        self.ax.set_xlim(-3000, 3000)
        self.ax.set_ylim(-3000, 3000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Enhanced)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        
        # 创建canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 控制面板组件
        # 系统状态显示
        ttk.Label(control_frame, text="System Status", font=('Arial', 12, 'bold')).pack(pady=5)
        self.status_var = tk.StringVar(value="Waiting for Trigger")
        self.status_label = ttk.Label(control_frame, textvariable=self.status_var, 
                                     background='red', foreground='white', font=('Arial', 10))
        self.status_label.pack(pady=5, fill=tk.X)
        
        # 启动/停止按钮
        self.start_stop_button = ttk.Button(control_frame, text="Manual Start", 
                                           command=self._toggle_system)
        self.start_stop_button.pack(pady=10, fill=tk.X)
        
        # 目标信息显示
        ttk.Label(control_frame, text="Target Information", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        self.target_info_frame = ttk.Frame(control_frame)
        self.target_info_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.target_info_frame, text="Angle:").grid(row=0, column=0, sticky='w')
        self.angle_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.angle_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(self.target_info_frame, text="Distance:").grid(row=1, column=0, sticky='w')
        self.distance_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.distance_var).grid(row=1, column=1, sticky='w')
        
        # 舵机控制
        ttk.Label(control_frame, text="Servo Control", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        servo_frame = ttk.Frame(control_frame)
        servo_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(servo_frame, text="Pan:").grid(row=0, column=0, sticky='w')
        self.pan_var = tk.StringVar(value=f"{self.servo.pan_angle}°")
        ttk.Label(servo_frame, textvariable=self.pan_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(servo_frame, text="Tilt:").grid(row=1, column=0, sticky='w')
        self.tilt_var = tk.StringVar(value=f"{self.servo.tilt_angle}°")
        ttk.Label(servo_frame, textvariable=self.tilt_var).grid(row=1, column=1, sticky='w')
        
        # 统计信息
        ttk.Label(control_frame, text="Statistics", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        stats_frame = ttk.Frame(control_frame)
        stats_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(stats_frame, text="Scan Points:").grid(row=0, column=0, sticky='w')
        self.scan_points_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.scan_points_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Field Points:").grid(row=1, column=0, sticky='w')
        self.field_points_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.field_points_var).grid(row=1, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Clusters:").grid(row=2, column=0, sticky='w')
        self.clusters_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.clusters_var).grid(row=2, column=1, sticky='w')
        
        # 启动监听线程
        self.listen_thread = threading.Thread(target=self._listen_for_trigger)
        self.listen_thread.daemon = True
        self.listen_thread.start()
        
        # 启动GUI更新线程
        self.gui_running = True
        self.gui_thread = threading.Thread(target=self._update_gui_loop)
        self.gui_thread.daemon = True
        self.gui_thread.start()
        
    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False
    
    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待视觉模块触发命令...")
        
        while True:
            try:
                if self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    if self._parse_trigger_command(data):
                        if not self.system_active:
                            print(f"接收到启动命令: {data}")
                            self.system_active = True
                            self._start_system()
                        else:
                            print(f"接收到停止命令: {data}")
                            self.system_active = False
                            self._stop_system()
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)
    
    def _toggle_system(self):
        """手动切换系统状态"""
        if not self.system_active:
            self.system_active = True
            self._start_system()
        else:
            self.system_active = False
            self._stop_system()
    
    def _start_system(self):
        """启动系统"""
        print("系统启动，开始前进2.5米...")
        self.status_var.set("System Active - Moving to Center")
        self.status_label.configure(background='green')
        self.start_stop_button.configure(text="Stop System")
        
        # 前进到中心位置
        self.move_to_center()
        
        # 启动战斗模式
        self.start_battle_mode()
        
    def _stop_system(self):
        """停止系统"""
        print("系统停止")
        self.is_running = False
        self.car.stop()
        # 舵机回到中位
        self.servo.set_horizontal_angle(0)
        self.servo.set_vertical_angle(0)
        
        self.status_var.set("System Stopped")
        self.status_label.configure(background='red')
        self.start_stop_button.configure(text="Manual Start")
        
    def move_to_center(self):
        """快速前进2.5米到场地中心,基于前方障碍物距离判断"""
        print("开始前进,目标:距离前方障碍物1.5米...")

        start_time = time.time()
        target_distance = 1500

        while time.time() - start_time < 15:
            if not self.system_active:
                self.car.stop()
                return

            scan_data = self.lidar.scan_data
            if scan_data:
                front_distances = [scan_data.get(a, (10000, 0))[0] 
                                for a in range(85, 95) 
                                if scan_data.get(a, (0, 0))[0] > 0]
                
                if front_distances:
                    current_front_distance = min(front_distances)
                    print(f"当前前方距离: {current_front_distance}mm")

                    if current_front_distance <= target_distance:
                        self.car.stop()
                        print(f"已达到目标位置,距离前方障碍物: {current_front_distance}mm")
                        break

                    # 根据距离调整速度
                    if current_front_distance > 3000:
                        speed = 80
                    elif current_front_distance > 2000:
                        speed = 70
                    else:
                        speed = 60

                    # 检查是否在场地内
                    if self.detector.is_point_in_field(0, 0):
                        self.car.move(90, speed)
                    else:
                        print("检测到已经超出场地边界,停止前进")
                        self.car.stop()
                        break
                else:
                    print("警告: 未检测到前方障碍物,降速前进")
                    self.car.move(90, 40)
            else:
                print("等待雷达数据...")
                time.sleep(0.1)
                continue
            
            time.sleep(0.05)

        self.car.stop()

        final_scan = self.lidar.scan_data
        if final_scan:
            final_distances = [final_scan.get(a, (10000, 0))[0] 
                            for a in range(80, 100) 
                            if final_scan.get(a, (0, 0))[0] > 0]
            if final_distances:
                final_distance = min(final_distances)
                print(f"最终位置确认 - 距离前方障碍物: {final_distance}mm")
                
                if final_distance <= target_distance:
                    print("成功到达目标位置!")
                else:
                    print(f"未完全到达目标位置,当前距离: {final_distance}mm")
            else:
                print("无法确认最终位置 - 雷达数据异常")
        else:
            print("无法确认最终位置 - 雷达无数据")
        
        print("前进完成,到达中心位置")
        self.status_var.set("System Active - Battle Mode")
            
    def track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        # 统一使用与GUI显示相同的角度映射关系
        # GUI中：corrected_servo_angle = (self.servo.pan_angle - 90) % 360
        # 所以控制时：servo_angle = (target_angle + 90) % 360
        
        # 计算舵机应该转到的角度（与GUI显示逻辑一致）
        target_servo_angle = (target_angle + 90) % 360
        
        # 将360度角度系统转换为舵机的0-180度系统
        if target_servo_angle > 180:
            target_servo_angle = 360 - target_servo_angle
            # 或者选择最近的等效角度
            if target_servo_angle > 90:
                target_servo_angle = 180 - (target_servo_angle - 180)
        
        # 限制在舵机有效范围内
        target_servo_angle = max(0, min(180, target_servo_angle))
        
        # 设置舵机角度
        current_servo_angle = self.servo.pan_angle
        new_angle = self.servo.set_pan_angle(target_servo_angle)
        
        print(f"目标角度{target_angle}° -> 舵机角度{new_angle}°")
        
        # 更新GUI显示
        self.pan_var.set(f"{self.servo.pan_angle:.0f}°")
        
    def start_battle_mode(self):
        """启动战斗模式"""
        self.is_running = True
        
        # 启动各个处理线程
        camera_thread = threading.Thread(target=self.camera_data_thread)
        lidar_thread = threading.Thread(target=self.lidar_data_thread)
        victory_thread = threading.Thread(target=self.victory_signal_thread)
        
        camera_thread.daemon = True
        lidar_thread.daemon = True
        victory_thread.daemon = True
        
        camera_thread.start()
        lidar_thread.start()
        victory_thread.start()
        
        print("战斗模式已启动！")
        
        return camera_thread, lidar_thread, victory_thread
    
    def _update_gui_loop(self):
        """GUI更新循环"""
        while self.gui_running:
            try:
                self._update_gui()
                time.sleep(0.1)  # 10Hz更新频率
            except Exception as e:
                print(f"GUI更新异常: {e}")
                time.sleep(0.5)
    
    def _update_gui(self):
        """更新GUI显示"""
        # 获取雷达数据
        scan_data = self.lidar.scan_data
        if not scan_data:
            return
        
        # 清除上一次的绘图
        self.ax.clear()
        self.ax.set_xlim(-3000, 3000)
        self.ax.set_ylim(-3000, 3000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Enhanced)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        self.ax.set_facecolor('black')
        
        # 处理雷达数据
        field_points = self.detector.detect_field_boundary(scan_data)
        clusters = self.detector.cluster_targets(field_points)
        
        # 绘制所有扫描点（灰色小点）
        all_points_x = []
        all_points_y = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if distance > 0:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                all_points_x.append(x)
                all_points_y.append(y)
        
        if all_points_x:
            self.ax.scatter(all_points_x, all_points_y, s=1, c='gray', alpha=0.5, label='Scan Points')
        
        # 绘制场地内的点（绿色）
        if field_points:
            field_x = []
            field_y = []
            for p in field_points:
                angle = math.atan2(p[1], p[0])
                distance = math.sqrt(p[0]**2 + p[1]**2)
                car_angle = (math.degrees(angle) + 90) % 360

                display_angle = math.radians(car_angle - 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                field_x.append(x)
                field_y.append(y)

            if field_x:
                self.ax.scatter(field_x, field_y, s=5, c='green', alpha=0.7, label='Field Points')

        colors = ['red', 'blue', 'yellow', 'orange', 'purple', 'cyan']

        # 绘制聚类结果
        for i, cluster in enumerate(clusters):
            color = colors[i % len(colors)]

            cluster_angle = cluster['angle']
            cluster_distance = cluster['distance']
            confidence = cluster.get('confidence', 0)

            display_angle = math.radians(90 - cluster_angle)
            center_x = cluster_distance * math.cos(display_angle)
            center_y = cluster_distance * math.sin(display_angle)

            # 根据置信度调整标记大小
            marker_size = 80 + confidence * 60

            self.ax.scatter(center_x, center_y, s=marker_size, c=color, marker='o', 
                        linewidths=2, alpha=0.8, label=f'Target {i+1} (C:{confidence:.2f})')

            # 添加距离、角度和置信度标注
            distance_text = f"{cluster_distance:.0f}mm\n{cluster_angle:.0f}°\nC:{confidence:.2f}"
            self.ax.annotate(distance_text, (center_x, center_y), 
                        xytext=(5, 5), textcoords='offset points',
                        color=color, fontsize=9, weight='bold')

        # 绘制机器人位置（原点）
        self.ax.scatter(0, 0, s=100, c='white', marker='o', edgecolors='red', 
                    linewidths=2, label='Robot')

        # 绘制机器人朝向（车头方向为90度，即Y轴正方向）
        self.ax.arrow(0, 0, 0, 200, head_width=50, head_length=50, fc='white', ec='white')

        # 绘制舵机指向方向
        corrected_servo_angle = (self.servo.pan_angle - 90) % 360
        servo_display_angle = math.radians(90 - corrected_servo_angle)
        servo_x = 300 * math.cos(servo_display_angle)
        servo_y = 300 * math.sin(servo_display_angle)
        self.ax.arrow(0, 0, servo_x, servo_y, 
                    head_width=30, head_length=30, fc='yellow', ec='yellow',
                    alpha=0.7, label='Servo Direction')

        # 如果有目标，绘制目标方向线
        if self.target_angle is not None:
            target_display_angle = math.radians(90 - self.target_angle)
            target_x = 500 * math.cos(target_display_angle)
            target_y = 500 * math.sin(target_display_angle)
            self.ax.plot([0, target_x], [0, target_y], 'r--', linewidth=3, alpha=0.8, label='Target Direction')

        # 添加角度刻度线
        for angle in [0, 90, 180, 270]:
            display_angle = math.radians(90 - angle)
            end_x = 400 * math.cos(display_angle)
            end_y = 400 * math.sin(display_angle)
            self.ax.plot([0, end_x], [0, end_y], 'w--', alpha=0.3, linewidth=0.5)
            label_x = 450 * math.cos(display_angle)
            label_y = 450 * math.sin(display_angle)
            self.ax.text(label_x, label_y, f'{angle}°', color='white', 
                        ha='center', va='center', fontsize=10)

        # 添加图例
        self.ax.legend(loc='upper right', fontsize=8)

        # 重绘canvas
        self.canvas.draw()
        
        # 更新状态信息
        with self.data_lock:
            if self.target_angle is not None:
                self.angle_var.set(f"{self.target_angle:.1f}°")
                self.distance_var.set(f"{self.target_distance:.0f}mm")
            else:
                self.angle_var.set("N/A")
                self.distance_var.set("N/A")
        
        # 更新舵机位置
        self.pan_var.set(f"{self.servo.pan_angle:.0f}°")
        self.tilt_var.set(f"{self.servo.tilt_angle:.0f}°")
        
        # 更新统计信息
        self.scan_points_var.set(str(len(all_points_x)))
        self.field_points_var.set(str(len(field_points)))
        self.clusters_var.set(str(len(clusters)))
    
    def shutdown(self):
        """关闭系统"""
        self.is_running = False
        self.system_active = False
        self.gui_running = False
        self.car.stop()
        self.servo.cleanup()
        self.lidar.shutdown()
        self.camera_serial.close()
        print("系统已关闭")

def main():
    # 创建机器人实例
    bot = LidarBattleBot()
    
    try:
        print("机器人系统已初始化")
        print("等待视觉模块发送触发命令（格式：$+角度1+角度2$，角度范围360-999）")
        print("发送相同格式的命令可以启动/停止系统")
        print("GUI窗口已打开，可以实时监测雷达数据和聚类结果")
        
        # 启动Tkinter主循环
        bot.root.mainloop()
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
    finally:
        bot.shutdown()

if __name__ == '__main__':
    main()