#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import serial
import threading
import bisect
import time
import math
import random
import numpy as np
from sklearn.cluster import DBSCAN
from mecanum_wheel_car import MecanumCar
from adafruit_servokit import ServoKit
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

# 全局边界检测配置
BOUNDARY_CONFIG = {
    'change_threshold': 150,      # 边界变化阈值(mm) - 增大以容忍更多不规则
    'smoothing_window': 7,        # 平滑窗口大小 - 增大以减少噪声影响
    'outlier_tolerance': 0.3,     # 异常值容忍度 (0-1) - 高值容忍更多异常点
    'boundary_percentile': 0.4,   # 边界检测百分位数 - 使用更保守的百分位
    'min_continuity_points': 3,   # 边界连续性最小点数
    'distance_variance_threshold': 200,  # 距离方差阈值
    'use_geometric_detection': True,  # 启用几何形状检测
    'wall_distance_threshold': 80,    # 墙面点距离阈值(mm)
    'min_wall_points': 10,            # 每面墙最少点数
    'angle_tolerance': 15,            # 墙面角度容忍度
    'wall_exclusion_distance': 100,  # 墙面拟合线两侧排除距离(mm) - 新增全局变量
}

# 全局聚类识别配置
CLUSTERING_CONFIG = {
    'eps': 100,                    # DBSCAN聚类半径(mm) - 控制聚类的紧密程度
    'min_samples': 3,             # DBSCAN最小样本数 - 形成聚类所需的最少点数
    'target_size_min': 80,        # 目标最小尺寸(mm)
    'target_size_max': 250,       # 目标最大尺寸(mm) 
    'min_cluster_points': 3,      # 有效聚类最少点数
    'density_threshold': 0.7,     # 小目标密度阈值 - 允许小但密集的目标
    'confidence_weight_points': 0.4,    # 点数在置信度计算中的权重
    'confidence_weight_density': 0.6,   # 密度在置信度计算中的权重
    'max_clusters': 5,           # 最大聚类数量限制
    'outlier_filter': True,       # 启用异常值过滤
    'outlier_threshold': 2.0,     # 异常值标准差阈值
}

class EnhancedBoundaryDetector:
    """增强的边界检测器，专门处理平行四边形场地"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.expected_field_shape = 'rectangle'  # 期望的场地形状
        self.wall_detection_distance = 3500  # 墙面检测距离阈值
        self.min_wall_points = BOUNDARY_CONFIG['min_wall_points']
        self.angle_tolerance = BOUNDARY_CONFIG['angle_tolerance']
        self.wall_distance_threshold = BOUNDARY_CONFIG['wall_distance_threshold']
        self.wall_exclusion_distance = BOUNDARY_CONFIG['wall_exclusion_distance']  # 新增：墙面排除距离
        self.detected_walls = []  # 存储检测到的墙面信息
        
    def detect_walls_by_geometry(self, scan_data):
        """基于几何形状检测墙面边界"""
        print("开始几何形状检测...")
        
        # 1. 收集所有有效点
        points = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if 500 < distance < 5000:  # 有效距离范围
                # 使用与显示一致的角度转换
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                points.append((x, y, angle, distance))
        
        print(f"收集到有效点数: {len(points)}")
        
        if len(points) < 50:
            print("有效点数不足,无法进行几何检测")
            return []
        
        # 2. 使用RANSAC算法检测直线（墙面）
        walls = self._detect_walls_ransac(points)
        print(f"检测到墙面数量: {len(walls)}")
        
        # 3. 过滤和验证墙面
        valid_walls = self._validate_walls(walls, points)
        print(f"有效墙面数量: {len(valid_walls)}")
        
        # 4. 存储检测到的墙面信息
        self.detected_walls = valid_walls
        
        # 5. 根据墙面确定场地内的点，排除墙面附近的点
        field_points = self._filter_points_by_walls_with_exclusion(points, valid_walls)
        print(f"场地内点数: {len(field_points)}")
        
        return field_points
    
    def _detect_walls_ransac(self, points, max_walls=4):
        """使用RANSAC算法检测墙面直线"""
        walls = []
        remaining_points = points.copy()
        
        for wall_idx in range(max_walls):
            if len(remaining_points) < 20:
                break
            
            best_wall = None
            best_inliers = []
            max_inliers = 0
            
            # RANSAC迭代
            for iteration in range(200):  # 增加迭代次数
                # 随机选择两个点
                if len(remaining_points) < 2:
                    break
                    
                sample = random.sample(remaining_points, 2)
                p1, p2 = sample[0][:2], sample[1][:2]
                
                # 计算直线参数 ax + by + c = 0
                dx = p2[0] - p1[0]
                dy = p2[1] - p1[1]
                
                if abs(dx) < 1 and abs(dy) < 1:
                    continue
                
                # 直线方程: (y2-y1)x - (x2-x1)y + (x2-x1)y1 - (y2-y1)x1 = 0
                a = dy
                b = -dx
                c = dx * p1[1] - dy * p1[0]
                
                # 归一化
                norm = math.sqrt(a*a + b*b)
                if norm > 0:
                    a, b, c = a/norm, b/norm, c/norm
                else:
                    continue
                
                # 找到内点
                inliers = []
                for point in remaining_points:
                    x, y = point[0], point[1]
                    dist = abs(a*x + b*y + c)
                    if dist < self.wall_distance_threshold:  # 距离阈值
                        inliers.append(point)
                
                # 更新最佳结果
                if len(inliers) > max_inliers and len(inliers) >= self.min_wall_points:
                    max_inliers = len(inliers)
                    best_wall = (a, b, c)
                    best_inliers = inliers.copy()
            
            # 如果找到有效墙面
            if best_wall and len(best_inliers) >= self.min_wall_points:
                wall_info = {
                    'line': best_wall,
                    'points': best_inliers,
                    'point_count': len(best_inliers),
                    'id': wall_idx
                }
                walls.append(wall_info)
                
                print(f"检测到墙面 {wall_idx}: {len(best_inliers)} 个点")
                
                # 从剩余点中移除已识别的墙面点
                remaining_points = [p for p in remaining_points if p not in best_inliers]
        
        return walls
    
    def _validate_walls(self, walls, all_points):
        """验证检测到的墙面"""
        valid_walls = []
        
        for wall in walls:
            a, b, c = wall['line']
            points = wall['points']
            
            if len(points) < self.min_wall_points:
                continue
            
            # 计算墙面的方向角
            wall_angle = math.degrees(math.atan2(-a, -b)) % 180
            
            # 检查是否接近水平或垂直（期望的墙面方向）
            # 但对于平行四边形，可能需要更宽松的角度判断
            angle_diff_horizontal = min(abs(wall_angle), abs(wall_angle - 180))
            angle_diff_vertical = abs(wall_angle - 90)
            angle_diff_diagonal1 = min(abs(wall_angle - 45), abs(wall_angle - 135))
            angle_diff_diagonal2 = min(abs(wall_angle - 225), abs(wall_angle - 315))
            
            # 接受水平、垂直或斜向的墙面（适应平行四边形）
            if (angle_diff_horizontal <= self.angle_tolerance or 
                angle_diff_vertical <= self.angle_tolerance or
                angle_diff_diagonal1 <= self.angle_tolerance or
                angle_diff_diagonal2 <= self.angle_tolerance):
                
                wall['angle'] = wall_angle
                valid_walls.append(wall)
                print(f"验证墙面 {wall['id']}: 角度={wall_angle:.1f}°")
        
        return valid_walls
    
    def _filter_points_by_walls_with_exclusion(self, points, walls):
        """根据检测到的墙面过滤场地内的点，排除墙面拟合线两侧指定距离内的点"""
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        excluded_points = []  # 新增：被排除的点
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            is_excluded_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面或在排除区域内
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
                # 检查是否在墙面拟合线两侧的排除区域内
                elif distance_to_wall < self.wall_exclusion_distance:
                    is_excluded_point = True
                    excluded_points.append(point)
                    print(f"排除墙面附近的点: 距离={distance_to_wall:.0f}mm")
                    break
            
            # 只有既不是墙面点也不在排除区域的点才加入场地点
            if not is_wall_point and not is_excluded_point and min_wall_distance > self.wall_exclusion_distance:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 排除点={len(excluded_points)}, 场地点={len(field_points)}")
        return field_points
    
    def _filter_points_by_walls(self, points, walls):
        """根据检测到的墙面过滤场地内的点（原有方法保持不变作为备用）"""
        if not walls:
            print("没有检测到墙面,返回所有点")
            return points  # 如果没有检测到墙面,返回所有点
        
        field_points = []
        wall_points = []
        
        for point in points:
            x, y = point[0], point[1]
            is_wall_point = False
            min_wall_distance = float('inf')
            
            # 检查点是否属于某个墙面
            for wall in walls:
                a, b, c = wall['line']
                distance_to_wall = abs(a*x + b*y + c)
                min_wall_distance = min(min_wall_distance, distance_to_wall)
                
                # 如果点距离墙面很近,认为是墙面上的点
                if distance_to_wall < self.wall_distance_threshold * 1.5:  # 稍微宽松一些
                    is_wall_point = True
                    wall_points.append(point)
                    break
            
            if not is_wall_point and min_wall_distance > self.wall_distance_threshold * 2:
                field_points.append(point)
        
        print(f"分类结果: 墙面点={len(wall_points)}, 场地点={len(field_points)}")
        return field_points

class EnhancedLidarProcessor:
    """增强的雷达数据处理器，提高数据密度和准确性"""
    
    def __init__(self, port='/dev/ttyAMA2', baudrate=230400):
        self.ser = serial.Serial(port, baudrate, timeout=5)
        self._scan_dict = dict.fromkeys(range(360), (0, 0))
        self._raw_points = []
        self._last_angle = 0
        self._scan_started = False
        self._lock = threading.Lock()
        self._running = True

        # 调试计数器
        self._valid_point_count = 0 
        self._total_point_count = 0

        # 增加数据缓存用于插值
        self._point_buffer = {}  # 按角度存储多个点
        self._complete_scans = []  # 存储最近的完整扫描
        self.interpolation_density = 2  # 插值密度倍数

        self._thread = threading.Thread(target=self._process_data)
        self._thread.daemon = True
        self._thread.start()

    def _parse_frame(self, data):
        try:
            start = (int.from_bytes(data[2:4], byteorder='little')) / 100.0
            end = (int.from_bytes(data[40:42], byteorder='little')) / 100.0

            points = []
            for i in range(12):
                offset = 4 + i*3
                if offset+2 >= len(data):
                    break
                
                dist_low = data[offset]
                dist_high = data[offset+1]
                distance = (dist_high << 8) | dist_low
                intensity = data[offset+2]

                if distance > 0:
                    angle_diff = end - start if start <= end else (360 - start) + end
                    angle = (start + (angle_diff / 11) * i) % 360
                    points.append((round(angle, 2), distance, intensity))
                    self._valid_point_count += 1
                self._total_point_count += 1

            return {
                'start': start,
                'end': end,
                'points': points
            }
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return {'start':0, 'end':0, 'points':[]}

    def _process_data(self):
        """使用滑动窗口方式处理串口数据,提高帧同步可靠性"""
        buffer = bytearray()
        while self._running:
            try:
                new_data = self.ser.read(max(1, self.ser.in_waiting))
                if not new_data:
                    time.sleep(0.001)
                    continue
                
                buffer.extend(new_data)
            
                while len(buffer) >= 47:
                    if buffer[0:2] == b'\x54\x2C':
                        frame_data = buffer[0:47]
                        del buffer[0:47]
                    
                        data = frame_data[2:]
                        frame = self._parse_frame(data)

                        if frame['start'] < 5 and not self._scan_started:
                            self._scan_started = True
                            self._raw_points = []

                        if self._scan_started:
                            self._raw_points.extend(frame['points'])
                            
                            if self._last_angle > 355 and frame['start'] < 5:
                                self._scan_started = False
                                self._generate_enhanced_scan_dict()
                                self._valid_point_count = 0
                                self._total_point_count = 0

                        self._last_angle = frame['end']
                    else:
                        del buffer[0]
                    
                if len(buffer) > 1024:
                    del buffer[0:512]
                
            except Exception as e:
                print(f"处理异常: {str(e)}")
                buffer.clear()
                time.sleep(0.1)

    def _generate_enhanced_scan_dict(self):
        """增强的扫描字典生成，提高数据密度和准确性"""
        if not self._raw_points:
            return

        # 按角度分组存储原始点，提高角度精度到0.5度
        angle_groups = {}
        for angle, distance, intensity in self._raw_points:
            # 提高角度精度到0.5度
            rounded_angle = round(angle * 2) / 2
            if rounded_angle not in angle_groups:
                angle_groups[rounded_angle] = []
            angle_groups[rounded_angle].append((distance, intensity))

        # 生成高密度插值数据
        processed_points = {}
        angles = sorted(angle_groups.keys())
        
        # 为每个0.5度生成数据
        for i in range(720):  # 360度 * 2 = 720个0.5度步长
            target_angle = i * 0.5
            
            if target_angle in angle_groups:
                # 有实际数据
                distances = [d for d, i in angle_groups[target_angle]]
                if distances:
                    distances.sort()
                    median_dist = distances[len(distances)//2]
                    
                    # 如果有多个点，取接近中位数的点的平均值
                    if len(distances) > 1:
                        # 选择距离中位数±20%范围内的点
                        threshold = median_dist * 0.2
                        valid_distances = [d for d in distances 
                                         if abs(d - median_dist) <= threshold]
                        if valid_distances:
                            final_distance = sum(valid_distances) / len(valid_distances)
                        else:
                            final_distance = median_dist
                    else:
                        final_distance = median_dist
                    
                    processed_points[target_angle] = (final_distance, 50)
            else:
                # 插值
                interpolated_value = self._advanced_interpolate(target_angle, angle_groups)
                processed_points[target_angle] = interpolated_value

        # 转换为整数角度并应用坐标变换
        final_dict = {}
        for target_angle in range(360):
            # 从高密度数据中选择最佳值
            candidates = []
            for precise_angle in [target_angle - 0.5, target_angle, target_angle + 0.5]:
                if precise_angle in processed_points:
                    candidates.append(processed_points[precise_angle])
            
            if candidates:
                # 选择中位数距离
                distances = [c[0] for c in candidates]
                distances.sort()
                final_distance = distances[len(distances)//2]
                final_dict[target_angle] = (final_distance, 50)
            else:
                final_dict[target_angle] = (0, 0)

        # 应用坐标变换
        adjusted_dict = {}
        for lidar_angle in range(360):
            car_angle = (360 - (lidar_angle + 90) - 90 + 7) % 360
            adjusted_dict[car_angle] = final_dict[lidar_angle]

        with self._lock:
            self._scan_dict = adjusted_dict

    def _advanced_interpolate(self, target_angle, angle_groups):
        """高级插值算法"""
        angles = sorted(angle_groups.keys())
        if not angles:
            return (0, 0)

        # 寻找最近的前后角度
        prev_angle = None
        next_angle = None
        
        for angle in angles:
            if angle <= target_angle:
                prev_angle = angle
            if angle >= target_angle and next_angle is None:
                next_angle = angle
                break

        if prev_angle is None:
            prev_angle = angles[-1]
        if next_angle is None:
            next_angle = angles[0]

        if prev_angle == next_angle:
            distances = [d for d, i in angle_groups[prev_angle]]
            return (sum(distances)/len(distances), 25) if distances else (0, 0)

        # 获取距离值
        prev_distances = [d for d, i in angle_groups[prev_angle]]
        next_distances = [d for d, i in angle_groups[next_angle]]
        
        if not prev_distances or not next_distances:
            return (0, 0)

        prev_dist = sum(prev_distances) / len(prev_distances)
        next_dist = sum(next_distances) / len(next_distances)

        # 角度差计算（处理环绕）
        angle_diff = next_angle - prev_angle
        if angle_diff < 0:
            angle_diff += 360

        weight = (target_angle - prev_angle) / angle_diff if angle_diff > 0 else 0
        if weight < 0:
            weight += 1

        interpolated_distance = prev_dist + weight * (next_dist - prev_dist)
        return (interpolated_distance, 25)

    @property
    def scan_data(self):
        with self._lock:
            return self._scan_dict.copy()

    def shutdown(self):
        self._running = False
        self.ser.close()

class ServoController:
    """舵机云台控制器，使用I2C PWM控制器"""
    
    def __init__(self):
        self.servo_kit = ServoKit(channels=16)
        
        self.pan_channel = 1
        self.tilt_channel = 0
        self.pan_angle = 90
        self.tilt_angle = 80
        self.angle_min = 0
        self.angle_max = 180
        
        self.set_pan_angle(self.pan_angle)
        self.set_tilt_angle(self.tilt_angle)
        print("I2C舵机控制器已初始化")
    
    def set_pan_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.pan_angle = angle
        self.servo_kit.servo[self.pan_channel].angle = angle
        return self.pan_angle
    
    def set_tilt_angle(self, angle):
        angle = max(self.angle_min, min(self.angle_max, angle))
        self.tilt_angle = angle
        self.servo_kit.servo[self.tilt_channel].angle = angle
        return self.tilt_angle
    
    def set_horizontal_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_pan_angle(absolute_angle)
        
    def set_vertical_angle(self, relative_angle):
        absolute_angle = 90 + relative_angle
        return self.set_tilt_angle(absolute_angle)
    
    def cleanup(self):
        self.set_pan_angle(90)
        self.set_tilt_angle(90)
        time.sleep(0.5)
        print("舵机已复位到中位位置")

class ImprovedTargetDetector:
    """改进的目标检测器，集成几何和统计检测方法"""
    
    def __init__(self):
        self.field_size = 4000  # 4米 = 4000mm
        self.min_distance_threshold = 200   # 最小有效距离(mm)
        self.max_distance_threshold = 5000  # 最大有效距离(mm)
        
        # 边界检测配置 - 使用全局配置
        self.boundary_change_threshold = BOUNDARY_CONFIG['change_threshold']
        self.smoothing_window = BOUNDARY_CONFIG['smoothing_window']
        self.outlier_tolerance = BOUNDARY_CONFIG['outlier_tolerance']
        self.boundary_percentile = BOUNDARY_CONFIG['boundary_percentile']
        self.min_continuity_points = BOUNDARY_CONFIG['min_continuity_points']
        self.distance_variance_threshold = BOUNDARY_CONFIG['distance_variance_threshold']
        self.use_geometric_detection = BOUNDARY_CONFIG['use_geometric_detection']
        
        # 聚类配置 - 使用全局配置
        self.clustering_eps = CLUSTERING_CONFIG['eps']
        self.clustering_min_samples = CLUSTERING_CONFIG['min_samples']
        self.target_size_range = (CLUSTERING_CONFIG['target_size_min'], CLUSTERING_CONFIG['target_size_max'])
        self.min_cluster_points = CLUSTERING_CONFIG['min_cluster_points']
        self.density_threshold = CLUSTERING_CONFIG['density_threshold']
        self.confidence_weight_points = CLUSTERING_CONFIG['confidence_weight_points']
        self.confidence_weight_density = CLUSTERING_CONFIG['confidence_weight_density']
        self.max_clusters = CLUSTERING_CONFIG['max_clusters']
        self.outlier_filter = CLUSTERING_CONFIG['outlier_filter']
        self.outlier_threshold = CLUSTERING_CONFIG['outlier_threshold']
        
        # 创建边界检测器
        self.boundary_detector = EnhancedBoundaryDetector()
        
    def detect_field_boundary(self, scan_data):
        """改进的场地边界检测"""
        if self.use_geometric_detection:
            print("使用几何形状检测算法...")
            # 使用几何形状检测
            field_points = self.boundary_detector.detect_walls_by_geometry(scan_data)
            
            if len(field_points) > 20:  # 如果几何检测成功
                print(f"几何检测成功，识别到 {len(field_points)} 个场地内点")
                return field_points
            else:
                print("几何检测失败，回退到统计方法")
        
        # 回退到原有的统计方法，但使用更宽松的参数
        return self._statistical_boundary_detection(scan_data)
    
    def _statistical_boundary_detection(self, scan_data):
        """改进的统计边界检测"""
        print("使用统计边界检测算法...")
        
        valid_points = []
        distances = []
        
        # 收集有效点
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if self.min_distance_threshold < distance < self.max_distance_threshold:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                valid_points.append((x, y, angle, distance))
                distances.append(distance)
        
        print(f"统计检测收集到有效点数: {len(valid_points)}")
        
        if len(valid_points) < 10:
            return valid_points
        
        # 使用更宽松的边界检测
        field_points = []
        
        # 计算全局距离统计
        distances_array = np.array(distances)
        median_distance = np.median(distances_array)
        std_distance = np.std(distances_array)
        q25 = np.percentile(distances_array, 25)
        q75 = np.percentile(distances_array, 75)
        
        print(f"距离统计: 中位数={median_distance:.0f}, 标准差={std_distance:.0f}, Q25={q25:.0f}, Q75={q75:.0f}")
        
        # 动态阈值：更接近中位数的点更可能是场地内的点
        # 使用四分位数范围来确定边界
        threshold_distance = q75 + (q75 - q25) * 0.3  # 更宽松的阈值
        
        for i, (x, y, angle, distance) in enumerate(valid_points):
            # 使用更宽松的条件
            if distance <= threshold_distance:
                field_points.append((x, y, angle, distance))
        
        print(f"统计检测识别到 {len(field_points)} 个场地内点 (阈值: {threshold_distance:.0f}mm)")
        return field_points
        
    def cluster_targets(self, field_points):
        """优化的目标聚类分析，已自动排除墙面附近的点"""
        if len(field_points) < self.min_cluster_points:
            return []
            
        # 提取坐标进行聚类
        coordinates = np.array([(p[0], p[1]) for p in field_points])
        
        print(f"开始聚类分析，输入点数: {len(coordinates)}")
        
        # 异常值过滤
        if self.outlier_filter and len(coordinates) > 5:
            coordinates_before = len(coordinates)
            coordinates = self._filter_outliers(coordinates)
            print(f"异常值过滤: {coordinates_before} -> {len(coordinates)} 点")
            if len(coordinates) < self.min_cluster_points:
                return []
        
        # 使用全局配置的DBSCAN参数
        clustering = DBSCAN(
            eps=self.clustering_eps,
            min_samples=self.clustering_min_samples
        ).fit(coordinates)
        
        labels = clustering.labels_
        
        clusters = []
        for label in set(labels):
            if label == -1:  # 跳过噪声点
                continue
                
            cluster_indices = [i for i in range(len(coordinates)) if labels[i] == label]
            cluster_points = [field_points[i] for i in cluster_indices if i < len(field_points)]
            
            if len(cluster_points) < self.min_cluster_points:
                continue
            
            # 计算聚类的尺寸和特征
            cluster_coords = np.array([(p[0], p[1]) for p in cluster_points])
            x_range = np.max(cluster_coords[:, 0]) - np.min(cluster_coords[:, 0])
            y_range = np.max(cluster_coords[:, 1]) - np.min(cluster_coords[:, 1])
            cluster_size = max(x_range, y_range)
            
            # 计算聚类密度
            cluster_area = x_range * y_range if x_range > 0 and y_range > 0 else 1
            density = len(cluster_points) / cluster_area * 1000  # 密度归一化
            
            # 使用全局配置的尺寸筛选条件
            if (self.target_size_range[0] <= cluster_size <= self.target_size_range[1] or 
                (cluster_size < self.target_size_range[0] and density > self.density_threshold)):
                
                # 计算聚类中心
                center_x = np.mean(cluster_coords[:, 0])
                center_y = np.mean(cluster_coords[:, 1])
                
                # 计算角度和距离
                target_angle = math.degrees(math.atan2(center_y, center_x))
                if target_angle < 0:
                    target_angle += 360
                    
                target_distance = math.sqrt(center_x**2 + center_y**2)
                
                # 使用全局配置的权重计算置信度
                points_score = min(1.0, len(cluster_points) / 10.0)
                density_score = min(1.0, density / 2.0)
                confidence = (self.confidence_weight_points * points_score + 
                             self.confidence_weight_density * density_score)
                
                clusters.append({
                    'angle': target_angle,
                    'distance': target_distance,
                    'size': cluster_size,
                    'points': cluster_points,
                    'center': (center_x, center_y),
                    'confidence': confidence,
                    'density': density
                })
                
                print(f"发现目标聚类: 尺寸={cluster_size:.0f}mm, 点数={len(cluster_points)}, 置信度={confidence:.2f}")
        
        # 限制聚类数量
        clusters.sort(key=lambda x: x['confidence'], reverse=True)
        clusters = clusters[:self.max_clusters]
        
        print(f"最终识别出 {len(clusters)} 个目标聚类")
        return clusters
    
    def _filter_outliers(self, coordinates):
        """过滤异常值点"""
        if len(coordinates) < 5:
            return coordinates
            
        # 计算距离原点的距离
        distances = np.sqrt(coordinates[:, 0]**2 + coordinates[:, 1]**2)
        
        # 使用标准差方法过滤异常值
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)
        
        # 保留在合理范围内的点
        valid_mask = np.abs(distances - mean_dist) <= self.outlier_threshold * std_dist
        
        return coordinates[valid_mask]
    
    def find_target(self, scan_data):
        """主要的目标检测函数"""
        field_points = self.detect_field_boundary(scan_data)
        clusters = self.cluster_targets(field_points)
        
        if clusters:
            # 优先选择置信度最高的目标，如果置信度相近则选择最近的
            best_target = clusters[0]
            for cluster in clusters[1:]:
                # 如果置信度差距不大(小于0.2)，选择更近的目标
                if (abs(cluster['confidence'] - best_target['confidence']) < 0.2 and 
                    cluster['distance'] < best_target['distance']):
                    best_target = cluster
            
            return best_target['angle'], best_target['distance']
        
        return None, None
    
    def update_clustering_params(self, **kwargs):
        """动态更新聚类参数"""
        for key, value in kwargs.items():
            if hasattr(self, f'clustering_{key}'):
                setattr(self, f'clustering_{key}', value)
                CLUSTERING_CONFIG[key] = value
            elif key in ['target_size_min', 'target_size_max']:
                if key == 'target_size_min':
                    self.target_size_range = (value, self.target_size_range[1])
                    CLUSTERING_CONFIG['target_size_min'] = value
                else:
                    self.target_size_range = (self.target_size_range[0], value)
                    CLUSTERING_CONFIG['target_size_max'] = value
            elif hasattr(self, key):
                setattr(self, key, value)
                CLUSTERING_CONFIG[key] = value
        
        print(f"聚类参数已更新: {kwargs}")

class LidarBattleBot:
    def __init__(self, lidar_port='/dev/ttyAMA2', camera_port='/dev/ttyCH343USB0', motor_pins=None, base_speed=60):
        """
        初始化战斗机器人系统
        """
        # 电机引脚配置
        if motor_pins is None:
            motor_pins = {
                'front_left': {'in1': 27, 'in2': 22, 'encoder_a': 4},
                'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
                'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
                'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
            }
        
        # 初始化各个组件
        self.lidar = EnhancedLidarProcessor(port=lidar_port, baudrate=230400)
        self.car = MecanumCar(motor_pins)
        self.servo = ServoController()
        self.detector = ImprovedTargetDetector()
    
        # 串口通信
        self.camera_serial = serial.Serial(camera_port, 115200, timeout=0.1)
        
        # 控制参数
        self.base_speed = base_speed
        self.is_running = False
        self.system_active = False
        self.target_angle = None
        self.target_distance = None
        
        # 新增：记录右边墙的距离
        self.right_wall_distance = None
        # 新增：前进的目标距离
        self.forward_distance = 1000  # 可根据需要调整
        
        # 线程锁
        self.data_lock = threading.Lock()
        
        # GUI相关初始化
        self.root = tk.Tk()
        self.root.title("Lidar Battle Bot - Enhanced Geometric Boundary Detection with Wall Exclusion")
        self.root.geometry("1500x1000")
        
        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建左侧控制面板
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # 创建图形显示区域
        plot_frame = ttk.Frame(main_frame)
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 设置matplotlib图形
        plt.style.use('dark_background')
        self.fig, self.ax = plt.subplots(figsize=(10, 10), facecolor='black')
        self.ax.set_facecolor('black')
        self.ax.set_xlim(-4000, 4000)
        self.ax.set_ylim(-4000, 4000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Wall Exclusion)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        
        # 创建canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 设置控制面板的滚动条
        canvas_frame = tk.Canvas(control_frame)
        scrollbar = ttk.Scrollbar(control_frame, orient="vertical", command=canvas_frame.yview)
        scrollable_frame = ttk.Frame(canvas_frame)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas_frame.configure(scrollregion=canvas_frame.bbox("all"))
        )
        
        canvas_frame.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas_frame.configure(yscrollcommand=scrollbar.set)

    def start_move_to_center(self):
        # 启动时记录右边墙的距离
        scan_data = self.lidar.scan_data
        right_angle = 180  # 可根据实际情况调整
        self.right_wall_distance = scan_data.get(right_angle, (0, 0))[0]
        print(f"记录右边墙的距离: {self.right_wall_distance} mm")
        
        # 开始前进
        self.is_running = True
        threading.Thread(target=self.move_to_center).start()

    def move_to_center(self):
        current_distance = 0
        while self.is_running and current_distance < self.forward_distance:
            scan_data = self.lidar.scan_data
            right_angle = 180  # 可根据实际情况调整
            current_right_distance = scan_data.get(right_angle, (0, 0))[0]
            
            # 计算与记录距离的偏差
            distance_error = current_right_distance - self.right_wall_distance
            print(distance_error)
            
            # 根据偏差调整机器人的运动
            if distance_error > 10:  # 可根据实际情况调整阈值
                # 向右偏移，向左调整
                self.car.move_left(self.base_speed)
            elif distance_error < -10:  # 可根据实际情况调整阈值
                # 向左偏移，向右调整
                self.car.move_right(self.base_speed)
            else:
                # 保持直线前进
                self.car.move_forward(self.base_speed)
            
            # 模拟前进距离的增加，实际应用中可根据编码器数据更新
            current_distance += 10  # 可根据实际情况调整前进步长
            time.sleep(0.05)
        
        # 到达目标距离后停止
        self.car.stop()
        self.is_running = False
        print("到达目标距离，停止运动")
    
    def _create_control_widgets(self, parent):
        """创建控制组件"""
        # 系统状态显示
        ttk.Label(parent, text="System Status", font=('Arial', 12, 'bold')).pack(pady=5)
        self.status_var = tk.StringVar(value="Waiting for Trigger")
        self.status_label = ttk.Label(parent, textvariable=self.status_var, 
                                     background='red', foreground='white', font=('Arial', 10))
        self.status_label.pack(pady=5, fill=tk.X)
        
        # 启动/停止按钮
        self.start_stop_button = ttk.Button(parent, text="Manual Start", 
                                           command=self._toggle_system)
        self.start_stop_button.pack(pady=10, fill=tk.X)
        
        # 边界检测方法选择
        ttk.Label(parent, text="Boundary Detection Method", 
                 font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        self.detection_method_var = tk.BooleanVar(value=BOUNDARY_CONFIG['use_geometric_detection'])
        method_check = ttk.Checkbutton(parent, text="Use Geometric Detection", 
                                     variable=self.detection_method_var,
                                     command=self._on_method_change)
        method_check.pack(anchor='w', pady=2)
        
        # 边界检测参数调节区域
        ttk.Label(parent, text="Boundary Detection Settings", 
                 font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        boundary_frame = ttk.Frame(parent)
        boundary_frame.pack(fill=tk.X, pady=5)
        
        # 墙面距离阈值调节
        ttk.Label(boundary_frame, text="Wall Distance Threshold (mm):").pack(anchor='w')
        self.wall_threshold_var = tk.IntVar(value=BOUNDARY_CONFIG['wall_distance_threshold'])
        wall_threshold_scale = ttk.Scale(boundary_frame, from_=30, to=200, 
                                   variable=self.wall_threshold_var, orient='horizontal',
                                   command=self._on_wall_threshold_change)
        wall_threshold_scale.pack(fill=tk.X, pady=2)
        self.wall_threshold_label = ttk.Label(boundary_frame, 
                                        text=f"Current: {self.wall_threshold_var.get()}mm")
        self.wall_threshold_label.pack(anchor='w')
        
        # 新增：墙面排除距离调节
        ttk.Label(boundary_frame, text="Wall Exclusion Distance (mm):").pack(anchor='w', pady=(10, 0))
        self.wall_exclusion_var = tk.IntVar(value=BOUNDARY_CONFIG['wall_exclusion_distance'])
        wall_exclusion_scale = ttk.Scale(boundary_frame, from_=50, to=300, 
                                   variable=self.wall_exclusion_var, orient='horizontal',
                                   command=self._on_wall_exclusion_change)
        wall_exclusion_scale.pack(fill=tk.X, pady=2)
        self.wall_exclusion_label = ttk.Label(boundary_frame, 
                                        text=f"Current: {self.wall_exclusion_var.get()}mm")
        self.wall_exclusion_label.pack(anchor='w')
        
        # 最小墙面点数调节
        ttk.Label(boundary_frame, text="Min Wall Points:").pack(anchor='w', pady=(10, 0))
        self.min_points_var = tk.IntVar(value=BOUNDARY_CONFIG['min_wall_points'])
        min_points_scale = ttk.Scale(boundary_frame, from_=5, to=30, 
                                variable=self.min_points_var, orient='horizontal',
                                command=self._on_min_points_change)
        min_points_scale.pack(fill=tk.X, pady=2)
        self.min_points_label = ttk.Label(boundary_frame, 
                                     text=f"Current: {self.min_points_var.get()}")
        self.min_points_label.pack(anchor='w')
        
        # 角度容忍度调节
        ttk.Label(boundary_frame, text="Angle Tolerance (°):").pack(anchor='w', pady=(10, 0))
        self.angle_tolerance_var = tk.IntVar(value=BOUNDARY_CONFIG['angle_tolerance'])
        angle_tolerance_scale = ttk.Scale(boundary_frame, from_=5, to=45, 
                                   variable=self.angle_tolerance_var, orient='horizontal',
                                   command=self._on_angle_tolerance_change)
        angle_tolerance_scale.pack(fill=tk.X, pady=2)
        self.angle_tolerance_label = ttk.Label(boundary_frame, 
                                        text=f"Current: {self.angle_tolerance_var.get()}°")
        self.angle_tolerance_label.pack(anchor='w')
        
        # 聚类参数调节区域 - 新增
        ttk.Label(parent, text="Clustering Settings", 
                 font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        clustering_frame = ttk.Frame(parent)
        clustering_frame.pack(fill=tk.X, pady=5)
        
        # DBSCAN EPS参数
        ttk.Label(clustering_frame, text="DBSCAN EPS (mm):").pack(anchor='w')
        self.eps_var = tk.IntVar(value=CLUSTERING_CONFIG['eps'])
        eps_scale = ttk.Scale(clustering_frame, from_=20, to=150, 
                             variable=self.eps_var, orient='horizontal',
                             command=self._on_eps_change)
        eps_scale.pack(fill=tk.X, pady=2)
        self.eps_label = ttk.Label(clustering_frame, 
                                  text=f"Current: {self.eps_var.get()}mm")
        self.eps_label.pack(anchor='w')
        
        # DBSCAN 最小样本数
        ttk.Label(clustering_frame, text="Min Samples:").pack(anchor='w', pady=(10, 0))
        self.min_samples_var = tk.IntVar(value=CLUSTERING_CONFIG['min_samples'])
        min_samples_scale = ttk.Scale(clustering_frame, from_=1, to=10, 
                                     variable=self.min_samples_var, orient='horizontal',
                                     command=self._on_min_samples_change)
        min_samples_scale.pack(fill=tk.X, pady=2)
        self.min_samples_label = ttk.Label(clustering_frame, 
                                          text=f"Current: {self.min_samples_var.get()}")
        self.min_samples_label.pack(anchor='w')
        
        # 目标最小尺寸
        ttk.Label(clustering_frame, text="Target Min Size (mm):").pack(anchor='w', pady=(10, 0))
        self.target_min_var = tk.IntVar(value=CLUSTERING_CONFIG['target_size_min'])
        target_min_scale = ttk.Scale(clustering_frame, from_=20, to=200, 
                                    variable=self.target_min_var, orient='horizontal',
                                    command=self._on_target_min_change)
        target_min_scale.pack(fill=tk.X, pady=2)
        self.target_min_label = ttk.Label(clustering_frame, 
                                         text=f"Current: {self.target_min_var.get()}mm")
        self.target_min_label.pack(anchor='w')
        
        # 目标最大尺寸
        ttk.Label(clustering_frame, text="Target Max Size (mm):").pack(anchor='w', pady=(10, 0))
        self.target_max_var = tk.IntVar(value=CLUSTERING_CONFIG['target_size_max'])
        target_max_scale = ttk.Scale(clustering_frame, from_=100, to=500, 
                                    variable=self.target_max_var, orient='horizontal',
                                    command=self._on_target_max_change)
        target_max_scale.pack(fill=tk.X, pady=2)
        self.target_max_label = ttk.Label(clustering_frame, 
                                         text=f"Current: {self.target_max_var.get()}mm")
        self.target_max_label.pack(anchor='w')
        
        # 密度阈值
        ttk.Label(clustering_frame, text="Density Threshold:").pack(anchor='w', pady=(10, 0))
        self.density_var = tk.DoubleVar(value=CLUSTERING_CONFIG['density_threshold'])
        density_scale = ttk.Scale(clustering_frame, from_=0.1, to=2.0, 
                                 variable=self.density_var, orient='horizontal',
                                 command=self._on_density_change)
        density_scale.pack(fill=tk.X, pady=2)
        self.density_label = ttk.Label(clustering_frame, 
                                      text=f"Current: {self.density_var.get():.1f}")
        self.density_label.pack(anchor='w')
        
        # 异常值过滤
        self.outlier_filter_var = tk.BooleanVar(value=CLUSTERING_CONFIG['outlier_filter'])
        outlier_check = ttk.Checkbutton(clustering_frame, text="Enable Outlier Filter", 
                                       variable=self.outlier_filter_var,
                                       command=self._on_outlier_filter_change)
        outlier_check.pack(anchor='w', pady=(10, 2))
        
        # 目标信息显示
        ttk.Label(parent, text="Target Information", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        self.target_info_frame = ttk.Frame(parent)
        self.target_info_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.target_info_frame, text="Angle:").grid(row=0, column=0, sticky='w')
        self.angle_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.angle_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(self.target_info_frame, text="Distance:").grid(row=1, column=0, sticky='w')
        self.distance_var = tk.StringVar(value="N/A")
        ttk.Label(self.target_info_frame, textvariable=self.distance_var).grid(row=1, column=1, sticky='w')
        
        # 舵机控制
        ttk.Label(parent, text="Servo Control", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        servo_frame = ttk.Frame(parent)
        servo_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(servo_frame, text="Pan:").grid(row=0, column=0, sticky='w')
        self.pan_var = tk.StringVar(value=f"{self.servo.pan_angle}°")
        ttk.Label(servo_frame, textvariable=self.pan_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(servo_frame, text="Tilt:").grid(row=1, column=0, sticky='w')
        self.tilt_var = tk.StringVar(value=f"{self.servo.tilt_angle}°")
        ttk.Label(servo_frame, textvariable=self.tilt_var).grid(row=1, column=1, sticky='w')
        
        # 统计信息
        ttk.Label(parent, text="Statistics", font=('Arial', 12, 'bold')).pack(pady=(20, 5))
        
        stats_frame = ttk.Frame(parent)
        stats_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(stats_frame, text="Scan Points:").grid(row=0, column=0, sticky='w')
        self.scan_points_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.scan_points_var).grid(row=0, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Field Points:").grid(row=1, column=0, sticky='w')
        self.field_points_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.field_points_var).grid(row=1, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Clusters:").grid(row=2, column=0, sticky='w')
        self.clusters_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.clusters_var).grid(row=2, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Walls:").grid(row=3, column=0, sticky='w')
        self.walls_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.walls_var).grid(row=3, column=1, sticky='w')
        
        ttk.Label(stats_frame, text="Excluded Points:").grid(row=4, column=0, sticky='w')
        self.excluded_points_var = tk.StringVar(value="0")
        ttk.Label(stats_frame, textvariable=self.excluded_points_var).grid(row=4, column=1, sticky='w')
    
    def _on_method_change(self):
        """检测方法变化回调"""
        new_method = self.detection_method_var.get()
        self.detector.use_geometric_detection = new_method
        BOUNDARY_CONFIG['use_geometric_detection'] = new_method
        method_text = "几何检测" if new_method else "统计检测"
        print(f"边界检测方法切换为: {method_text}")
        
    def _on_wall_threshold_change(self, value):
        """墙面距离阈值变化回调"""
        new_threshold = int(float(value))
        self.detector.boundary_detector.wall_distance_threshold = new_threshold
        BOUNDARY_CONFIG['wall_distance_threshold'] = new_threshold
        self.wall_threshold_label.config(text=f"Current: {new_threshold}mm")
        
    def _on_wall_exclusion_change(self, value):
        """墙面排除距离变化回调 - 新增"""
        new_exclusion = int(float(value))
        self.detector.boundary_detector.wall_exclusion_distance = new_exclusion
        BOUNDARY_CONFIG['wall_exclusion_distance'] = new_exclusion
        self.wall_exclusion_label.config(text=f"Current: {new_exclusion}mm")
        print(f"墙面排除距离已更新为: {new_exclusion}mm")
        
    def _on_min_points_change(self, value):
        """最小墙面点数变化回调"""
        new_min_points = int(float(value))
        self.detector.boundary_detector.min_wall_points = new_min_points
        BOUNDARY_CONFIG['min_wall_points'] = new_min_points
        self.min_points_label.config(text=f"Current: {new_min_points}")
        
    def _on_angle_tolerance_change(self, value):
        """角度容忍度变化回调"""
        new_tolerance = int(float(value))
        self.detector.boundary_detector.angle_tolerance = new_tolerance
        BOUNDARY_CONFIG['angle_tolerance'] = new_tolerance
        self.angle_tolerance_label.config(text=f"Current: {new_tolerance}°")
    
    # 新增聚类参数变化回调函数
    def _on_eps_change(self, value):
        """EPS参数变化回调"""
        new_eps = int(float(value))
        self.detector.update_clustering_params(eps=new_eps)
        self.eps_label.config(text=f"Current: {new_eps}mm")
        
    def _on_min_samples_change(self, value):
        """最小样本数变化回调"""
        new_min_samples = int(float(value))
        self.detector.update_clustering_params(min_samples=new_min_samples)
        self.min_samples_label.config(text=f"Current: {new_min_samples}")
        
    def _on_target_min_change(self, value):
        """目标最小尺寸变化回调"""
        new_min_size = int(float(value))
        self.detector.update_clustering_params(target_size_min=new_min_size)
        self.target_min_label.config(text=f"Current: {new_min_size}mm")
        
    def _on_target_max_change(self, value):
        """目标最大尺寸变化回调"""
        new_max_size = int(float(value))
        self.detector.update_clustering_params(target_size_max=new_max_size)
        self.target_max_label.config(text=f"Current: {new_max_size}mm")
        
    def _on_density_change(self, value):
        """密度阈值变化回调"""
        new_density = float(value)
        self.detector.update_clustering_params(density_threshold=new_density)
        self.density_label.config(text=f"Current: {new_density:.1f}")
        
    def _on_outlier_filter_change(self):
        """异常值过滤变化回调"""
        new_filter = self.outlier_filter_var.get()
        self.detector.update_clustering_params(outlier_filter=new_filter)
        filter_text = "启用" if new_filter else "禁用"
        print(f"异常值过滤已{filter_text}")
        
    def _parse_trigger_command(self, data_str):
        """解析触发命令，格式为 $+角度1+角度2$"""
        try:
            data_str = data_str.strip()
            if data_str.startswith('$+') and data_str.endswith('$'):
                content = data_str[2:-1]
                parts = content.split('+')
                if len(parts) == 2:
                    angle1 = int(parts[0])
                    angle2 = int(parts[1])
                    if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                        return True
            return False
        except:
            return False
    
    def _listen_for_trigger(self):
        """监听触发命令的线程"""
        print("等待视觉模块触发命令...")
        
        while True:
            try:
                if self.camera_serial.in_waiting > 0:
                    data = self.camera_serial.readline().decode().strip()
                    
                    if self._parse_trigger_command(data):
                        if not self.system_active:
                            print(f"接收到启动命令: {data}")
                            self.system_active = True
                            self._start_system()
                        else:
                            print(f"接收到停止命令: {data}")
                            self.system_active = False
                            self._stop_system()
                            
            except Exception as e:
                print(f"监听触发命令异常: {e}")
                
            time.sleep(0.05)
    
    def _toggle_system(self):
        """手动切换系统状态"""
        if not self.system_active:
            self.system_active = True
            self._start_system()
        else:
            self.system_active = False
            self._stop_system()
    
    def _start_system(self):
        """启动系统"""
        print("系统启动，开始前进2.5米...")
        self.status_var.set("System Active - Moving to Center")
        self.status_label.configure(background='green')
        self.start_stop_button.configure(text="Stop System")
        
        # 前进到中心位置
        self.move_to_center()
        
        # 启动战斗模式
        self.start_battle_mode()
        
    def _stop_system(self):
        """停止系统"""
        print("系统停止")
        self.is_running = False
        self.car.stop()
        # 舵机回到中位
        self.servo.set_horizontal_angle(0)
        self.servo.set_vertical_angle(0)
        
        self.status_var.set("System Stopped")
        self.status_label.configure(background='red')
        self.start_stop_button.configure(text="Manual Start")
    
    def camera_data_thread(self):
        """处理摄像头数据的线程"""
        print("摄像头数据线程已启动")
        while self.is_running and self.system_active:
            try:
                # 这里可以添加摄像头数据处理逻辑
                time.sleep(0.1)
            except Exception as e:
                print(f"摄像头数据处理异常: {e}")
                time.sleep(0.5)
    
    def lidar_data_thread(self):
        """处理雷达数据的线程"""
        print("雷达数据线程已启动")
        while self.is_running and self.system_active:
            try:
                scan_data = self.lidar.scan_data
                if scan_data:
                    target_angle, target_distance = self.detector.find_target(scan_data)
                    
                    with self.data_lock:
                        self.target_angle = target_angle
                        self.target_distance = target_distance
                    
                    if target_angle is not None:
                        self.track_target_with_servo(target_angle)
                        print(f"检测到目标: 角度={target_angle:.1f}°, 距离={target_distance:.0f}mm")
                
                time.sleep(0.1)
            except Exception as e:
                print(f"雷达数据处理异常: {e}")
                time.sleep(0.5)
    
    def victory_signal_thread(self):
        """胜利信号线程"""
        print("胜利信号线程已启动")
        while self.is_running and self.system_active:
            try:
                # 这里可以添加胜利条件检测逻辑
                time.sleep(1.0)
            except Exception as e:
                print(f"胜利信号处理异常: {e}")
                time.sleep(1.0)
            
    def track_target_with_servo(self, target_angle):
        """使用舵机跟踪目标"""
        # 统一使用与GUI显示相同的角度映射关系
        # GUI中：corrected_servo_angle = (self.servo.pan_angle - 90) % 360
        # 所以控制时：servo_angle = (target_angle + 90) % 360
        
        # 计算舵机应该转到的角度（与GUI显示逻辑一致）
        target_servo_angle = (target_angle + 90) % 360
        
        # 将360度角度系统转换为舵机的0-180度系统
        if target_servo_angle > 180:
            target_servo_angle = 360 - target_servo_angle
            # 或者选择最近的等效角度
            if target_servo_angle > 90:
                target_servo_angle = 180 - (target_servo_angle - 180)
        
        # 限制在舵机有效范围内
        target_servo_angle = max(0, min(180, target_servo_angle))
        
        # 设置舵机角度
        current_servo_angle = self.servo.pan_angle
        new_angle = self.servo.set_pan_angle(target_servo_angle)
        
        print(f"目标角度{target_angle}° -> 舵机角度{new_angle}°")
        
        # 更新GUI显示
        self.pan_var.set(f"{self.servo.pan_angle:.0f}°")
        
    def start_battle_mode(self):
        """启动战斗模式"""
        self.is_running = True
        
        # 启动各个处理线程
        camera_thread = threading.Thread(target=self.camera_data_thread)
        lidar_thread = threading.Thread(target=self.lidar_data_thread)
        victory_thread = threading.Thread(target=self.victory_signal_thread)
        
        camera_thread.daemon = True
        lidar_thread.daemon = True
        victory_thread.daemon = True
        
        camera_thread.start()
        lidar_thread.start()
        victory_thread.start()
        
        print("战斗模式已启动！")
        
        return camera_thread, lidar_thread, victory_thread
    
    def _update_gui_loop(self):
        """GUI更新循环"""
        while self.gui_running:
            try:
                self._update_gui()
                time.sleep(0.1)  # 10Hz更新频率
            except Exception as e:
                print(f"GUI更新异常: {e}")
                time.sleep(0.05)
    
    def _update_gui(self):
        """更新GUI显示"""
        # 获取雷达数据
        scan_data = self.lidar.scan_data
        if not scan_data:
            return
        
        # 清除上一次的绘图
        self.ax.clear()
        self.ax.set_xlim(-4000, 4000)
        self.ax.set_ylim(-4000, 4000)
        self.ax.set_xlabel('X (mm)', color='white')
        self.ax.set_ylabel('Y (mm)', color='white')
        self.ax.set_title('Lidar Scan and Target Detection (Wall Exclusion)', color='white')
        self.ax.grid(True, alpha=0.3)
        self.ax.tick_params(colors='white')
        self.ax.set_facecolor('black')
        
        # 处理雷达数据
        field_points = self.detector.detect_field_boundary(scan_data)
        
        # 如果使用几何检测，获取墙面信息
        detected_walls = []
        excluded_points_count = 0
        if self.detector.use_geometric_detection:
            # 重新运行几何检测以获取墙面信息
            points = []
            for angle in range(360):
                distance, intensity = scan_data.get(angle, (0, 0))
                if 500 < distance < 5000:
                    display_angle = math.radians(angle + 90)
                    x = distance * math.cos(display_angle)
                    y = distance * math.sin(display_angle)
                    points.append((x, y, angle, distance))
            
            if len(points) >= 50:
                detected_walls = self.detector.boundary_detector._detect_walls_ransac(points)
                detected_walls = self.detector.boundary_detector._validate_walls(detected_walls, points)
                
                # 计算被排除的点数
                for point in points:
                    x, y = point[0], point[1]
                    for wall in detected_walls:
                        a, b, c = wall['line']
                        distance_to_wall = abs(a*x + b*y + c)
                        if (self.detector.boundary_detector.wall_distance_threshold * 1.5 <= 
                            distance_to_wall < self.detector.boundary_detector.wall_exclusion_distance):
                            excluded_points_count += 1
                            break
        
        clusters = self.detector.cluster_targets(field_points)
        
        # 绘制所有扫描点（灰色小点）
        all_points_x = []
        all_points_y = []
        for angle in range(360):
            distance, intensity = scan_data.get(angle, (0, 0))
            if distance > 0:
                display_angle = math.radians(angle + 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                all_points_x.append(x)
                all_points_y.append(y)
        
        if all_points_x:
            self.ax.scatter(all_points_x, all_points_y, s=1, c='gray', alpha=0.5, label='Scan Points')
        
        # 绘制检测到的墙面
        if detected_walls:
            for i, wall in enumerate(detected_walls):
                wall_points = wall['points']
                if wall_points:
                    wall_x = [p[0] for p in wall_points]
                    wall_y = [p[1] for p in wall_points]
                    
                    # 绘制墙面点
                    wall_color = ['red', 'blue', 'yellow', 'orange'][i % 4]
                    self.ax.scatter(wall_x, wall_y, s=8, c=wall_color, alpha=0.8, 
                                  label=f'Wall {i+1} ({len(wall_points)} pts)')
                    
                    # 绘制拟合直线
                    a, b, c = wall['line']
                    if abs(b) > 0.001:  # 非垂直线
                        x_line = np.linspace(-4000, 4000, 100)
                        y_line = -(a * x_line + c) / b
                        # 只绘制在视图范围内的部分
                        valid_mask = (y_line >= -4000) & (y_line <= 4000)
                        if np.any(valid_mask):
                            self.ax.plot(x_line[valid_mask], y_line[valid_mask], 
                                       color=wall_color, linestyle='--', alpha=0.7, linewidth=2)
                            
                            # 绘制排除区域（淡化显示）
                            exclusion_distance = self.detector.boundary_detector.wall_exclusion_distance
                            # 上边界
                            y_upper = y_line + exclusion_distance * abs(a) / math.sqrt(a*a + b*b)
                            # 下边界
                            y_lower = y_line - exclusion_distance * abs(a) / math.sqrt(a*a + b*b)
                            
                            upper_mask = (y_upper >= -4000) & (y_upper <= 4000)
                            lower_mask = (y_lower >= -4000) & (y_lower <= 4000)
                            
                            if np.any(upper_mask):
                                self.ax.plot(x_line[upper_mask], y_upper[upper_mask], 
                                           color=wall_color, linestyle=':', alpha=0.3, linewidth=1)
                            if np.any(lower_mask):
                                self.ax.plot(x_line[lower_mask], y_lower[lower_mask], 
                                           color=wall_color, linestyle=':', alpha=0.3, linewidth=1)
                    else:  # 垂直线
                        x_line = -c / a
                        if -4000 <= x_line <= 4000:
                            self.ax.axvline(x=x_line, color=wall_color, linestyle='--', 
                                          alpha=0.7, linewidth=2)
                            # 绘制排除区域
                            exclusion_distance = self.detector.boundary_detector.wall_exclusion_distance
                            self.ax.axvline(x=x_line + exclusion_distance, color=wall_color, 
                                          linestyle=':', alpha=0.3, linewidth=1)
                            self.ax.axvline(x=x_line - exclusion_distance, color=wall_color, 
                                          linestyle=':', alpha=0.3, linewidth=1)
        
        # 绘制场地内的点（绿色）
        if field_points:
            field_x = []
            field_y = []
            for p in field_points:
                angle = math.atan2(p[1], p[0])
                distance = math.sqrt(p[0]**2 + p[1]**2)
                car_angle = (math.degrees(angle) + 90) % 360

                display_angle = math.radians(car_angle - 90)
                x = distance * math.cos(display_angle)
                y = distance * math.sin(display_angle)
                field_x.append(x)
                field_y.append(y)

            if field_x:
                self.ax.scatter(field_x, field_y, s=5, c='green', alpha=0.7, label='Field Points')

        colors = ['red', 'blue', 'yellow', 'orange', 'purple', 'cyan']

        # 绘制聚类结果
        for i, cluster in enumerate(clusters):
            color = colors[i % len(colors)]

            cluster_angle = cluster['angle']
            cluster_distance = cluster['distance']
            confidence = cluster.get('confidence', 0)

            # 与舵机控制逻辑一致的角度转换
            display_angle = math.radians((360 - cluster_angle) % 360)
            center_x = cluster_distance * math.cos(display_angle)
            center_y = cluster_distance * math.sin(display_angle)

            # 由于GUI中Y轴正方向是向下的,需要再次转换
            center_y = -center_y

            # 根据置信度调整标记大小
            marker_size = 80 + confidence * 60

            self.ax.scatter(center_x, center_y, s=marker_size, c=color, marker='o', 
                   linewidths=2, alpha=0.8, label=f'Target {i+1} (C:{confidence:.2f})')
            # 添加距离、角度和置信度标注
            distance_text = f"{cluster_distance:.0f}mm\n{cluster_angle:.0f}°\nC:{confidence:.2f}"
            self.ax.annotate(distance_text, (center_x, center_y), 
                        xytext=(5, 5), textcoords='offset points',
                        color=color, fontsize=9, weight='bold')

        # 绘制机器人位置（原点）
        self.ax.scatter(0, 0, s=100, c='white', marker='o', edgecolors='red', 
                    linewidths=2, label='Robot')

        # 绘制机器人朝向（车头方向为90度，即Y轴正方向）
        self.ax.arrow(0, 0, 0, 200, head_width=50, head_length=50, fc='white', ec='white')

        # 绘制舵机指向方向
        corrected_servo_angle = (self.servo.pan_angle - 90) % 360
        servo_display_angle = math.radians(90 - corrected_servo_angle)
        servo_x = 300 * math.cos(servo_display_angle)
        servo_y = 300 * math.sin(servo_display_angle)
        self.ax.arrow(0, 0, servo_x, servo_y, 
                    head_width=30, head_length=30, fc='yellow', ec='yellow',
                    alpha=0.7, label='Servo Direction')

        # 如果有目标，绘制目标方向线
        if self.target_angle is not None:
            # 与舵机控制逻辑一致的角度转换
            target_display_angle = math.radians((360 - self.target_angle) % 360)
            target_x = 500 * math.cos(target_display_angle)
            target_y = 500 * math.sin(target_display_angle)
            self.ax.plot([0, target_x], [0, target_y], 'r--', linewidth=3, alpha=0.8, label='Target Direction')

        # 添加角度刻度线
        for angle in [0, 90, 180, 270]:
            display_angle = math.radians(90 - angle)
            end_x = 400 * math.cos(display_angle)
            end_y = 400 * math.sin(display_angle)
            self.ax.plot([0, end_x], [0, end_y], 'w--', alpha=0.3, linewidth=0.5)
            label_x = 450 * math.cos(display_angle)
            label_y = 450 * math.sin(display_angle)
            self.ax.text(label_x, label_y, f'{angle}°', color='white', 
                        ha='center', va='center', fontsize=10)

        # 添加图例
        self.ax.legend(loc='upper right', fontsize=8)

        # 重绘canvas
        self.canvas.draw()
        
        # 更新状态信息
        with self.data_lock:
            if self.target_angle is not None:
                self.angle_var.set(f"{self.target_angle:.1f}°")
                self.distance_var.set(f"{self.target_distance:.0f}mm")
            else:
                self.angle_var.set("N/A")
                self.distance_var.set("N/A")
        
        # 更新舵机位置
        self.pan_var.set(f"{self.servo.pan_angle:.0f}°")
        self.tilt_var.set(f"{self.servo.tilt_angle:.0f}°")
        
        # 更新统计信息
        self.scan_points_var.set(str(len(all_points_x)))
        self.field_points_var.set(str(len(field_points)))
        self.clusters_var.set(str(len(clusters)))
        self.walls_var.set(str(len(detected_walls)))
        self.excluded_points_var.set(str(excluded_points_count))
    
    def shutdown(self):
        """关闭系统"""
        self.is_running = False
        self.system_active = False
        self.gui_running = False
        self.car.stop()
        self.servo.cleanup()
        self.lidar.shutdown()
        self.camera_serial.close()
        print("系统已关闭")

def main():
    # 创建机器人实例
    bot = LidarBattleBot()
    
    try:
        print("机器人系统已初始化")
        print("边界检测已升级为几何形状检测，能够识别平行四边形场地")
        print("墙面附近点排除功能已启用，避免将墙体误识别为目标")
        print(f"当前检测方法: {'几何检测' if BOUNDARY_CONFIG['use_geometric_detection'] else '统计检测'}")
        print(f"墙面距离阈值: {BOUNDARY_CONFIG['wall_distance_threshold']}mm")
        print(f"墙面排除距离: {BOUNDARY_CONFIG['wall_exclusion_distance']}mm（可在GUI中调节）")
        print(f"最小墙面点数: {BOUNDARY_CONFIG['min_wall_points']}")
        print(f"角度容忍度: {BOUNDARY_CONFIG['angle_tolerance']}°")
        print("\n聚类检测参数:")
        print(f"DBSCAN EPS: {CLUSTERING_CONFIG['eps']}mm")
        print(f"最小样本数: {CLUSTERING_CONFIG['min_samples']}")
        print(f"目标尺寸范围: {CLUSTERING_CONFIG['target_size_min']}-{CLUSTERING_CONFIG['target_size_max']}mm")
        print(f"密度阈值: {CLUSTERING_CONFIG['density_threshold']}")
        print(f"异常值过滤: {'启用' if CLUSTERING_CONFIG['outlier_filter'] else '禁用'}")
        print("\n等待视觉模块发送触发命令（格式：$+角度1+角度2$，角度范围360-999）")
        print("GUI界面提供实时参数调节和墙面排除区域可视化")
        
        # 启动Tkinter主循环
        bot.root.mainloop()
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
    finally:
        bot.shutdown()

if __name__ == '__main__':
    main()