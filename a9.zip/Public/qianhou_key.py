import threading
import RPi.GPIO as GPIO
import time
from mecanum_wheel_car import MecanumCar
import serial

# 全局边界检测配置
BOUNDARY_CONFIG = {
    'change_threshold': 150,      # 边界变化阈值(mm) - 增大以容忍更多不规则
    'smoothing_window': 7,        # 平滑窗口大小 - 增大以减少噪声影响
    'outlier_tolerance': 0.3,     # 异常值容忍度 (0-1) - 高值容忍更多异常点
    'boundary_percentile': 0.4,   # 边界检测百分位数 - 使用更保守的百分位
    'min_continuity_points': 3,   # 边界连续性最小点数
    'distance_variance_threshold': 200,  # 距离方差阈值
    'use_geometric_detection': True,  # 启用几何形状检测
    'wall_distance_threshold': 80,    # 墙面点距离阈值(mm)
    'min_wall_points': 15,            # 每面墙最少点数
    'angle_tolerance': 15,            # 墙面角度容忍度
}

# 前进的起步时间（秒）
forward_start_up_time = 0.05
# 前进的示例起步占空比
forward_start_duty_cycles = {
    'front_left': 99,
    'front_right': 99,
    'rear_left': 99,
    'rear_right': 99
}
# 前进的示例正常行驶占空比
forward_normal_duty_cycles = {
    'front_left': 100,
    'front_right': 100,
    'rear_left': 100,
    'rear_right': 100
}
# 前进的行驶时间（秒）
forward_duration = 1.2

# 后退的起步时间（秒）
backward_start_up_time = 0.3
# 后退的示例起步占空比
backward_start_duty_cycles = {
    'front_left': 99,
    'front_right': 99,
    'rear_left': 70,
    'rear_right': 99
}
# 后退的示例正常行驶占空比
backward_normal_duty_cycles = {
    'front_left': 100,
    'front_right': 100,
    'rear_left': 75,
    'rear_right': 100
}
# 后退的行驶时间（秒）
backward_duration = 1.9

# 示例引脚配置
pins = {
    'front_left': {'in1': 27, 'in2': 17, 'encoder_a': 22},
    'front_right': {'in1': 13, 'in2': 19, 'encoder_a': 26},
    'rear_left': {'in1': 23, 'in2': 24, 'encoder_a': 18},
    'rear_right': {'in1': 21, 'in2': 20, 'encoder_a': 16}
}

# 创建麦轮小车对象
car = MecanumCar(pins)

# 解析触发命令
def parse_trigger_command(data_str):
    try:
        data_str = data_str.strip()
        if data_str.startswith('$+') and data_str.endswith('$'):
            content = data_str[2:-1]
            parts = content.split('+')
            if len(parts) == 2:
                angle1 = int(parts[0])
                angle2 = int(parts[1])
                if 360 <= angle1 <= 999 and 360 <= angle2 <= 999:
                    return True
        return False
    except:
        return False

# 监听触发命令的线程
def listen_for_trigger(ser):
    print("等待视觉模块触发命令...")
    
    while True:
        try:
            if ser.in_waiting > 0:
                data = ser.readline().decode().strip()
                
                if parse_trigger_command(data):
                    print(f"接收到命令: {data}")
                    start_motion()
                    
        except Exception as e:
            print(f"监听触发命令异常: {e}")
        
        time.sleep(0.05)

# 前进动作
def move_forward():
    print("开始前进...")
    car.move_forward_with_custom_duty_cycles(
        forward_start_up_time, forward_start_duty_cycles, 
        forward_normal_duty_cycles, forward_duration
    )

# 后退动作
def move_backward():
    print("开始后退...")
    car.move_backward_with_custom_duty_cycles(
        backward_start_up_time, backward_start_duty_cycles, 
        backward_normal_duty_cycles, backward_duration
    )

# 开始运动
def start_motion():
    move_forward()
    time.sleep(1.5)
    move_backward()

# 主程序入口
if __name__ == '__main__':
    try:
        # 初始化串口
        camera_serial = serial.Serial('/dev/ttyCH343USB0', 115200, timeout=0.1)
        
        # 启动监听线程
        listen_thread = threading.Thread(target=listen_for_trigger, args=(camera_serial,))
        listen_thread.daemon = True
        listen_thread.start()
        
        print("系统已启动,等待视觉模块触发命令...")
        
        # 等待程序被终止
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"程序异常: {e}")
    finally:
        car.stop()
        GPIO.cleanup()
        camera_serial.close()
        print("系统已关闭")